// Player image URLs - using reliable public image sources
// These are placeholder URLs using UI Avatars API as fallback + real image concepts
// For the blurry photo game, we create visual clue cards instead of relying on external images

export interface PlayerVisual {
  id: number;
  imageUrl: string;
  silhouetteClues: string[]; // Visual description clues revealed progressively
  hairStyle: string;
  skinTone: string;
  distinguishingFeature: string;
}

// Using picsum.photos and ui-avatars as reliable image sources
// Real player images would need proper licensing - we use creative visual clues instead
export const playerVisuals: Record<number, PlayerVisual> = {
  1: { id: 1, imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/b/b8/Messi_vs_Nigeria_2018.jpg', silhouetteClues: ['لحية خفيفة وشعر قصير', 'قصير القامة - 170 سم', 'وشم على ذراعه الأيسر', 'يرتدي الرقم 10', 'ليو - الماعز 🐐'], hairStyle: 'short-dark', skinTone: 'light', distinguishingFeature: 'قصير القامة مع لحية' },
  2: { id: 2, imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/8/8c/Cristiano_Ronaldo_2018.jpg', silhouetteClues: ['طويل القامة - 187 سم', 'عضلات بارزة وجسم رياضي', 'شعر مصفف دائماً', 'يرتدي الرقم 7', 'CR7 - SIUUU! 🐐'], hairStyle: 'styled-dark', skinTone: 'medium', distinguishingFeature: 'طويل وعضلي مع شعر مصفف' },
  3: { id: 3, imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/6/65/20180610_FIFA_Friendly_Match_Austria_vs._Brazil_Neymar_850_1705.jpg', silhouetteClues: ['تسريحات شعر غريبة ومتغيرة دائماً', 'نحيف وسريع', 'وشوم كثيرة', 'يرتدي الرقم 10', 'برازيلي يحب الرقص'], hairStyle: 'creative-changing', skinTone: 'medium', distinguishingFeature: 'تسريحات شعر مميزة ووشوم' },
  4: { id: 4, imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/5/57/2019-07-17_SG_Dynamo_Dresden_vs._Paris_Saint-Germain_by_Sandro_Halank%E2%80%93129_%28cropped%29.jpg', silhouetteClues: ['سرعة خارقة', 'فرنسي شاب', 'يضع يديه خلف ظهره عند الجري', 'يرتدي الرقم 7', 'سلحفاة نينجا 🐢'], hairStyle: 'short-dark', skinTone: 'dark', distinguishingFeature: 'شاب وسريع جداً' },
  5: { id: 5, imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/6/6e/Erling_Haaland_2023.jpg', silhouetteClues: ['أشقر طويل جداً - 194 سم', 'نرويجي ضخم', 'يحتفل بوضعية التأمل', 'يرتدي الرقم 9', 'آلة تسجيل أهداف'], hairStyle: 'blonde-long', skinTone: 'very-light', distinguishingFeature: 'أشقر طويل وضخم' },
  6: { id: 6, imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/e/e4/Karim_Benzema_2024.jpg', silhouetteClues: ['فرنسي من أصل جزائري', 'لحية مميزة', 'أنيق على الملعب', 'يرتدي الرقم 9', 'الليث الفرنسي'], hairStyle: 'short-dark', skinTone: 'medium', distinguishingFeature: 'لحية كثيفة وأنيق' },
  7: { id: 7, imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/4/4a/Mohamed_Salah_2018.jpg', silhouetteClues: ['شعر مجعد أفرو مميز', 'مصري', 'ابتسامة مميزة', 'يرتدي الرقم 11', 'الملك المصري 👑'], hairStyle: 'afro-curly', skinTone: 'medium', distinguishingFeature: 'شعر أفرو مجعد' },
  8: { id: 8, imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/e/e9/ISL_vs._CRO_2018_FIFA_WC_%28cropped%29.jpg', silhouetteClues: ['شعر أشقر طويل ومميز', 'كرواتي قصير القامة', 'صانع لعب أنيق', 'يرتدي الرقم 10', 'ساحر كرواتيا'], hairStyle: 'blonde-long', skinTone: 'light', distinguishingFeature: 'شعر أشقر طويل' },
  9: { id: 9, imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/0/03/Robert_Lewandowski%2C_FC_Bayern_M%C3%BCnchen_%28by_Sven_Mandel%2C_2019-05-27%29_01.jpg', silhouetteClues: ['بولندي طويل', 'مهاجم كلاسيكي', 'شعر قصير داكن', 'يرتدي الرقم 9', '5 أهداف في 9 دقائق!'], hairStyle: 'short-dark', skinTone: 'light', distinguishingFeature: 'مهاجم كلاسيكي بولندي' },
  10: { id: 10, imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/e/e1/Vinicius_Junior_2022.jpg', silhouetteClues: ['برازيلي شاب وسريع', 'شعر مجعد', 'مراوغ ماهر', 'يرتدي الرقم 7', 'نجم ريال مدريد الحالي'], hairStyle: 'curly-dark', skinTone: 'dark', distinguishingFeature: 'شاب برازيلي بشعر مجعد' },
  11: { id: 11, imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/8/88/Sergio_Ramos_2018.jpg', silhouetteClues: ['مدافع قوي بشعر متغير', 'وشوم كثيرة على ذراعيه', 'إسباني شرس', 'يرتدي الرقم 4', 'ملك الدقائق الأخيرة'], hairStyle: 'changing', skinTone: 'light', distinguishingFeature: 'مدافع بوشوم كثيرة' },
  12: { id: 12, imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/1/10/Jude_Bellingham_2023.jpg', silhouetteClues: ['إنجليزي شاب', 'شعر مجعد قصير', 'أنيق ومتعدد المواهب', 'يرتدي الرقم 5', 'نجم ريال مدريد الشاب'], hairStyle: 'curly-short', skinTone: 'dark', distinguishingFeature: 'شاب إنجليزي أنيق' },
  13: { id: 13, imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/4/40/Kevin_De_Bruyne_201.jpg', silhouetteClues: ['شعر أحمر/برتقالي مميز', 'بلجيكي', 'صانع لعب استثنائي', 'يرتدي الرقم 17', 'عيون زرقاء ونظرة حادة'], hairStyle: 'ginger', skinTone: 'very-light', distinguishingFeature: 'شعر أحمر/برتقالي' },
  14: { id: 14, imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/c/c4/Sadio_Man%C3%A9_2018.jpg', silhouetteClues: ['سنغالي سريع', 'ابتسامة مشرقة', 'متواضع جداً', 'يرتدي الرقم 10', 'بطل أفريقيا 2022'], hairStyle: 'short-dark', skinTone: 'very-dark', distinguishingFeature: 'ابتسامة مشرقة ومتواضع' },
  15: { id: 15, imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/f/f3/Zinedine_Zidane_by_Tasnim_03.jpg', silhouetteClues: ['أصلع الرأس', 'فرنسي من أصل جزائري', 'أنيق جداً في اللعب', 'ارتدى الرقم 5', 'النطحة الشهيرة في 2006'], hairStyle: 'bald', skinTone: 'medium', distinguishingFeature: 'أصلع الرأس' },
  16: { id: 16, imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/4/43/Ronaldinho_2019.jpg', silhouetteClues: ['ابتسامة بأسنان بارزة', 'شعر طويل مجعد', 'برازيلي ساحر', 'يرتدي الرقم 10', 'الساحر الذي أمتع العالم'], hairStyle: 'long-curly', skinTone: 'dark', distinguishingFeature: 'ابتسامة مميزة وشعر طويل' },
  17: { id: 17, imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/4/4e/Virgil_van_Dijk_2018.jpg', silhouetteClues: ['طويل جداً - 193 سم', 'هولندي ضخم', 'مدافع صخري', 'يرتدي الرقم 4', 'جدار ليفربول'], hairStyle: 'short-dark', skinTone: 'dark', distinguishingFeature: 'طويل وضخم جداً' },
  18: { id: 18, imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/4/42/Griezmann_2018.jpg', silhouetteClues: ['شعر مصبوغ أحياناً', 'فرنسي أنيق', 'يحتفل برقصات مميزة', 'يرتدي الرقم 7', 'Take the L'], hairStyle: 'dyed-varied', skinTone: 'light', distinguishingFeature: 'يحتفل برقصات ألعاب' },
  19: { id: 19, imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/5/56/Riyad_Mahrez_2019.jpg', silhouetteClues: ['لحية كثيفة', 'جزائري ماهر', 'قدم يسرى سحرية', 'يرتدي الرقم 26', 'نجم معجزة ليستر'], hairStyle: 'curly-dark', skinTone: 'medium', distinguishingFeature: 'لحية كثيفة جزائري' },
  20: { id: 20, imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/a/a5/Zlatan_Ibrahimovi%C4%87_2019.jpg', silhouetteClues: ['أنف كبير مميز', 'طويل جداً وقوي', 'ذيل حصان في الشعر', 'يرتدي الرقم 9', 'الإله زلاتان'], hairStyle: 'ponytail', skinTone: 'light', distinguishingFeature: 'طويل بذيل حصان وأنف مميز' },
  21: { id: 21, imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/b/b5/Andres_Iniesta.jpg', silhouetteClues: ['أصلع أو شبه أصلع', 'قصير القامة وهادئ', 'إسباني رقيق', 'يرتدي الرقم 8', 'هدف نهائي كأس العالم 2010'], hairStyle: 'balding', skinTone: 'light', distinguishingFeature: 'أصلع وقصير وهادئ' },
  22: { id: 22, imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/4/4a/Lamine_Yamal_2024.jpg', silhouetteClues: ['أصغر لاعب في المستوى العالي', 'إسباني مراهق', 'موهبة استثنائية', 'يرتدي الرقم 19', 'ولد 2007!'], hairStyle: 'short-dark', skinTone: 'medium', distinguishingFeature: 'مراهق صغير السن' },
  23: { id: 23, imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/2/2d/Kante_2018.jpg', silhouetteClues: ['قصير القامة جداً - 168 سم', 'ابتسامة خجولة', 'فرنسي متواضع', 'يرتدي الرقم 7', 'يغطي كل الملعب'], hairStyle: 'short-dark', skinTone: 'very-dark', distinguishingFeature: 'قصير جداً وخجول ومتواضع' },
  24: { id: 24, imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/7/7e/Harry_Kane_2022.jpg', silhouetteClues: ['إنجليزي كلاسيكي', 'شعر أشقر فاتح', 'مهاجم هداف', 'يرتدي الرقم 9', 'بلا ألقاب مع توتنهام'], hairStyle: 'blonde-short', skinTone: 'light', distinguishingFeature: 'أشقر إنجليزي كلاسيكي' },
  25: { id: 25, imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/c/c4/Thibaut_Courtois_2018.jpg', silhouetteClues: ['طويل جداً - 199 سم!', 'حارس مرمى بلجيكي', 'أطول حارس تقريباً', 'يرتدي الرقم 1', 'جدار ريال مدريد'], hairStyle: 'short-brown', skinTone: 'light', distinguishingFeature: 'طويل جداً 199 سم' },
};

// Generate a visual clue card using CSS/SVG instead of external images
export function getPlayerSilhouetteStyle(playerId: number): {
  bgGradient: string;
  icon: string;
  clues: string[];
} {
  const visual = playerVisuals[playerId];
  if (!visual) {
    return {
      bgGradient: 'linear-gradient(135deg, #1a3a1a, #0d2d0d)',
      icon: '👤',
      clues: ['لاعب كرة قدم', 'محترف', 'مشهور', 'نجم', 'أسطورة'],
    };
  }

  const gradients: Record<string, string> = {
    'very-light': 'linear-gradient(135deg, #f0d9b5, #c8a882)',
    'light': 'linear-gradient(135deg, #dbb896, #b08d6a)',
    'medium': 'linear-gradient(135deg, #b87c50, #8c5e3a)',
    'dark': 'linear-gradient(135deg, #7c4b2a, #5a351e)',
    'very-dark': 'linear-gradient(135deg, #4a2c17, #362010)',
  };

  const hairIcons: Record<string, string> = {
    'bald': '👨‍🦲', 'balding': '👨‍🦲', 'short-dark': '👨', 'styled-dark': '💇‍♂️',
    'creative-changing': '🎨', 'blonde-long': '👱', 'blonde-short': '👱',
    'afro-curly': '👨‍🦱', 'curly-dark': '👨‍🦱', 'curly-short': '👨‍🦱',
    'long-curly': '👨‍🦱', 'ginger': '👨‍🦰', 'ponytail': '👨', 'changing': '💇‍♂️',
    'dyed-varied': '🎨', 'short-brown': '👨',
  };

  return {
    bgGradient: gradients[visual.skinTone] || gradients['medium'],
    icon: hairIcons[visual.hairStyle] || '👤',
    clues: visual.silhouetteClues,
  };
}
