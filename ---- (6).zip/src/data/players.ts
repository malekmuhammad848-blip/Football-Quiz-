export interface Player {
  id: number;
  nameAr: string;
  nameEn: string;
  birthYear: number;
  nationality: string;
  nationalityAr: string;
  position: string;
  positionAr: string;
  clubs: string[];
  clubsAr: string[];
  currentClub: string;
  currentClubAr: string;
  numbers: number[];
  goals: number;
  assists: number;
  matches: number;
  titles: number;
  transferStory: string;
  transferStoryAr: string;
  coaches: string[];
  coachesAr: string[];
  firstIntlYear: number;
  achievements: string[];
  achievementsAr: string[];
  hints: string[];
  hintsAr: string[];
  teammates: string[];
  teammatesAr: string[];
  difficulty: 'easy' | 'medium' | 'hard';
}

export const players: Player[] = [
  {
    id: 1, nameAr: "ليونيل ميسي", nameEn: "Lionel Messi", birthYear: 1987,
    nationality: "Argentina", nationalityAr: "الأرجنتين", position: "Forward", positionAr: "مهاجم",
    clubs: ["Barcelona", "PSG", "Inter Miami"], clubsAr: ["برشلونة", "باريس سان جيرمان", "إنتر ميامي"],
    currentClub: "Inter Miami", currentClubAr: "إنتر ميامي", numbers: [30, 19, 10],
    goals: 838, assists: 374, matches: 1065, titles: 45,
    transferStory: "انتقل إلى باريس سان جيرمان مجاناً في 2021 بعد أزمة برشلونة المالية",
    transferStoryAr: "انتقل إلى باريس سان جيرمان مجاناً في 2021 بعد أزمة برشلونة المالية",
    coaches: ["Pep Guardiola", "Luis Enrique", "Pochettino"],
    coachesAr: ["بيب غوارديولا", "لويس إنريكي", "بوتشيتينو"],
    firstIntlYear: 2005,
    achievements: ["8 Ballon d'Or", "World Cup 2022"], achievementsAr: ["8 كرات ذهبية", "كأس العالم 2022"],
    hints: ["فاز بـ 8 كرات ذهبية", "أرجنتيني الجنسية", "لعب في برشلونة أكثر من 20 سنة", "يرتدي الرقم 10", "يُعتبر الأفضل في التاريخ"],
    hintsAr: ["فاز بـ 8 كرات ذهبية", "أرجنتيني الجنسية", "لعب في برشلونة أكثر من 20 سنة", "يرتدي الرقم 10", "يُعتبر الأفضل في التاريخ"],
    teammates: ["سواريز", "نيمار", "إنييستا", "تشافي"], teammatesAr: ["سواريز", "نيمار", "إنييستا", "تشافي"],
    difficulty: 'easy'
  },
  {
    id: 2, nameAr: "كريستيانو رونالدو", nameEn: "Cristiano Ronaldo", birthYear: 1985,
    nationality: "Portugal", nationalityAr: "البرتغال", position: "Forward", positionAr: "مهاجم",
    clubs: ["Sporting Lisbon", "Manchester United", "Real Madrid", "Juventus", "Al Nassr"],
    clubsAr: ["سبورتينغ لشبونة", "مانشستر يونايتد", "ريال مدريد", "يوفنتوس", "النصر"],
    currentClub: "Al Nassr", currentClubAr: "النصر", numbers: [28, 7, 9],
    goals: 900, assists: 260, matches: 1200, titles: 35,
    transferStory: "انتقل إلى ريال مدريد بـ 94 مليون يورو في 2009 من مانشستر يونايتد",
    transferStoryAr: "انتقل إلى ريال مدريد بـ 94 مليون يورو في 2009 من مانشستر يونايتد",
    coaches: ["Alex Ferguson", "Zinedine Zidane", "Carlo Ancelotti"],
    coachesAr: ["أليكس فيرغسون", "زين الدين زيدان", "كارلو أنشيلوتي"],
    firstIntlYear: 2003,
    achievements: ["5 Ballon d'Or", "5 Champions League"], achievementsAr: ["5 كرات ذهبية", "5 دوري أبطال أوروبا"],
    hints: ["أكثر هداف في تاريخ كرة القدم", "برتغالي الجنسية", "لعب في 3 من أكبر الدوريات الأوروبية", "يرتدي الرقم 7 الشهير", "يلعب حالياً في الدوري السعودي"],
    hintsAr: ["أكثر هداف في تاريخ كرة القدم", "برتغالي الجنسية", "لعب في 3 من أكبر الدوريات الأوروبية", "يرتدي الرقم 7 الشهير", "يلعب حالياً في الدوري السعودي"],
    teammates: ["بنزيما", "بيل", "روني", "راموس"], teammatesAr: ["بنزيما", "بيل", "روني", "راموس"],
    difficulty: 'easy'
  },
  {
    id: 3, nameAr: "نيمار جونيور", nameEn: "Neymar Jr", birthYear: 1992,
    nationality: "Brazil", nationalityAr: "البرازيل", position: "Forward", positionAr: "مهاجم",
    clubs: ["Santos", "Barcelona", "PSG", "Al Hilal", "Santos"],
    clubsAr: ["سانتوس", "برشلونة", "باريس سان جيرمان", "الهلال", "سانتوس"],
    currentClub: "Santos", currentClubAr: "سانتوس", numbers: [11, 10],
    goals: 440, assists: 280, matches: 720, titles: 28,
    transferStory: "انتقل بـ 222 مليون يورو في 2017 من برشلونة إلى باريس - أغلى صفقة في التاريخ",
    transferStoryAr: "انتقل بـ 222 مليون يورو في 2017 من برشلونة إلى باريس - أغلى صفقة في التاريخ",
    coaches: ["Luis Enrique", "Thomas Tuchel", "Unai Emery"],
    coachesAr: ["لويس إنريكي", "توماس توخيل", "أوناي إيمري"],
    firstIntlYear: 2010,
    achievements: ["Champions League 2015", "Copa Libertadores 2011"], achievementsAr: ["دوري الأبطال 2015", "كوبا ليبرتادوريس 2011"],
    hints: ["أغلى لاعب في التاريخ بـ 222 مليون يورو", "برازيلي الجنسية", "شكّل ثلاثي MSN في برشلونة", "يرتدي الرقم 10", "لعب في الدوري السعودي مع الهلال"],
    hintsAr: ["أغلى لاعب في التاريخ بـ 222 مليون يورو", "برازيلي الجنسية", "شكّل ثلاثي MSN في برشلونة", "يرتدي الرقم 10", "لعب في الدوري السعودي مع الهلال"],
    teammates: ["ميسي", "سواريز", "مبابي", "كافاني"], teammatesAr: ["ميسي", "سواريز", "مبابي", "كافاني"],
    difficulty: 'easy'
  },
  {
    id: 4, nameAr: "كيليان مبابي", nameEn: "Kylian Mbappé", birthYear: 1998,
    nationality: "France", nationalityAr: "فرنسا", position: "Forward", positionAr: "مهاجم",
    clubs: ["Monaco", "PSG", "Real Madrid"], clubsAr: ["موناكو", "باريس سان جيرمان", "ريال مدريد"],
    currentClub: "Real Madrid", currentClubAr: "ريال مدريد", numbers: [29, 7, 9],
    goals: 310, assists: 120, matches: 450, titles: 18,
    transferStory: "انتقل إلى ريال مدريد مجاناً في صيف 2024 بعد انتهاء عقده مع باريس",
    transferStoryAr: "انتقل إلى ريال مدريد مجاناً في صيف 2024 بعد انتهاء عقده مع باريس",
    coaches: ["Leonardo Jardim", "Thomas Tuchel", "Carlo Ancelotti"],
    coachesAr: ["ليوناردو جارديم", "توماس توخيل", "كارلو أنشيلوتي"],
    firstIntlYear: 2017,
    achievements: ["World Cup 2018", "7 Ligue 1"], achievementsAr: ["كأس العالم 2018", "7 ألقاب دوري فرنسي"],
    hints: ["فاز بكأس العالم 2018 وعمره 19 سنة", "فرنسي الجنسية", "بدأ في موناكو", "من أسرع لاعبين في العالم", "انتقل لريال مدريد مجاناً في 2024"],
    hintsAr: ["فاز بكأس العالم 2018 وعمره 19 سنة", "فرنسي الجنسية", "بدأ في موناكو", "من أسرع لاعبين في العالم", "انتقل لريال مدريد مجاناً في 2024"],
    teammates: ["نيمار", "ميسي", "فينيسيوس", "بيلينغهام"], teammatesAr: ["نيمار", "ميسي", "فينيسيوس", "بيلينغهام"],
    difficulty: 'easy'
  },
  {
    id: 5, nameAr: "إرلينغ هالاند", nameEn: "Erling Haaland", birthYear: 2000,
    nationality: "Norway", nationalityAr: "النرويج", position: "Forward", positionAr: "مهاجم",
    clubs: ["Bryne", "Molde", "RB Salzburg", "Borussia Dortmund", "Manchester City"],
    clubsAr: ["بريني", "مولده", "ريد بول سالزبورغ", "بوروسيا دورتموند", "مانشستر سيتي"],
    currentClub: "Manchester City", currentClubAr: "مانشستر سيتي", numbers: [9, 17],
    goals: 280, assists: 55, matches: 310, titles: 12,
    transferStory: "انتقل إلى مانشستر سيتي بـ 60 مليون يورو عبر شرط جزائي في 2022",
    transferStoryAr: "انتقل إلى مانشستر سيتي بـ 60 مليون يورو عبر شرط جزائي في 2022",
    coaches: ["Pep Guardiola", "Marco Rose", "Lucien Favre"],
    coachesAr: ["بيب غوارديولا", "ماركو روزه", "لوسيان فافر"],
    firstIntlYear: 2019,
    achievements: ["Champions League 2023", "Treble 2023"], achievementsAr: ["دوري الأبطال 2023", "الثلاثية 2023"],
    hints: ["سجل 36 هدفاً في أول موسم بالدوري الإنجليزي", "نرويجي الجنسية", "والده لعب في مانشستر سيتي", "يرتدي الرقم 9", "حقق الثلاثية مع مانشستر سيتي 2023"],
    hintsAr: ["سجل 36 هدفاً في أول موسم بالدوري الإنجليزي", "نرويجي الجنسية", "والده لعب في مانشستر سيتي", "يرتدي الرقم 9", "حقق الثلاثية مع مانشستر سيتي 2023"],
    teammates: ["دي بروين", "فودين", "غريليش", "بيرناردو سيلفا"], teammatesAr: ["دي بروين", "فودين", "غريليش", "بيرناردو سيلفا"],
    difficulty: 'easy'
  },
  {
    id: 6, nameAr: "كريم بنزيما", nameEn: "Karim Benzema", birthYear: 1987,
    nationality: "France", nationalityAr: "فرنسا", position: "Forward", positionAr: "مهاجم",
    clubs: ["Lyon", "Real Madrid", "Al Ittihad"], clubsAr: ["ليون", "ريال مدريد", "الاتحاد"],
    currentClub: "Al Ittihad", currentClubAr: "الاتحاد", numbers: [9, 10],
    goals: 470, assists: 200, matches: 850, titles: 26,
    transferStory: "انتقل إلى ريال مدريد بـ 35 مليون يورو في 2009 من ليون وبقي 14 سنة",
    transferStoryAr: "انتقل إلى ريال مدريد بـ 35 مليون يورو في 2009 من ليون وبقي 14 سنة",
    coaches: ["Zinedine Zidane", "Carlo Ancelotti", "Jose Mourinho"],
    coachesAr: ["زين الدين زيدان", "كارلو أنشيلوتي", "جوزيه مورينيو"],
    firstIntlYear: 2007,
    achievements: ["Ballon d'Or 2022", "5 Champions League"], achievementsAr: ["الكرة الذهبية 2022", "5 دوري أبطال"],
    hints: ["فاز بالكرة الذهبية في 2022", "فرنسي من أصل جزائري", "14 سنة في ريال مدريد", "يرتدي الرقم 9", "يلعب في الاتحاد السعودي"],
    hintsAr: ["فاز بالكرة الذهبية في 2022", "فرنسي من أصل جزائري", "14 سنة في ريال مدريد", "يرتدي الرقم 9", "يلعب في الاتحاد السعودي"],
    teammates: ["رونالدو", "مودريتش", "راموس", "كروس"], teammatesAr: ["رونالدو", "مودريتش", "راموس", "كروس"],
    difficulty: 'easy'
  },
  {
    id: 7, nameAr: "محمد صلاح", nameEn: "Mohamed Salah", birthYear: 1992,
    nationality: "Egypt", nationalityAr: "مصر", position: "Forward", positionAr: "مهاجم",
    clubs: ["Basel", "Chelsea", "Fiorentina", "Roma", "Liverpool"],
    clubsAr: ["بازل", "تشيلسي", "فيورنتينا", "روما", "ليفربول"],
    currentClub: "Liverpool", currentClubAr: "ليفربول", numbers: [11, 10, 22],
    goals: 350, assists: 170, matches: 650, titles: 12,
    transferStory: "انتقل إلى ليفربول بـ 42 مليون يورو في 2017 بعد تألقه مع روما",
    transferStoryAr: "انتقل إلى ليفربول بـ 42 مليون يورو في 2017 بعد تألقه مع روما",
    coaches: ["Jurgen Klopp", "Jose Mourinho", "Luciano Spalletti", "Arne Slot"],
    coachesAr: ["يورغن كلوب", "جوزيه مورينيو", "لوتشيانو سباليتي", "آرنه سلوت"],
    firstIntlYear: 2011,
    achievements: ["Champions League 2019", "Premier League 2020"], achievementsAr: ["دوري الأبطال 2019", "الدوري الإنجليزي 2020"],
    hints: ["يُلقب بالملك المصري", "لعب في سويسرا وإيطاليا وإنجلترا", "لم ينجح في تشيلسي", "يرتدي الرقم 11", "أفضل لاعب عربي وأفريقي"],
    hintsAr: ["يُلقب بالملك المصري", "لعب في سويسرا وإيطاليا وإنجلترا", "لم ينجح في تشيلسي", "يرتدي الرقم 11", "أفضل لاعب عربي وأفريقي"],
    teammates: ["ماني", "فان دايك", "فيرمينو", "أرنولد"], teammatesAr: ["ماني", "فان دايك", "فيرمينو", "أرنولد"],
    difficulty: 'easy'
  },
  {
    id: 8, nameAr: "لوكا مودريتش", nameEn: "Luka Modrić", birthYear: 1985,
    nationality: "Croatia", nationalityAr: "كرواتيا", position: "Midfielder", positionAr: "وسط ملعب",
    clubs: ["Dinamo Zagreb", "Tottenham", "Real Madrid"],
    clubsAr: ["دينامو زغرب", "توتنهام", "ريال مدريد"],
    currentClub: "Real Madrid", currentClubAr: "ريال مدريد", numbers: [10, 14, 19],
    goals: 95, assists: 180, matches: 800, titles: 26,
    transferStory: "انتقل إلى ريال مدريد بـ 35 مليون يورو في 2012 من توتنهام",
    transferStoryAr: "انتقل إلى ريال مدريد بـ 35 مليون يورو في 2012 من توتنهام",
    coaches: ["Zinedine Zidane", "Carlo Ancelotti", "Harry Redknapp"],
    coachesAr: ["زين الدين زيدان", "كارلو أنشيلوتي", "هاري ريدناب"],
    firstIntlYear: 2006,
    achievements: ["Ballon d'Or 2018", "6 Champions League"], achievementsAr: ["الكرة الذهبية 2018", "6 دوري أبطال"],
    hints: ["كسر هيمنة ميسي ورونالدو على الكرة الذهبية 2018", "كرواتي الجنسية", "انتقل من توتنهام لريال مدريد", "يرتدي الرقم 10", "قاد كرواتيا لنهائي كأس العالم 2018"],
    hintsAr: ["كسر هيمنة ميسي ورونالدو على الكرة الذهبية 2018", "كرواتي الجنسية", "انتقل من توتنهام لريال مدريد", "يرتدي الرقم 10", "قاد كرواتيا لنهائي كأس العالم 2018"],
    teammates: ["رونالدو", "بنزيما", "كروس", "راموس"], teammatesAr: ["رونالدو", "بنزيما", "كروس", "راموس"],
    difficulty: 'medium'
  },
  {
    id: 9, nameAr: "روبرت ليفاندوفسكي", nameEn: "Robert Lewandowski", birthYear: 1988,
    nationality: "Poland", nationalityAr: "بولندا", position: "Forward", positionAr: "مهاجم",
    clubs: ["Znicz Pruszków", "Lech Poznan", "Borussia Dortmund", "Bayern Munich", "Barcelona"],
    clubsAr: ["زنيتش بروشكوف", "ليخ بوزنان", "بوروسيا دورتموند", "بايرن ميونخ", "برشلونة"],
    currentClub: "Barcelona", currentClubAr: "برشلونة", numbers: [9, 7],
    goals: 650, assists: 160, matches: 900, titles: 30,
    transferStory: "انتقل لبايرن ميونخ مجاناً من دورتموند 2014 ثم لبرشلونة بـ 45 مليون 2022",
    transferStoryAr: "انتقل لبايرن ميونخ مجاناً من دورتموند 2014 ثم لبرشلونة بـ 45 مليون 2022",
    coaches: ["Pep Guardiola", "Hansi Flick", "Xavi", "Jurgen Klopp"],
    coachesAr: ["بيب غوارديولا", "هانسي فليك", "تشافي", "يورغن كلوب"],
    firstIntlYear: 2008,
    achievements: ["Champions League 2020", "8 Bundesliga"], achievementsAr: ["دوري الأبطال 2020", "8 بوندسليغا"],
    hints: ["سجل 5 أهداف في 9 دقائق ضد فولفسبورغ 2015", "بولندي الجنسية", "انتقل من دورتموند لبايرن مجاناً", "يرتدي الرقم 9", "أكثر أجنبي تسجيلاً في البوندسليغا"],
    hintsAr: ["سجل 5 أهداف في 9 دقائق ضد فولفسبورغ 2015", "بولندي الجنسية", "انتقل من دورتموند لبايرن مجاناً", "يرتدي الرقم 9", "أكثر أجنبي تسجيلاً في البوندسليغا"],
    teammates: ["مولر", "كيميتش", "بيدري", "رافينيا"], teammatesAr: ["مولر", "كيميتش", "بيدري", "رافينيا"],
    difficulty: 'easy'
  },
  {
    id: 10, nameAr: "فينيسيوس جونيور", nameEn: "Vinícius Jr", birthYear: 2000,
    nationality: "Brazil", nationalityAr: "البرازيل", position: "Forward", positionAr: "مهاجم",
    clubs: ["Flamengo", "Real Madrid"], clubsAr: ["فلامنغو", "ريال مدريد"],
    currentClub: "Real Madrid", currentClubAr: "ريال مدريد", numbers: [20, 7],
    goals: 110, assists: 85, matches: 300, titles: 12,
    transferStory: "تعاقد معه ريال مدريد من فلامنغو بـ 45 مليون يورو بعمر 18 سنة",
    transferStoryAr: "تعاقد معه ريال مدريد من فلامنغو بـ 45 مليون يورو بعمر 18 سنة",
    coaches: ["Carlo Ancelotti", "Zinedine Zidane", "Santiago Solari"],
    coachesAr: ["كارلو أنشيلوتي", "زين الدين زيدان", "سانتياغو سولاري"],
    firstIntlYear: 2019,
    achievements: ["2 Champions League", "2 La Liga"], achievementsAr: ["2 دوري أبطال", "2 دوري إسباني"],
    hints: ["جاء من فلامنغو البرازيلي بعمر 18", "برازيلي", "لعب في ريال مدريد فقط أوروبياً", "ورث الرقم 7", "سجل في نهائي دوري الأبطال 2024"],
    hintsAr: ["جاء من فلامنغو البرازيلي بعمر 18", "برازيلي", "لعب في ريال مدريد فقط أوروبياً", "ورث الرقم 7", "سجل في نهائي دوري الأبطال 2024"],
    teammates: ["مبابي", "بنزيما", "مودريتش", "كروس"], teammatesAr: ["مبابي", "بنزيما", "مودريتش", "كروس"],
    difficulty: 'easy'
  },
  {
    id: 11, nameAr: "سيرخيو راموس", nameEn: "Sergio Ramos", birthYear: 1986,
    nationality: "Spain", nationalityAr: "إسبانيا", position: "Defender", positionAr: "مدافع",
    clubs: ["Sevilla", "Real Madrid", "PSG", "Sevilla"],
    clubsAr: ["إشبيلية", "ريال مدريد", "باريس سان جيرمان", "إشبيلية"],
    currentClub: "Retired", currentClubAr: "معتزل", numbers: [4, 15],
    goals: 130, assists: 50, matches: 850, titles: 30,
    transferStory: "انتقل لريال مدريد بـ 27 مليون يورو من إشبيلية بعمر 19 سنة في 2005",
    transferStoryAr: "انتقل لريال مدريد بـ 27 مليون يورو من إشبيلية بعمر 19 سنة في 2005",
    coaches: ["Zinedine Zidane", "Carlo Ancelotti", "Jose Mourinho"],
    coachesAr: ["زين الدين زيدان", "كارلو أنشيلوتي", "جوزيه مورينيو"],
    firstIntlYear: 2005,
    achievements: ["4 Champions League", "World Cup 2010", "Euro 2008, 2012"],
    achievementsAr: ["4 دوري أبطال", "كأس العالم 2010", "يورو 2008 و2012"],
    hints: ["مدافع يسجل أهدافاً حاسمة في الدقائق الأخيرة", "إسباني", "قائد ريال مدريد لسنوات", "يرتدي الرقم 4", "سجل هدف المعادلة الدقيقة 93 نهائي دوري الأبطال 2014"],
    hintsAr: ["مدافع يسجل أهدافاً حاسمة في الدقائق الأخيرة", "إسباني", "قائد ريال مدريد لسنوات", "يرتدي الرقم 4", "سجل هدف المعادلة الدقيقة 93 نهائي دوري الأبطال 2014"],
    teammates: ["رونالدو", "بنزيما", "مودريتش", "كاسياس"], teammatesAr: ["رونالدو", "بنزيما", "مودريتش", "كاسياس"],
    difficulty: 'easy'
  },
  {
    id: 12, nameAr: "جود بيلينغهام", nameEn: "Jude Bellingham", birthYear: 2003,
    nationality: "England", nationalityAr: "إنجلترا", position: "Midfielder", positionAr: "وسط ملعب",
    clubs: ["Birmingham City", "Borussia Dortmund", "Real Madrid"],
    clubsAr: ["برمنغهام سيتي", "بوروسيا دورتموند", "ريال مدريد"],
    currentClub: "Real Madrid", currentClubAr: "ريال مدريد", numbers: [22, 5],
    goals: 80, assists: 50, matches: 250, titles: 6,
    transferStory: "انتقل لريال مدريد بـ 103 مليون يورو في 2023 من بوروسيا دورتموند",
    transferStoryAr: "انتقل لريال مدريد بـ 103 مليون يورو في 2023 من بوروسيا دورتموند",
    coaches: ["Carlo Ancelotti", "Marco Rose", "Edin Terzić"],
    coachesAr: ["كارلو أنشيلوتي", "ماركو روزه", "إيدين تيرزيتش"],
    firstIntlYear: 2020,
    achievements: ["La Liga 2024", "Champions League 2024"], achievementsAr: ["الدوري الإسباني 2024", "دوري الأبطال 2024"],
    hints: ["أصغر لاعب يلعب لبرمنغهام سيتي بعمر 16", "إنجليزي", "لعب في دورتموند قبل إسبانيا", "يرتدي الرقم 5 في ريال مدريد", "سجل 23 هدفاً في أول نصف موسم مع ريال مدريد"],
    hintsAr: ["أصغر لاعب يلعب لبرمنغهام سيتي بعمر 16", "إنجليزي", "لعب في دورتموند قبل إسبانيا", "يرتدي الرقم 5 في ريال مدريد", "سجل 23 هدفاً في أول نصف موسم مع ريال مدريد"],
    teammates: ["فينيسيوس", "مبابي", "مودريتش", "كروس"], teammatesAr: ["فينيسيوس", "مبابي", "مودريتش", "كروس"],
    difficulty: 'medium'
  },
  {
    id: 13, nameAr: "كيفن دي بروين", nameEn: "Kevin De Bruyne", birthYear: 1991,
    nationality: "Belgium", nationalityAr: "بلجيكا", position: "Midfielder", positionAr: "وسط ملعب",
    clubs: ["Genk", "Chelsea", "Werder Bremen", "Wolfsburg", "Manchester City"],
    clubsAr: ["جينك", "تشيلسي", "فيردر بريمن", "فولفسبورغ", "مانشستر سيتي"],
    currentClub: "Manchester City", currentClubAr: "مانشستر سيتي", numbers: [17, 7],
    goals: 120, assists: 220, matches: 600, titles: 18,
    transferStory: "انتقل لمانشستر سيتي بـ 76 مليون يورو في 2015 من فولفسبورغ",
    transferStoryAr: "انتقل لمانشستر سيتي بـ 76 مليون يورو في 2015 من فولفسبورغ",
    coaches: ["Pep Guardiola", "Jose Mourinho"],
    coachesAr: ["بيب غوارديولا", "جوزيه مورينيو"],
    firstIntlYear: 2010,
    achievements: ["Champions League 2023", "6 Premier League"], achievementsAr: ["دوري الأبطال 2023", "6 دوري إنجليزي"],
    hints: ["أفضل صانع لعب في الدوري الإنجليزي الحديث", "بلجيكي", "لم يحظَ بفرصة في تشيلسي مع مورينيو", "يرتدي الرقم 17", "يلعب لمانشستر سيتي منذ 2015"],
    hintsAr: ["أفضل صانع لعب في الدوري الإنجليزي الحديث", "بلجيكي", "لم يحظَ بفرصة في تشيلسي مع مورينيو", "يرتدي الرقم 17", "يلعب لمانشستر سيتي منذ 2015"],
    teammates: ["هالاند", "فودين", "بيرناردو سيلفا", "أغويرو"], teammatesAr: ["هالاند", "فودين", "بيرناردو سيلفا", "أغويرو"],
    difficulty: 'medium'
  },
  {
    id: 14, nameAr: "ساديو ماني", nameEn: "Sadio Mané", birthYear: 1992,
    nationality: "Senegal", nationalityAr: "السنغال", position: "Forward", positionAr: "مهاجم",
    clubs: ["Metz", "RB Salzburg", "Southampton", "Liverpool", "Bayern Munich", "Al Nassr"],
    clubsAr: ["ميتز", "ريد بول سالزبورغ", "ساوثهامبتون", "ليفربول", "بايرن ميونخ", "النصر"],
    currentClub: "Al Nassr", currentClubAr: "النصر", numbers: [10, 19, 17],
    goals: 260, assists: 100, matches: 600, titles: 14,
    transferStory: "انتقل لليفربول بـ 34 مليون جنيه في 2016 من ساوثهامبتون",
    transferStoryAr: "انتقل لليفربول بـ 34 مليون جنيه في 2016 من ساوثهامبتون",
    coaches: ["Jurgen Klopp", "Julian Nagelsmann", "Thomas Tuchel"],
    coachesAr: ["يورغن كلوب", "يوليان ناغلسمان", "توماس توخيل"],
    firstIntlYear: 2012,
    achievements: ["Champions League 2019", "AFCON 2022"], achievementsAr: ["دوري الأبطال 2019", "كأس أمم أفريقيا 2022"],
    hints: ["فاز بكأس أمم أفريقيا مع السنغال 2022", "سنغالي", "ثنائي مع صلاح في ليفربول", "سجل أسرع هاتريك بالدوري الإنجليزي", "يلعب في النصر مع رونالدو"],
    hintsAr: ["فاز بكأس أمم أفريقيا مع السنغال 2022", "سنغالي", "ثنائي مع صلاح في ليفربول", "سجل أسرع هاتريك بالدوري الإنجليزي", "يلعب في النصر مع رونالدو"],
    teammates: ["صلاح", "فان دايك", "رونالدو", "مولر"], teammatesAr: ["صلاح", "فان دايك", "رونالدو", "مولر"],
    difficulty: 'medium'
  },
  {
    id: 15, nameAr: "زين الدين زيدان", nameEn: "Zinedine Zidane", birthYear: 1972,
    nationality: "France", nationalityAr: "فرنسا", position: "Midfielder", positionAr: "وسط ملعب",
    clubs: ["Cannes", "Bordeaux", "Juventus", "Real Madrid"],
    clubsAr: ["كان", "بوردو", "يوفنتوس", "ريال مدريد"],
    currentClub: "Retired", currentClubAr: "معتزل", numbers: [5, 21, 10],
    goals: 125, assists: 120, matches: 680, titles: 18,
    transferStory: "انتقل لريال مدريد بـ 77.5 مليون يورو في 2001 - أغلى لاعب وقتها",
    transferStoryAr: "انتقل لريال مدريد بـ 77.5 مليون يورو في 2001 - أغلى لاعب وقتها",
    coaches: ["Marcello Lippi", "Vicente del Bosque"],
    coachesAr: ["مارسيلو ليبي", "بيسينتي ديل بوسكي"],
    firstIntlYear: 1994,
    achievements: ["World Cup 1998", "Euro 2000", "Champions League 2002"], achievementsAr: ["كأس العالم 1998", "يورو 2000", "دوري الأبطال 2002"],
    hints: ["سجل هدفين برأسه في نهائي كأس العالم 1998", "فرنسي من أصل جزائري", "لعب في يوفنتوس ثم ريال مدريد", "ارتدى الرقم 5 في ريال مدريد", "طُرد بنطحة لماتيراتزي في نهائي 2006"],
    hintsAr: ["سجل هدفين برأسه في نهائي كأس العالم 1998", "فرنسي من أصل جزائري", "لعب في يوفنتوس ثم ريال مدريد", "ارتدى الرقم 5 في ريال مدريد", "طُرد بنطحة لماتيراتزي في نهائي 2006"],
    teammates: ["فيغو", "روبرتو كارلوس", "رونالدو البرازيلي", "ديل بييرو"], teammatesAr: ["فيغو", "روبرتو كارلوس", "رونالدو البرازيلي", "ديل بييرو"],
    difficulty: 'medium'
  },
  {
    id: 16, nameAr: "رونالدينيو", nameEn: "Ronaldinho", birthYear: 1980,
    nationality: "Brazil", nationalityAr: "البرازيل", position: "Forward", positionAr: "مهاجم",
    clubs: ["Grêmio", "PSG", "Barcelona", "AC Milan", "Flamengo", "Atlético Mineiro"],
    clubsAr: ["غريميو", "باريس سان جيرمان", "برشلونة", "ميلان", "فلامنغو", "أتلتيكو مينيرو"],
    currentClub: "Retired", currentClubAr: "معتزل", numbers: [10, 80, 21],
    goals: 250, assists: 180, matches: 600, titles: 16,
    transferStory: "انتقل لبرشلونة بـ 30 مليون يورو في 2003 من باريس سان جيرمان",
    transferStoryAr: "انتقل لبرشلونة بـ 30 مليون يورو في 2003 من باريس سان جيرمان",
    coaches: ["Frank Rijkaard", "Carlo Ancelotti"],
    coachesAr: ["فرانك ريكارد", "كارلو أنشيلوتي"],
    firstIntlYear: 1999,
    achievements: ["World Cup 2002", "Ballon d'Or 2005", "Champions League 2006"],
    achievementsAr: ["كأس العالم 2002", "الكرة الذهبية 2005", "دوري الأبطال 2006"],
    hints: ["الساحر صاحب الابتسامة الدائمة والمهارات الخارقة", "برازيلي", "صفق له جمهور ريال مدريد تقديراً", "لعب في برشلونة وميلان وباريس", "كأس العالم 2002 والكرة الذهبية 2005"],
    hintsAr: ["الساحر صاحب الابتسامة الدائمة والمهارات الخارقة", "برازيلي", "صفق له جمهور ريال مدريد تقديراً", "لعب في برشلونة وميلان وباريس", "كأس العالم 2002 والكرة الذهبية 2005"],
    teammates: ["ميسي", "إيتو", "ديكو", "بويول"], teammatesAr: ["ميسي", "إيتو", "ديكو", "بويول"],
    difficulty: 'medium'
  },
  {
    id: 17, nameAr: "فيرجيل فان دايك", nameEn: "Virgil van Dijk", birthYear: 1991,
    nationality: "Netherlands", nationalityAr: "هولندا", position: "Defender", positionAr: "مدافع",
    clubs: ["Groningen", "Celtic", "Southampton", "Liverpool"],
    clubsAr: ["غرونينغن", "سلتيك", "ساوثهامبتون", "ليفربول"],
    currentClub: "Liverpool", currentClubAr: "ليفربول", numbers: [4, 17],
    goals: 45, assists: 20, matches: 500, titles: 10,
    transferStory: "انتقل لليفربول بـ 75 مليون جنيه يناير 2018 - أغلى مدافع وقتها",
    transferStoryAr: "انتقل لليفربول بـ 75 مليون جنيه يناير 2018 - أغلى مدافع وقتها",
    coaches: ["Jurgen Klopp", "Ronald Koeman", "Arne Slot"],
    coachesAr: ["يورغن كلوب", "رونالد كومان", "آرنه سلوت"],
    firstIntlYear: 2015,
    achievements: ["Champions League 2019", "Premier League 2020"], achievementsAr: ["دوري الأبطال 2019", "الدوري الإنجليزي 2020"],
    hints: ["كان أغلى مدافع في التاريخ عند انتقاله", "هولندي", "لعب في سلتيك قبل إنجلترا", "يرتدي الرقم 4", "غيّر دفاع ليفربول تماماً"],
    hintsAr: ["كان أغلى مدافع في التاريخ عند انتقاله", "هولندي", "لعب في سلتيك قبل إنجلترا", "يرتدي الرقم 4", "غيّر دفاع ليفربول تماماً"],
    teammates: ["صلاح", "ماني", "فيرمينو", "أرنولد"], teammatesAr: ["صلاح", "ماني", "فيرمينو", "أرنولد"],
    difficulty: 'medium'
  },
  {
    id: 18, nameAr: "أنطوان غريزمان", nameEn: "Antoine Griezmann", birthYear: 1991,
    nationality: "France", nationalityAr: "فرنسا", position: "Forward", positionAr: "مهاجم",
    clubs: ["Real Sociedad", "Atlético Madrid", "Barcelona", "Atlético Madrid"],
    clubsAr: ["ريال سوسيداد", "أتلتيكو مدريد", "برشلونة", "أتلتيكو مدريد"],
    currentClub: "Atlético Madrid", currentClubAr: "أتلتيكو مدريد", numbers: [7, 17, 8],
    goals: 290, assists: 140, matches: 700, titles: 10,
    transferStory: "انتقل لبرشلونة بـ 120 مليون يورو 2019 ثم عاد لأتلتيكو",
    transferStoryAr: "انتقل لبرشلونة بـ 120 مليون يورو 2019 ثم عاد لأتلتيكو",
    coaches: ["Diego Simeone", "Ernesto Valverde", "Didier Deschamps"],
    coachesAr: ["دييغو سيميوني", "إرنستو فالفيردي", "ديدييه ديشان"],
    firstIntlYear: 2014,
    achievements: ["World Cup 2018", "Europa League 2018"], achievementsAr: ["كأس العالم 2018", "الدوري الأوروبي 2018"],
    hints: ["يحتفل برقصة Take the L", "فرنسي", "انتقل لبرشلونة ثم عاد لأتلتيكو", "بدأ في ريال سوسيداد", "سجل هدفين في نهائي كأس العالم 2018"],
    hintsAr: ["يحتفل برقصة Take the L", "فرنسي", "انتقل لبرشلونة ثم عاد لأتلتيكو", "بدأ في ريال سوسيداد", "سجل هدفين في نهائي كأس العالم 2018"],
    teammates: ["سواريز", "ميسي", "جواو فيليكس", "كوكي"], teammatesAr: ["سواريز", "ميسي", "جواو فيليكس", "كوكي"],
    difficulty: 'medium'
  },
  {
    id: 19, nameAr: "رياض محرز", nameEn: "Riyad Mahrez", birthYear: 1991,
    nationality: "Algeria", nationalityAr: "الجزائر", position: "Forward", positionAr: "مهاجم",
    clubs: ["Le Havre", "Leicester City", "Manchester City", "Al Ahli"],
    clubsAr: ["لوهافر", "ليستر سيتي", "مانشستر سيتي", "الأهلي السعودي"],
    currentClub: "Al Ahli", currentClubAr: "الأهلي السعودي", numbers: [26, 7],
    goals: 150, assists: 120, matches: 500, titles: 12,
    transferStory: "انتقل لمانشستر سيتي بـ 60 مليون جنيه في 2018 بعد معجزة ليستر",
    transferStoryAr: "انتقل لمانشستر سيتي بـ 60 مليون جنيه في 2018 بعد معجزة ليستر",
    coaches: ["Pep Guardiola", "Claudio Ranieri"],
    coachesAr: ["بيب غوارديولا", "كلاوديو رانييري"],
    firstIntlYear: 2014,
    achievements: ["AFCON 2019", "Premier League 2016 with Leicester"], achievementsAr: ["كأس أمم أفريقيا 2019", "الدوري الإنجليزي 2016 مع ليستر"],
    hints: ["جزء من معجزة ليستر سيتي 2016", "جزائري", "ليستر ثم مانشستر سيتي", "يرتدي الرقم 26", "قاد الجزائر لكأس أمم أفريقيا 2019"],
    hintsAr: ["جزء من معجزة ليستر سيتي 2016", "جزائري", "ليستر ثم مانشستر سيتي", "يرتدي الرقم 26", "قاد الجزائر لكأس أمم أفريقيا 2019"],
    teammates: ["دي بروين", "هالاند", "فاردي", "كانتي"], teammatesAr: ["دي بروين", "هالاند", "فاردي", "كانتي"],
    difficulty: 'medium'
  },
  {
    id: 20, nameAr: "زلاتان إبراهيموفيتش", nameEn: "Zlatan Ibrahimović", birthYear: 1981,
    nationality: "Sweden", nationalityAr: "السويد", position: "Forward", positionAr: "مهاجم",
    clubs: ["Malmö", "Ajax", "Juventus", "Inter Milan", "Barcelona", "AC Milan", "PSG", "Manchester United", "LA Galaxy", "AC Milan"],
    clubsAr: ["مالمو", "أياكس", "يوفنتوس", "إنتر ميلان", "برشلونة", "ميلان", "باريس سان جيرمان", "مانشستر يونايتد", "غالاكسي", "ميلان"],
    currentClub: "Retired", currentClubAr: "معتزل", numbers: [9, 10, 11],
    goals: 570, assists: 200, matches: 1000, titles: 33,
    transferStory: "لعب لـ 10 أندية في 6 دول مختلفة",
    transferStoryAr: "لعب لـ 10 أندية في 6 دول مختلفة",
    coaches: ["Pep Guardiola", "Jose Mourinho", "Carlo Ancelotti", "Max Allegri"],
    coachesAr: ["بيب غوارديولا", "جوزيه مورينيو", "كارلو أنشيلوتي", "ماكس أليغري"],
    firstIntlYear: 2001,
    achievements: ["13 League titles in 4 countries"], achievementsAr: ["13 لقب دوري في 4 دول"],
    hints: ["لعب في أكثر من 6 دول", "سويدي من أصل بوسني", "ثقة عالية وتصريحات مثيرة", "موسم واحد في برشلونة مع غوارديولا", "اعتزل في ميلان عن 41 سنة"],
    hintsAr: ["لعب في أكثر من 6 دول", "سويدي من أصل بوسني", "ثقة عالية وتصريحات مثيرة", "موسم واحد في برشلونة مع غوارديولا", "اعتزل في ميلان عن 41 سنة"],
    teammates: ["ميسي", "بوغبا", "نيمار", "مبابي"], teammatesAr: ["ميسي", "بوغبا", "نيمار", "مبابي"],
    difficulty: 'medium'
  },
  {
    id: 21, nameAr: "أندريس إنييستا", nameEn: "Andrés Iniesta", birthYear: 1984,
    nationality: "Spain", nationalityAr: "إسبانيا", position: "Midfielder", positionAr: "وسط ملعب",
    clubs: ["Barcelona", "Vissel Kobe", "Emirates Club"],
    clubsAr: ["برشلونة", "فيسيل كوبي", "نادي الإمارات"],
    currentClub: "Retired", currentClubAr: "معتزل", numbers: [8],
    goals: 75, assists: 180, matches: 750, titles: 35,
    transferStory: "غادر برشلونة لليابان في 2018 بعد 16 سنة في الفريق الأول",
    transferStoryAr: "غادر برشلونة لليابان في 2018 بعد 16 سنة في الفريق الأول",
    coaches: ["Pep Guardiola", "Luis Enrique", "Frank Rijkaard"],
    coachesAr: ["بيب غوارديولا", "لويس إنريكي", "فرانك ريكارد"],
    firstIntlYear: 2006,
    achievements: ["World Cup 2010", "Euro 2008, 2012", "4 Champions League"],
    achievementsAr: ["كأس العالم 2010", "يورو 2008 و2012", "4 دوري أبطال"],
    hints: ["سجل هدف فوز إسبانيا نهائي كأس العالم 2010", "إسباني", "مسيرته الأوروبية كلها في برشلونة", "يرتدي الرقم 8", "أذكى لاعبي الوسط في التاريخ"],
    hintsAr: ["سجل هدف فوز إسبانيا نهائي كأس العالم 2010", "إسباني", "مسيرته الأوروبية كلها في برشلونة", "يرتدي الرقم 8", "أذكى لاعبي الوسط في التاريخ"],
    teammates: ["ميسي", "تشافي", "بويول", "بوسكيتس"], teammatesAr: ["ميسي", "تشافي", "بويول", "بوسكيتس"],
    difficulty: 'medium'
  },
  {
    id: 22, nameAr: "لامين يامال", nameEn: "Lamine Yamal", birthYear: 2007,
    nationality: "Spain", nationalityAr: "إسبانيا", position: "Forward", positionAr: "مهاجم",
    clubs: ["Barcelona"], clubsAr: ["برشلونة"],
    currentClub: "Barcelona", currentClubAr: "برشلونة", numbers: [19, 27],
    goals: 15, assists: 20, matches: 70, titles: 3,
    transferStory: "خريج أكاديمية لا ماسيا في برشلونة",
    transferStoryAr: "خريج أكاديمية لا ماسيا في برشلونة",
    coaches: ["Xavi", "Hansi Flick"], coachesAr: ["تشافي", "هانسي فليك"],
    firstIntlYear: 2023,
    achievements: ["Euro 2024"], achievementsAr: ["يورو 2024"],
    hints: ["أصغر لاعب يسجل في تاريخ أمم أوروبا", "إسباني", "خريج لا ماسيا", "يرتدي الرقم 19", "وُلد 2007 أكبر موهبة في العالم"],
    hintsAr: ["أصغر لاعب يسجل في تاريخ أمم أوروبا", "إسباني", "خريج لا ماسيا", "يرتدي الرقم 19", "وُلد 2007 أكبر موهبة في العالم"],
    teammates: ["ليفاندوفسكي", "بيدري", "رافينيا", "غافي"], teammatesAr: ["ليفاندوفسكي", "بيدري", "رافينيا", "غافي"],
    difficulty: 'medium'
  },
  {
    id: 23, nameAr: "نغولو كانتي", nameEn: "N'Golo Kanté", birthYear: 1991,
    nationality: "France", nationalityAr: "فرنسا", position: "Midfielder", positionAr: "وسط ملعب",
    clubs: ["Boulogne", "Caen", "Leicester City", "Chelsea", "Al Ittihad"],
    clubsAr: ["بولوني", "كان", "ليستر سيتي", "تشيلسي", "الاتحاد"],
    currentClub: "Al Ittihad", currentClubAr: "الاتحاد", numbers: [14, 7],
    goals: 35, assists: 50, matches: 500, titles: 14,
    transferStory: "فاز بالدوري مع ليستر 2016 ثم انتقل لتشيلسي وفاز به مجدداً 2017",
    transferStoryAr: "فاز بالدوري مع ليستر 2016 ثم انتقل لتشيلسي وفاز به مجدداً 2017",
    coaches: ["Claudio Ranieri", "Antonio Conte", "Thomas Tuchel"],
    coachesAr: ["كلاوديو رانييري", "أنطونيو كونتي", "توماس توخيل"],
    firstIntlYear: 2016,
    achievements: ["World Cup 2018", "Champions League 2021"], achievementsAr: ["كأس العالم 2018", "دوري الأبطال 2021"],
    hints: ["فاز بالدوري مع فريقين متتاليين", "فرنسي", "بدأ من الدرجات الدنيا", "ليستر ثم تشيلسي", "أفضل وسط دفاعي في جيله"],
    hintsAr: ["فاز بالدوري مع فريقين متتاليين", "فرنسي", "بدأ من الدرجات الدنيا", "ليستر ثم تشيلسي", "أفضل وسط دفاعي في جيله"],
    teammates: ["هازارد", "فاردي", "محرز", "بنزيما"], teammatesAr: ["هازارد", "فاردي", "محرز", "بنزيما"],
    difficulty: 'medium'
  },
  {
    id: 24, nameAr: "هاري كين", nameEn: "Harry Kane", birthYear: 1993,
    nationality: "England", nationalityAr: "إنجلترا", position: "Forward", positionAr: "مهاجم",
    clubs: ["Tottenham", "Bayern Munich"],
    clubsAr: ["توتنهام", "بايرن ميونخ"],
    currentClub: "Bayern Munich", currentClubAr: "بايرن ميونخ", numbers: [10, 9],
    goals: 350, assists: 90, matches: 600, titles: 2,
    transferStory: "انتقل لبايرن ميونخ بـ 100 مليون يورو في 2023 بدون ألقاب من توتنهام",
    transferStoryAr: "انتقل لبايرن ميونخ بـ 100 مليون يورو في 2023 بدون ألقاب من توتنهام",
    coaches: ["Jose Mourinho", "Thomas Tuchel", "Pochettino", "Vincent Kompany"],
    coachesAr: ["جوزيه مورينيو", "توماس توخيل", "بوتشيتينو", "فينسنت كومباني"],
    firstIntlYear: 2015,
    achievements: ["3 Premier League Golden Boot"], achievementsAr: ["3 مرات هداف الدوري الإنجليزي"],
    hints: ["هداف توتنهام التاريخي", "إنجليزي", "انتقل لبايرن 2023", "يرتدي الرقم 9", "لم يفز بلقب مع توتنهام"],
    hintsAr: ["هداف توتنهام التاريخي", "إنجليزي", "انتقل لبايرن 2023", "يرتدي الرقم 9", "لم يفز بلقب مع توتنهام"],
    teammates: ["سون", "مولر", "كيميتش", "ساني"], teammatesAr: ["سون", "مولر", "كيميتش", "ساني"],
    difficulty: 'medium'
  },
  {
    id: 25, nameAr: "تيبو كورتوا", nameEn: "Thibaut Courtois", birthYear: 1992,
    nationality: "Belgium", nationalityAr: "بلجيكا", position: "Goalkeeper", positionAr: "حارس مرمى",
    clubs: ["Genk", "Atlético Madrid", "Chelsea", "Real Madrid"],
    clubsAr: ["جينك", "أتلتيكو مدريد", "تشيلسي", "ريال مدريد"],
    currentClub: "Real Madrid", currentClubAr: "ريال مدريد", numbers: [1, 13],
    goals: 0, assists: 2, matches: 550, titles: 14,
    transferStory: "انتقل لريال مدريد بـ 35 مليون يورو من تشيلسي 2018",
    transferStoryAr: "انتقل لريال مدريد بـ 35 مليون يورو من تشيلسي 2018",
    coaches: ["Carlo Ancelotti", "Diego Simeone", "Jose Mourinho"],
    coachesAr: ["كارلو أنشيلوتي", "دييغو سيميوني", "جوزيه مورينيو"],
    firstIntlYear: 2011,
    achievements: ["Champions League 2022", "La Liga 2022"], achievementsAr: ["دوري الأبطال 2022", "الدوري الإسباني 2022"],
    hints: ["أفضل حارس في نهائي دوري الأبطال 2022 ضد ليفربول", "بلجيكي", "أُعير لأتلتيكو 3 مواسم", "طوله 199 سم", "حارس ريال مدريد"],
    hintsAr: ["أفضل حارس في نهائي دوري الأبطال 2022 ضد ليفربول", "بلجيكي", "أُعير لأتلتيكو 3 مواسم", "طوله 199 سم", "حارس ريال مدريد"],
    teammates: ["بنزيما", "مودريتش", "هازارد", "راموس"], teammatesAr: ["بنزيما", "مودريتش", "هازارد", "راموس"],
    difficulty: 'medium'
  },
  {
    id: 26, nameAr: "بيدري", nameEn: "Pedri", birthYear: 2002,
    nationality: "Spain", nationalityAr: "إسبانيا", position: "Midfielder", positionAr: "وسط ملعب",
    clubs: ["Las Palmas", "Barcelona"],
    clubsAr: ["لاس بالماس", "برشلونة"],
    currentClub: "Barcelona", currentClubAr: "برشلونة", numbers: [8, 16],
    goals: 30, assists: 25, matches: 200, titles: 5,
    transferStory: "انتقل لبرشلونة بـ 5 مليون يورو فقط من لاس بالماس 2020",
    transferStoryAr: "انتقل لبرشلونة بـ 5 مليون يورو فقط من لاس بالماس 2020",
    coaches: ["Xavi", "Ronald Koeman", "Hansi Flick"],
    coachesAr: ["تشافي", "رونالد كومان", "هانسي فليك"],
    firstIntlYear: 2021,
    achievements: ["Euro 2024", "Golden Boy 2021"], achievementsAr: ["يورو 2024", "الفتى الذهبي 2021"],
    hints: ["يُقارن بإنييستا في أسلوبه", "إسباني من جزر الكناري", "جاء من لاس بالماس بمبلغ زهيد", "ورث الرقم 8", "يورو 2024"],
    hintsAr: ["يُقارن بإنييستا في أسلوبه", "إسباني من جزر الكناري", "جاء من لاس بالماس بمبلغ زهيد", "ورث الرقم 8", "يورو 2024"],
    teammates: ["ليفاندوفسكي", "يامال", "غافي", "رافينيا"], teammatesAr: ["ليفاندوفسكي", "يامال", "غافي", "رافينيا"],
    difficulty: 'hard'
  },
  {
    id: 27, nameAr: "فيل فودين", nameEn: "Phil Foden", birthYear: 2000,
    nationality: "England", nationalityAr: "إنجلترا", position: "Midfielder", positionAr: "وسط ملعب",
    clubs: ["Manchester City"], clubsAr: ["مانشستر سيتي"],
    currentClub: "Manchester City", currentClubAr: "مانشستر سيتي", numbers: [47],
    goals: 80, assists: 55, matches: 280, titles: 14,
    transferStory: "خريج أكاديمية مانشستر سيتي ولم ينتقل لأي نادٍ آخر",
    transferStoryAr: "خريج أكاديمية مانشستر سيتي ولم ينتقل لأي نادٍ آخر",
    coaches: ["Pep Guardiola"], coachesAr: ["بيب غوارديولا"],
    firstIntlYear: 2020,
    achievements: ["Treble 2023", "PFA Player 2024"], achievementsAr: ["الثلاثية 2023", "أفضل لاعب إنجلترا 2024"],
    hints: ["خريج أكاديمية سيتي ولم يغادرها", "إنجليزي", "الرقم 47 غير المعتاد", "الثلاثية 2023", "تدرب تحت غوارديولا فقط"],
    hintsAr: ["خريج أكاديمية سيتي ولم يغادرها", "إنجليزي", "الرقم 47 غير المعتاد", "الثلاثية 2023", "تدرب تحت غوارديولا فقط"],
    teammates: ["هالاند", "دي بروين", "غريليش", "ووكر"], teammatesAr: ["هالاند", "دي بروين", "غريليش", "ووكر"],
    difficulty: 'hard'
  },
  {
    id: 28, nameAr: "تشافي هيرنانديز", nameEn: "Xavi Hernández", birthYear: 1980,
    nationality: "Spain", nationalityAr: "إسبانيا", position: "Midfielder", positionAr: "وسط ملعب",
    clubs: ["Barcelona", "Al Sadd"], clubsAr: ["برشلونة", "السد القطري"],
    currentClub: "Retired", currentClubAr: "معتزل", numbers: [6],
    goals: 85, assists: 185, matches: 870, titles: 33,
    transferStory: "غادر برشلونة للسد القطري 2015 ثم عاد مدرباً لبرشلونة 2021",
    transferStoryAr: "غادر برشلونة للسد القطري 2015 ثم عاد مدرباً لبرشلونة 2021",
    coaches: ["Pep Guardiola", "Frank Rijkaard", "Louis van Gaal"],
    coachesAr: ["بيب غوارديولا", "فرانك ريكارد", "لويس فان غال"],
    firstIntlYear: 2000,
    achievements: ["World Cup 2010", "Euro 2008, 2012", "4 Champions League"],
    achievementsAr: ["كأس العالم 2010", "يورو 2008 و2012", "4 دوري أبطال"],
    hints: ["أفضل لاعب تمرير في التاريخ", "إسباني", "رمز لا ماسيا", "يرتدي الرقم 6", "أصبح مدرباً لبرشلونة"],
    hintsAr: ["أفضل لاعب تمرير في التاريخ", "إسباني", "رمز لا ماسيا", "يرتدي الرقم 6", "أصبح مدرباً لبرشلونة"],
    teammates: ["ميسي", "إنييستا", "بويول", "بوسكيتس"], teammatesAr: ["ميسي", "إنييستا", "بويول", "بوسكيتس"],
    difficulty: 'medium'
  },
  {
    id: 29, nameAr: "توني كروس", nameEn: "Toni Kroos", birthYear: 1990,
    nationality: "Germany", nationalityAr: "ألمانيا", position: "Midfielder", positionAr: "وسط ملعب",
    clubs: ["Bayern Munich", "Bayer Leverkusen", "Real Madrid"],
    clubsAr: ["بايرن ميونخ", "باير ليفركوزن", "ريال مدريد"],
    currentClub: "Retired", currentClubAr: "معتزل", numbers: [8, 39],
    goals: 50, assists: 140, matches: 700, titles: 28,
    transferStory: "انتقل لريال مدريد بـ 25 مليون يورو 2014 بعد كأس العالم",
    transferStoryAr: "انتقل لريال مدريد بـ 25 مليون يورو 2014 بعد كأس العالم",
    coaches: ["Zinedine Zidane", "Carlo Ancelotti", "Jupp Heynckes"],
    coachesAr: ["زين الدين زيدان", "كارلو أنشيلوتي", "يوب هاينكس"],
    firstIntlYear: 2010,
    achievements: ["World Cup 2014", "5 Champions League"], achievementsAr: ["كأس العالم 2014", "5 دوري أبطال"],
    hints: ["كأس العالم 2014 مع ألمانيا", "ألماني", "بايرن ثم ريال مدريد", "يرتدي الرقم 8", "اعتزل بعد يورو 2024"],
    hintsAr: ["كأس العالم 2014 مع ألمانيا", "ألماني", "بايرن ثم ريال مدريد", "يرتدي الرقم 8", "اعتزل بعد يورو 2024"],
    teammates: ["رونالدو", "بنزيما", "مودريتش", "راموس"], teammatesAr: ["رونالدو", "بنزيما", "مودريتش", "راموس"],
    difficulty: 'hard'
  },
  {
    id: 30, nameAr: "بوكايو ساكا", nameEn: "Bukayo Saka", birthYear: 2001,
    nationality: "England", nationalityAr: "إنجلترا", position: "Forward", positionAr: "مهاجم",
    clubs: ["Arsenal"], clubsAr: ["أرسنال"],
    currentClub: "Arsenal", currentClubAr: "أرسنال", numbers: [7, 77],
    goals: 70, assists: 55, matches: 220, titles: 1,
    transferStory: "خريج أكاديمية أرسنال منذ طفولته",
    transferStoryAr: "خريج أكاديمية أرسنال منذ طفولته",
    coaches: ["Mikel Arteta", "Unai Emery"],
    coachesAr: ["ميكيل أرتيتا", "أوناي إيمري"],
    firstIntlYear: 2020,
    achievements: ["Euro 2024 finalist"], achievementsAr: ["وصيف يورو 2024"],
    hints: ["خريج أكاديمية أرسنال", "إنجليزي من أصل نيجيري", "يرتدي الرقم 7", "أخطأ ركلة ترجيح يورو 2020 بعمر 19", "نجم أرسنال الحالي"],
    hintsAr: ["خريج أكاديمية أرسنال", "إنجليزي من أصل نيجيري", "يرتدي الرقم 7", "أخطأ ركلة ترجيح يورو 2020 بعمر 19", "نجم أرسنال الحالي"],
    teammates: ["أوديغارد", "رايس", "سليمان", "هافيرتز"], teammatesAr: ["أوديغارد", "رايس", "سليمان", "هافيرتز"],
    difficulty: 'hard'
  },
  {
    id: 31, nameAr: "أشرف حكيمي", nameEn: "Achraf Hakimi", birthYear: 1998,
    nationality: "Morocco", nationalityAr: "المغرب", position: "Defender", positionAr: "مدافع",
    clubs: ["Real Madrid", "Borussia Dortmund", "Inter Milan", "PSG"],
    clubsAr: ["ريال مدريد", "بوروسيا دورتموند", "إنتر ميلان", "باريس سان جيرمان"],
    currentClub: "PSG", currentClubAr: "باريس سان جيرمان", numbers: [2, 5],
    goals: 35, assists: 55, matches: 350, titles: 12,
    transferStory: "انتقل لباريس بـ 60 مليون يورو 2021 من إنتر ميلان",
    transferStoryAr: "انتقل لباريس بـ 60 مليون يورو 2021 من إنتر ميلان",
    coaches: ["Carlo Ancelotti", "Antonio Conte", "Luis Enrique"],
    coachesAr: ["كارلو أنشيلوتي", "أنطونيو كونتي", "لويس إنريكي"],
    firstIntlYear: 2016,
    achievements: ["World Cup Semi-final 2022", "Serie A 2021"], achievementsAr: ["نصف نهائي كأس العالم 2022", "الدوري الإيطالي 2021"],
    hints: ["أسرع ظهير في العالم", "مغربي ولد في مدريد", "أكاديمية ريال مدريد", "يرتدي الرقم 2", "بانينكا ضد إسبانيا كأس العالم 2022"],
    hintsAr: ["أسرع ظهير في العالم", "مغربي ولد في مدريد", "أكاديمية ريال مدريد", "يرتدي الرقم 2", "بانينكا ضد إسبانيا كأس العالم 2022"],
    teammates: ["مبابي", "نيمار", "ميسي", "لوكاكو"], teammatesAr: ["مبابي", "نيمار", "ميسي", "لوكاكو"],
    difficulty: 'hard'
  },
  {
    id: 32, nameAr: "جمال موسيالا", nameEn: "Jamal Musiala", birthYear: 2003,
    nationality: "Germany", nationalityAr: "ألمانيا", position: "Midfielder", positionAr: "وسط ملعب",
    clubs: ["Chelsea Youth", "Bayern Munich"],
    clubsAr: ["شباب تشيلسي", "بايرن ميونخ"],
    currentClub: "Bayern Munich", currentClubAr: "بايرن ميونخ", numbers: [42, 10],
    goals: 45, assists: 30, matches: 170, titles: 3,
    transferStory: "غادر أكاديمية تشيلسي وانضم لشباب بايرن ميونخ",
    transferStoryAr: "غادر أكاديمية تشيلسي وانضم لشباب بايرن ميونخ",
    coaches: ["Thomas Tuchel", "Julian Nagelsmann", "Vincent Kompany"],
    coachesAr: ["توماس توخيل", "يوليان ناغلسمان", "فينسنت كومباني"],
    firstIntlYear: 2021,
    achievements: ["Bundesliga 2023"], achievementsAr: ["البوندسليغا 2023"],
    hints: ["كان في أكاديمية تشيلسي قبل بايرن", "ألماني لأم إنجليزية نيجيرية", "اختار ألمانيا وليس إنجلترا", "الرقم 42 ثم 10", "أصغر ألماني يسجل بدوري الأبطال"],
    hintsAr: ["كان في أكاديمية تشيلسي قبل بايرن", "ألماني لأم إنجليزية نيجيرية", "اختار ألمانيا وليس إنجلترا", "الرقم 42 ثم 10", "أصغر ألماني يسجل بدوري الأبطال"],
    teammates: ["كين", "كيميتش", "مولر", "ساني"], teammatesAr: ["كين", "كيميتش", "مولر", "ساني"],
    difficulty: 'hard'
  },
  {
    id: 33, nameAr: "حكيم زياش", nameEn: "Hakim Ziyech", birthYear: 1993,
    nationality: "Morocco", nationalityAr: "المغرب", position: "Midfielder", positionAr: "وسط ملعب",
    clubs: ["Heerenveen", "Twente", "Ajax", "Chelsea", "Galatasaray"],
    clubsAr: ["هيرينفين", "توينتي", "أياكس", "تشيلسي", "غلطة سراي"],
    currentClub: "Galatasaray", currentClubAr: "غلطة سراي", numbers: [22, 10],
    goals: 95, assists: 110, matches: 450, titles: 6,
    transferStory: "انتقل لتشيلسي بـ 40 مليون يورو 2020 من أياكس",
    transferStoryAr: "انتقل لتشيلسي بـ 40 مليون يورو 2020 من أياكس",
    coaches: ["Erik ten Hag", "Thomas Tuchel", "Graham Potter"],
    coachesAr: ["إيريك تين هاخ", "توماس توخيل", "غراهام بوتر"],
    firstIntlYear: 2015,
    achievements: ["CL semi-final with Ajax 2019"], achievementsAr: ["نصف نهائي دوري الأبطال مع أياكس 2019"],
    hints: ["قدم يسرى ساحرة", "مغربي ولد في هولندا", "تألق مع أياكس", "يرتدي الرقم 22", "إنجاز المغرب كأس العالم 2022"],
    hintsAr: ["قدم يسرى ساحرة", "مغربي ولد في هولندا", "تألق مع أياكس", "يرتدي الرقم 22", "إنجاز المغرب كأس العالم 2022"],
    teammates: ["حكيمي", "النصيري", "بونو", "فان دي بيك"], teammatesAr: ["حكيمي", "النصيري", "بونو", "فان دي بيك"],
    difficulty: 'hard'
  },
  {
    id: 34, nameAr: "ترينت ألكسندر أرنولد", nameEn: "Trent Alexander-Arnold", birthYear: 1998,
    nationality: "England", nationalityAr: "إنجلترا", position: "Defender", positionAr: "مدافع",
    clubs: ["Liverpool"], clubsAr: ["ليفربول"],
    currentClub: "Liverpool", currentClubAr: "ليفربول", numbers: [66],
    goals: 25, assists: 90, matches: 350, titles: 8,
    transferStory: "خريج أكاديمية ليفربول ولد في مدينة ليفربول",
    transferStoryAr: "خريج أكاديمية ليفربول ولد في مدينة ليفربول",
    coaches: ["Jurgen Klopp", "Arne Slot"],
    coachesAr: ["يورغن كلوب", "آرنه سلوت"],
    firstIntlYear: 2018,
    achievements: ["Champions League 2019", "Premier League 2020"], achievementsAr: ["دوري الأبطال 2019", "الدوري الإنجليزي 2020"],
    hints: ["ظهير أيمن بتمريرات صانع لعب", "إنجليزي من ليفربول نفسها", "خريج أكاديمية ليفربول", "الرقم 66 غير المعتاد", "ركنية سريعة ذكية ضد برشلونة 4-0 في 2019"],
    hintsAr: ["ظهير أيمن بتمريرات صانع لعب", "إنجليزي من ليفربول نفسها", "خريج أكاديمية ليفربول", "الرقم 66 غير المعتاد", "ركنية سريعة ذكية ضد برشلونة 4-0 في 2019"],
    teammates: ["صلاح", "فان دايك", "ماني", "فيرمينو"], teammatesAr: ["صلاح", "فان دايك", "ماني", "فيرمينو"],
    difficulty: 'hard'
  },
  {
    id: 35, nameAr: "إيدين هازارد", nameEn: "Eden Hazard", birthYear: 1991,
    nationality: "Belgium", nationalityAr: "بلجيكا", position: "Forward", positionAr: "مهاجم",
    clubs: ["Lille", "Chelsea", "Real Madrid"],
    clubsAr: ["ليل", "تشيلسي", "ريال مدريد"],
    currentClub: "Retired", currentClubAr: "معتزل", numbers: [10, 7, 17],
    goals: 150, assists: 120, matches: 550, titles: 9,
    transferStory: "انتقل لريال مدريد بـ 100 مليون يورو 2019 لكن عانى من الإصابات",
    transferStoryAr: "انتقل لريال مدريد بـ 100 مليون يورو 2019 لكن عانى من الإصابات",
    coaches: ["Jose Mourinho", "Antonio Conte", "Zinedine Zidane"],
    coachesAr: ["جوزيه مورينيو", "أنطونيو كونتي", "زين الدين زيدان"],
    firstIntlYear: 2008,
    achievements: ["2 Europa League", "2 Premier League"], achievementsAr: ["2 الدوري الأوروبي", "2 دوري إنجليزي"],
    hints: ["أفضل لاعب بالدوري الإنجليزي قبل انتقاله", "بلجيكي", "فشل في ريال مدريد بسبب الإصابات", "الرقم 10 في تشيلسي والرقم 7 في مدريد", "اعتزل مبكراً 2023 بعمر 32"],
    hintsAr: ["أفضل لاعب بالدوري الإنجليزي قبل انتقاله", "بلجيكي", "فشل في ريال مدريد بسبب الإصابات", "الرقم 10 في تشيلسي والرقم 7 في مدريد", "اعتزل مبكراً 2023 بعمر 32"],
    teammates: ["كورتوا", "كانتي", "بنزيما", "مودريتش"], teammatesAr: ["كورتوا", "كانتي", "بنزيما", "مودريتش"],
    difficulty: 'hard'
  },
  {
    id: 36, nameAr: "بول بوغبا", nameEn: "Paul Pogba", birthYear: 1993,
    nationality: "France", nationalityAr: "فرنسا", position: "Midfielder", positionAr: "وسط ملعب",
    clubs: ["Manchester United", "Juventus", "Manchester United", "Juventus"],
    clubsAr: ["مانشستر يونايتد", "يوفنتوس", "مانشستر يونايتد", "يوفنتوس"],
    currentClub: "Suspended", currentClubAr: "موقوف", numbers: [6, 10],
    goals: 85, assists: 95, matches: 460, titles: 12,
    transferStory: "غادر يونايتد مجاناً 2012 ثم عاد بـ 105 مليون يورو 2016",
    transferStoryAr: "غادر يونايتد مجاناً 2012 ثم عاد بـ 105 مليون يورو 2016",
    coaches: ["Jose Mourinho", "Max Allegri", "Ole Gunnar Solskjær"],
    coachesAr: ["جوزيه مورينيو", "ماكس أليغري", "أولي غونار سولشاير"],
    firstIntlYear: 2013,
    achievements: ["World Cup 2018", "4 Serie A"], achievementsAr: ["كأس العالم 2018", "4 دوري إيطالي"],
    hints: ["غادر يونايتد مجاناً ثم عاد بـ 105 مليون", "فرنسي", "لعب في يونايتد مرتين", "يرتدي الرقم 6", "سجل في نهائي كأس العالم 2018"],
    hintsAr: ["غادر يونايتد مجاناً ثم عاد بـ 105 مليون", "فرنسي", "لعب في يونايتد مرتين", "يرتدي الرقم 6", "سجل في نهائي كأس العالم 2018"],
    teammates: ["رونالدو", "ديبالا", "لوكاكو", "إبراهيموفيتش"], teammatesAr: ["رونالدو", "ديبالا", "لوكاكو", "إبراهيموفيتش"],
    difficulty: 'hard'
  },
  {
    id: 37, nameAr: "مارسيلو", nameEn: "Marcelo", birthYear: 1988,
    nationality: "Brazil", nationalityAr: "البرازيل", position: "Defender", positionAr: "مدافع",
    clubs: ["Fluminense", "Real Madrid", "Fluminense"],
    clubsAr: ["فلومينينسي", "ريال مدريد", "فلومينينسي"],
    currentClub: "Fluminense", currentClubAr: "فلومينينسي", numbers: [12, 3],
    goals: 55, assists: 110, matches: 650, titles: 25,
    transferStory: "انضم لريال مدريد بعمر 18 سنة في 2007 وبقي 15 سنة",
    transferStoryAr: "انضم لريال مدريد بعمر 18 سنة في 2007 وبقي 15 سنة",
    coaches: ["Zinedine Zidane", "Carlo Ancelotti", "Jose Mourinho"],
    coachesAr: ["زين الدين زيدان", "كارلو أنشيلوتي", "جوزيه مورينيو"],
    firstIntlYear: 2006,
    achievements: ["5 Champions League", "6 La Liga"], achievementsAr: ["5 دوري أبطال", "6 دوري إسباني"],
    hints: ["أفضل ظهير أيسر في جيله", "برازيلي", "15 سنة في ريال مدريد", "الرقم 12 الشهير", "عاد لفلومينينسي"],
    hintsAr: ["أفضل ظهير أيسر في جيله", "برازيلي", "15 سنة في ريال مدريد", "الرقم 12 الشهير", "عاد لفلومينينسي"],
    teammates: ["رونالدو", "بنزيما", "راموس", "مودريتش"], teammatesAr: ["رونالدو", "بنزيما", "راموس", "مودريتش"],
    difficulty: 'hard'
  },
  {
    id: 38, nameAr: "أليسون بيكر", nameEn: "Alisson Becker", birthYear: 1992,
    nationality: "Brazil", nationalityAr: "البرازيل", position: "Goalkeeper", positionAr: "حارس مرمى",
    clubs: ["Internacional", "Roma", "Liverpool"],
    clubsAr: ["إنترناسيونال", "روما", "ليفربول"],
    currentClub: "Liverpool", currentClubAr: "ليفربول", numbers: [1],
    goals: 1, assists: 3, matches: 450, titles: 10,
    transferStory: "انتقل لليفربول بـ 66.8 مليون يورو 2018 - أغلى حارس وقتها",
    transferStoryAr: "انتقل لليفربول بـ 66.8 مليون يورو 2018 - أغلى حارس وقتها",
    coaches: ["Jurgen Klopp", "Eusebio Di Francesco", "Arne Slot"],
    coachesAr: ["يورغن كلوب", "إوزيبيو دي فرانشيسكو", "آرنه سلوت"],
    firstIntlYear: 2015,
    achievements: ["Champions League 2019", "Premier League 2020"], achievementsAr: ["دوري الأبطال 2019", "الدوري الإنجليزي 2020"],
    hints: ["سجل هدفاً برأسه كحارس ضد وست بروميتش 2021", "برازيلي", "لعب في روما قبل ليفربول", "يرتدي الرقم 1", "أغلى حارس عند انتقاله"],
    hintsAr: ["سجل هدفاً برأسه كحارس ضد وست بروميتش 2021", "برازيلي", "لعب في روما قبل ليفربول", "يرتدي الرقم 1", "أغلى حارس عند انتقاله"],
    teammates: ["صلاح", "فان دايك", "أرنولد", "ماني"], teammatesAr: ["صلاح", "فان دايك", "أرنولد", "ماني"],
    difficulty: 'hard'
  },
  {
    id: 39, nameAr: "كارلوس بويول", nameEn: "Carles Puyol", birthYear: 1978,
    nationality: "Spain", nationalityAr: "إسبانيا", position: "Defender", positionAr: "مدافع",
    clubs: ["Barcelona"], clubsAr: ["برشلونة"],
    currentClub: "Retired", currentClubAr: "معتزل", numbers: [5],
    goals: 25, assists: 15, matches: 600, titles: 22,
    transferStory: "لاعب نادي واحد طوال مسيرته - برشلونة فقط",
    transferStoryAr: "لاعب نادي واحد طوال مسيرته - برشلونة فقط",
    coaches: ["Pep Guardiola", "Frank Rijkaard", "Louis van Gaal"],
    coachesAr: ["بيب غوارديولا", "فرانك ريكارد", "لويس فان غال"],
    firstIntlYear: 2000,
    achievements: ["World Cup 2010", "Euro 2008", "3 Champions League"],
    achievementsAr: ["كأس العالم 2010", "يورو 2008", "3 دوري أبطال"],
    hints: ["قائد برشلونة بالشعر المجعد الطويل", "إسباني", "برشلونة فقط طوال مسيرته", "يرتدي الرقم 5", "هدف برأسه نصف نهائي كأس العالم 2010 ضد ألمانيا"],
    hintsAr: ["قائد برشلونة بالشعر المجعد الطويل", "إسباني", "برشلونة فقط طوال مسيرته", "يرتدي الرقم 5", "هدف برأسه نصف نهائي كأس العالم 2010 ضد ألمانيا"],
    teammates: ["ميسي", "إنييستا", "تشافي", "رونالدينيو"], teammatesAr: ["ميسي", "إنييستا", "تشافي", "رونالدينيو"],
    difficulty: 'hard'
  },
  {
    id: 40, nameAr: "يوسف النصيري", nameEn: "Youssef En-Nesyri", birthYear: 1997,
    nationality: "Morocco", nationalityAr: "المغرب", position: "Forward", positionAr: "مهاجم",
    clubs: ["Málaga", "Leganés", "Sevilla", "Fenerbahçe"],
    clubsAr: ["مالقا", "ليغانيس", "إشبيلية", "فنربخشة"],
    currentClub: "Fenerbahçe", currentClubAr: "فنربخشة", numbers: [12, 15, 19],
    goals: 100, assists: 20, matches: 300, titles: 2,
    transferStory: "انتقل لفنربخشة التركي في 2024 من إشبيلية",
    transferStoryAr: "انتقل لفنربخشة التركي في 2024 من إشبيلية",
    coaches: ["Julen Lopetegui", "Jose Mourinho"],
    coachesAr: ["خولين لوبيتيغي", "جوزيه مورينيو"],
    firstIntlYear: 2019,
    achievements: ["World Cup Semi-final 2022", "Europa League 2020"], achievementsAr: ["نصف نهائي كأس العالم 2022", "الدوري الأوروبي 2020"],
    hints: ["هدف فوز المغرب على البرتغال ربع نهائي 2022", "مغربي", "إشبيلية عدة مواسم", "قفز عالي مذهل بالرأس", "يلعب في فنربخشة"],
    hintsAr: ["هدف فوز المغرب على البرتغال ربع نهائي 2022", "مغربي", "إشبيلية عدة مواسم", "قفز عالي مذهل بالرأس", "يلعب في فنربخشة"],
    teammates: ["حكيمي", "بونو", "زياش", "أمرابط"], teammatesAr: ["حكيمي", "بونو", "زياش", "أمرابط"],
    difficulty: 'hard'
  },
];

// Dynamic question generation from player data
export interface GeneratedTrueFalse {
  id: number;
  statement: string;
  answer: boolean;
  explanation: string;
  difficulty: 'easy' | 'medium' | 'hard';
}

export interface GeneratedQuickQuestion {
  id: number;
  question: string;
  options: string[];
  answer: string;
  difficulty: 'easy' | 'medium' | 'hard';
}

function shuffleArr<T>(arr: T[]): T[] {
  const s = [...arr];
  for (let i = s.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [s[i], s[j]] = [s[j], s[i]];
  }
  return s;
}

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

function pickN<T>(arr: T[], n: number): T[] {
  return shuffleArr(arr).slice(0, n);
}

// Generate unlimited True/False questions dynamically from player data
export function generateTrueFalse(difficulty: 'easy' | 'medium' | 'hard'): GeneratedTrueFalse {
  const pool = difficulty === 'easy' ? players.filter(p => p.difficulty === 'easy')
    : difficulty === 'medium' ? players.filter(p => p.difficulty !== 'hard')
    : players;
  
  const p = pick(pool);
  const othersPool = players.filter(x => x.id !== p.id);
  const other = pick(othersPool);
  const id = Math.floor(Math.random() * 999999);

  // Templates based on difficulty
  const easyTemplates = [
    // Correct nationality
    () => ({ statement: `${p.nameAr} جنسيته ${p.nationalityAr}`, answer: true, explanation: `نعم، ${p.nameAr} يحمل جنسية ${p.nationalityAr}` }),
    // Wrong nationality
    () => ({ statement: `${p.nameAr} جنسيته ${other.nationalityAr !== p.nationalityAr ? other.nationalityAr : 'ألمانيا'}`, answer: false, explanation: `لا، ${p.nameAr} جنسيته ${p.nationalityAr} وليس ${other.nationalityAr}` }),
    // Current club correct
    () => ({ statement: `${p.nameAr} يلعب حالياً في ${p.currentClubAr}`, answer: true, explanation: `نعم، ${p.nameAr} يلعب في ${p.currentClubAr}` }),
    // Current club wrong
    () => ({ statement: `${p.nameAr} يلعب حالياً في ${other.currentClubAr !== p.currentClubAr ? other.currentClubAr : 'ريال مدريد'}`, answer: false, explanation: `لا، ${p.nameAr} يلعب في ${p.currentClubAr} وليس ${other.currentClubAr}` }),
    // Position correct
    () => ({ statement: `${p.nameAr} يلعب في مركز ${p.positionAr}`, answer: true, explanation: `نعم، ${p.nameAr} يلعب ${p.positionAr}` }),
    // Played for club (true)
    () => {
      const club = pick(p.clubsAr);
      return { statement: `${p.nameAr} لعب في ${club} خلال مسيرته`, answer: true, explanation: `نعم، ${p.nameAr} لعب فعلاً في ${club}` };
    },
    // Never played for club (false)
    () => {
      const fakeClub = pick(othersPool.flatMap(x => x.clubsAr).filter(c => !p.clubsAr.includes(c)));
      return { statement: `${p.nameAr} لعب في ${fakeClub || 'أتلتيكو مدريد'} خلال مسيرته`, answer: false, explanation: `لا، ${p.nameAr} لم يلعب في ${fakeClub}. أنديته: ${p.clubsAr.join('، ')}` };
    },
  ];

  const mediumTemplates = [
    // Birth year correct
    () => ({ statement: `${p.nameAr} وُلد في عام ${p.birthYear}`, answer: true, explanation: `نعم، ${p.nameAr} وُلد عام ${p.birthYear}` }),
    // Birth year wrong
    () => ({ statement: `${p.nameAr} وُلد في عام ${p.birthYear + (Math.random() > 0.5 ? 2 : -3)}`, answer: false, explanation: `لا، ${p.nameAr} وُلد عام ${p.birthYear}` }),
    // Goals comparison
    () => {
      const more = p.goals > other.goals;
      return { statement: `${p.nameAr} سجل أهدافاً أكثر من ${other.nameAr} في مسيرته`, answer: more, explanation: `${p.nameAr} سجل ${p.goals} هدفاً بينما ${other.nameAr} سجل ${other.goals} هدفاً` };
    },
    // Coach trained player (true)
    () => {
      const coach = pick(p.coachesAr);
      return { statement: `${coach} درّب ${p.nameAr} في مسيرته`, answer: true, explanation: `نعم، ${coach} درّب ${p.nameAr}` };
    },
    // Coach never trained player (false)
    () => {
      const fakeCoach = pick(othersPool.flatMap(x => x.coachesAr).filter(c => !p.coachesAr.includes(c)));
      return { statement: `${fakeCoach || 'كلوب'} درّب ${p.nameAr} في مسيرته`, answer: false, explanation: `لا، ${fakeCoach} لم يدرّب ${p.nameAr}. مدربوه: ${p.coachesAr.join('، ')}` };
    },
    // Number correct
    () => {
      const num = pick(p.numbers);
      return { statement: `${p.nameAr} ارتدى الرقم ${num} في مسيرته`, answer: true, explanation: `نعم، ${p.nameAr} ارتدى الرقم ${num}` };
    },
    // Titles comparison
    () => {
      const more = p.titles > other.titles;
      return { statement: `${p.nameAr} فاز بألقاب أكثر من ${other.nameAr}`, answer: more, explanation: `${p.nameAr} فاز بـ ${p.titles} لقب بينما ${other.nameAr} فاز بـ ${other.titles} لقب` };
    },
    // First intl year
    () => ({ statement: `${p.nameAr} لعب أول مباراة دولية في عام ${p.firstIntlYear}`, answer: true, explanation: `نعم، أول مباراة دولية لـ ${p.nameAr} كانت في ${p.firstIntlYear}` }),
    // First intl year wrong
    () => {
      const fakeYear = p.firstIntlYear + (Math.random() > 0.5 ? 3 : -2);
      return { statement: `${p.nameAr} لعب أول مباراة دولية في عام ${fakeYear}`, answer: false, explanation: `لا، أول مباراة دولية لـ ${p.nameAr} كانت في ${p.firstIntlYear} وليس ${fakeYear}` };
    },
  ];

  const hardTemplates = [
    // Assists comparison
    () => {
      const more = p.assists > other.assists;
      return { statement: `${p.nameAr} قدم تمريرات حاسمة أكثر من ${other.nameAr}`, answer: more, explanation: `${p.nameAr} قدم ${p.assists} تمريرة حاسمة بينما ${other.nameAr} قدم ${other.assists}` };
    },
    // Teammate (true)
    () => {
      const tm = pick(p.teammatesAr);
      return { statement: `${p.nameAr} لعب مع ${tm} في نفس الفريق`, answer: true, explanation: `نعم، ${p.nameAr} و${tm} كانا زملاء في نفس الفريق` };
    },
    // Not teammate (false)
    () => {
      const fakeTm = pick(othersPool.filter(x => !p.teammatesAr.includes(x.nameAr)).map(x => x.nameAr));
      return { statement: `${p.nameAr} لعب مع ${fakeTm || 'موسيالا'} في نفس الفريق`, answer: false, explanation: `لا، ${p.nameAr} لم يلعب مع ${fakeTm} في نفس الفريق` };
    },
    // Matches comparison
    () => {
      const more = p.matches > other.matches;
      return { statement: `${p.nameAr} لعب مباريات أكثر من ${other.nameAr} في مسيرته`, answer: more, explanation: `${p.nameAr} لعب ${p.matches} مباراة بينما ${other.nameAr} لعب ${other.matches}` };
    },
    // Number wrong
    () => {
      const fakeNum = pick([3, 4, 5, 6, 8, 14, 21, 23, 25, 99].filter(n => !p.numbers.includes(n)));
      return { statement: `${p.nameAr} ارتدى الرقم ${fakeNum} في مسيرته`, answer: false, explanation: `لا، أرقام ${p.nameAr}: ${p.numbers.join('، ')}` };
    },
    // Age started intl
    () => {
      const age = p.firstIntlYear - p.birthYear;
      return { statement: `${p.nameAr} لعب أول مباراة دولية وعمره ${age} سنة`, answer: true, explanation: `نعم، ولد ${p.birthYear} وأول مباراة دولية ${p.firstIntlYear} أي بعمر ${age}` };
    },
    // How many clubs
    () => {
      const numClubs = new Set(p.clubsAr).size;
      return { statement: `${p.nameAr} لعب لـ ${numClubs} أندية مختلفة في مسيرته`, answer: true, explanation: `نعم، لعب لـ ${numClubs} أندية: ${[...new Set(p.clubsAr)].join('، ')}` };
    },
    // Wrong number of clubs
    () => {
      const numClubs = new Set(p.clubsAr).size;
      const fakeNum = numClubs + (Math.random() > 0.5 ? 2 : 3);
      return { statement: `${p.nameAr} لعب لـ ${fakeNum} أندية مختلفة في مسيرته`, answer: false, explanation: `لا، لعب لـ ${numClubs} أندية فقط: ${[...new Set(p.clubsAr)].join('، ')}` };
    },
  ];

  let templates: typeof easyTemplates;
  if (difficulty === 'easy') templates = easyTemplates;
  else if (difficulty === 'medium') templates = [...easyTemplates, ...mediumTemplates];
  else templates = [...mediumTemplates, ...hardTemplates];

  const gen = pick(templates)();
  return { id, difficulty, ...gen };
}

// Generate unlimited Quick Questions dynamically
export function generateQuickQuestion(difficulty: 'easy' | 'medium' | 'hard'): GeneratedQuickQuestion {
  const pool = difficulty === 'easy' ? players.filter(p => p.difficulty === 'easy')
    : difficulty === 'medium' ? players.filter(p => p.difficulty !== 'hard')
    : players;
  
  const p = pick(pool);
  const others = pickN(pool.filter(x => x.id !== p.id), 3);
  const id = Math.floor(Math.random() * 999999);

  const easyTemplates = [
    () => ({ question: `ما هي جنسية ${p.nameAr}؟`, options: shuffleArr([p.nationalityAr, ...others.map(o => o.nationalityAr).filter(n => n !== p.nationalityAr)].slice(0, 4)), answer: p.nationalityAr }),
    () => ({ question: `في أي نادي يلعب ${p.nameAr} حالياً؟`, options: shuffleArr([p.currentClubAr, ...others.map(o => o.currentClubAr).filter(c => c !== p.currentClubAr)].slice(0, 4)), answer: p.currentClubAr }),
    () => ({ question: `ما هو مركز ${p.nameAr}؟`, options: shuffleArr(["مهاجم", "وسط ملعب", "مدافع", "حارس مرمى"]), answer: p.positionAr }),
    () => {
      const club = pick(p.clubsAr);
      return { question: `أي لاعب لعب في ${club}؟`, options: shuffleArr([p.nameAr, ...others.map(o => o.nameAr)].slice(0, 4)), answer: p.nameAr };
    },
  ];

  const mediumTemplates = [
    () => ({ question: `في أي سنة وُلد ${p.nameAr}؟`, options: shuffleArr([`${p.birthYear}`, `${p.birthYear + 2}`, `${p.birthYear - 1}`, `${p.birthYear + 3}`]), answer: `${p.birthYear}` }),
    () => ({ question: `كم عدد ألقاب ${p.nameAr} تقريباً؟`, options: shuffleArr([`${p.titles}`, `${p.titles + 5}`, `${Math.max(0, p.titles - 8)}`, `${p.titles + 12}`]), answer: `${p.titles}` }),
    () => {
      const coach = pick(p.coachesAr);
      return { question: `من درّب ${p.nameAr}؟`, options: shuffleArr([coach, ...pickN(players.flatMap(x => x.coachesAr).filter(c => !p.coachesAr.includes(c)), 3)].slice(0, 4)), answer: coach };
    },
    () => ({ question: `في أي سنة لعب ${p.nameAr} أول مباراة دولية؟`, options: shuffleArr([`${p.firstIntlYear}`, `${p.firstIntlYear + 2}`, `${p.firstIntlYear - 2}`, `${p.firstIntlYear + 4}`]), answer: `${p.firstIntlYear}` }),
    () => {
      const tm = pick(p.teammatesAr);
      return { question: `من لعب مع ${p.nameAr} في نفس الفريق؟`, options: shuffleArr([tm, ...pickN(players.flatMap(x => x.teammatesAr).filter(t => !p.teammatesAr.includes(t)), 3)].slice(0, 4)), answer: tm };
    },
  ];

  const hardTemplates = [
    () => ({ question: `كم هدفاً سجل ${p.nameAr} تقريباً في مسيرته؟`, options: shuffleArr([`${p.goals}`, `${p.goals + 100}`, `${Math.max(0, p.goals - 80)}`, `${p.goals + 200}`]), answer: `${p.goals}` }),
    () => ({ question: `كم تمريرة حاسمة قدم ${p.nameAr} تقريباً؟`, options: shuffleArr([`${p.assists}`, `${p.assists + 50}`, `${Math.max(0, p.assists - 40)}`, `${p.assists + 100}`]), answer: `${p.assists}` }),
    () => {
      const num = pick(p.numbers);
      return { question: `ما هو أحد الأرقام التي ارتداها ${p.nameAr}؟`, options: shuffleArr([`${num}`, ...pickN([1,2,3,4,5,6,7,8,9,10,11,14,17,21,22,23,25,99].filter(n => !p.numbers.includes(n)), 3).map(n => `${n}`)].slice(0, 4)), answer: `${num}` };
    },
    () => ({ question: `كم مباراة لعب ${p.nameAr} تقريباً؟`, options: shuffleArr([`${p.matches}`, `${p.matches + 150}`, `${Math.max(50, p.matches - 200)}`, `${p.matches + 300}`]), answer: `${p.matches}` }),
    () => {
      const firstClub = p.clubsAr[0];
      return { question: `ما هو أول نادي لعب فيه ${p.nameAr}؟`, options: shuffleArr([firstClub, ...pickN(players.map(x => x.clubsAr[0]).filter(c => c !== firstClub), 3)].slice(0, 4)), answer: firstClub };
    },
  ];

  let templates: typeof easyTemplates;
  if (difficulty === 'easy') templates = easyTemplates;
  else if (difficulty === 'medium') templates = [...easyTemplates, ...mediumTemplates];
  else templates = [...mediumTemplates, ...hardTemplates];

  const gen = pick(templates)();
  // Ensure 4 unique options
  const uniqueOpts = [...new Set(gen.options)];
  while (uniqueOpts.length < 4) uniqueOpts.push(`خيار ${uniqueOpts.length + 1}`);
  return { id, difficulty, question: gen.question, options: uniqueOpts.slice(0, 4), answer: gen.answer };
}

// Historic matches (kept as static since they're specific events)
export const historicMatches = [
  { id: 1, score: "8-2", year: 2020, competition: "دوري الأبطال", descAr: "بايرن ميونخ 8 - 2 برشلونة", difficulty: 'easy' as const },
  { id: 2, score: "7-1", year: 2014, competition: "كأس العالم", descAr: "ألمانيا 7 - 1 البرازيل", difficulty: 'easy' as const },
  { id: 3, score: "6-1", year: 2017, competition: "دوري الأبطال", descAr: "برشلونة 6 - 1 باريس سان جيرمان", difficulty: 'easy' as const },
  { id: 4, score: "4-0", year: 2019, competition: "دوري الأبطال", descAr: "ليفربول 4 - 0 برشلونة", difficulty: 'easy' as const },
  { id: 5, score: "5-0", year: 2010, competition: "الدوري الإسباني", descAr: "برشلونة 5 - 0 ريال مدريد", difficulty: 'medium' as const },
  { id: 6, score: "3-3", year: 2022, competition: "نهائي كأس العالم", descAr: "الأرجنتين 3 - 3 فرنسا (ركلات ترجيح)", difficulty: 'easy' as const },
  { id: 7, score: "4-1", year: 2014, competition: "نهائي دوري الأبطال", descAr: "ريال مدريد 4 - 1 أتلتيكو مدريد", difficulty: 'medium' as const },
  { id: 8, score: "5-1", year: 2018, competition: "الدوري الإسباني", descAr: "برشلونة 5 - 1 ريال مدريد", difficulty: 'hard' as const },
  { id: 9, score: "3-1", year: 2022, competition: "دوري الأبطال", descAr: "ريال مدريد 3 - 1 مانشستر سيتي", difficulty: 'medium' as const },
  { id: 10, score: "1-0", year: 2022, competition: "كأس العالم", descAr: "المغرب 1 - 0 البرتغال", difficulty: 'medium' as const },
  { id: 11, score: "3-3", year: 2005, competition: "نهائي دوري الأبطال", descAr: "ليفربول 3 - 3 ميلان (معجزة إسطنبول)", difficulty: 'hard' as const },
  { id: 12, score: "2-1", year: 2022, competition: "كأس العالم", descAr: "السعودية 2 - 1 الأرجنتين", difficulty: 'medium' as const },
  { id: 13, score: "3-0", year: 2006, competition: "نهائي دوري الأبطال", descAr: "برشلونة 2 - 1 أرسنال", difficulty: 'hard' as const },
  { id: 14, score: "4-3", year: 2018, competition: "كأس العالم", descAr: "فرنسا 4 - 3 الأرجنتين (دور الـ16)", difficulty: 'hard' as const },
  { id: 15, score: "6-1", year: 2010, competition: "كأس العالم", descAr: "ألمانيا 4 - 1 إنجلترا (دور الـ16)", difficulty: 'hard' as const },
];
