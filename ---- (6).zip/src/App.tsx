import { useState, useEffect, useCallback, useRef } from 'react';
import { players, historicMatches, generateTrueFalse, generateQuickQuestion } from './data/players';
import type { Player, GeneratedTrueFalse, GeneratedQuickQuestion } from './data/players';
import { playerVisuals, getPlayerSilhouetteStyle } from './data/playerImages';

// ==================== TYPES ====================
type GameMode =
  | 'menu' | 'career3' | 'careerNational' | 'birthPosition' | 'firstLast'
  | 'hints5' | 'rankGoals' | 'rankAssists' | 'rankTitles' | 'currentClub'
  | 'nationalTeam' | 'twoNumbers' | 'blurryPhoto' | 'transferStory'
  | 'teammate' | 'coach' | 'historicMatch' | 'quickQuiz' | 'trueFalse'
  | 'comparison' | 'firstIntl' | 'stats' | 'dailyChallenge' | 'settings' | 'multiplayer' | 'multiplayerSetup';

type Difficulty = 'easy' | 'medium' | 'hard';

interface GameState {
  score: number;
  totalQuestions: number;
  correctAnswers: number;
  currentQuestion: number;
  showResult: boolean;
  selectedAnswer: string | null;
  isCorrect: boolean | null;
  timer: number;
  streak: number;
  bestStreak: number;
}

interface MultiplayerPlayer {
  name: string;
  score: number;
  correctAnswers: number;
  totalAnswered: number;
  color: string;
}

// ==================== SOUND EFFECTS ====================
const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
let audioCtx: AudioContext | null = null;

function getAudioCtx() {
  if (!audioCtx) audioCtx = new AudioCtx();
  return audioCtx;
}

function playSound(type: 'correct' | 'wrong' | 'click' | 'win' | 'tick') {
  try {
    const ctx = getAudioCtx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    
    switch (type) {
      case 'correct':
        osc.frequency.setValueAtTime(523, ctx.currentTime);
        osc.frequency.setValueAtTime(659, ctx.currentTime + 0.1);
        osc.frequency.setValueAtTime(784, ctx.currentTime + 0.2);
        gain.gain.setValueAtTime(0.3, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.4);
        osc.start(ctx.currentTime);
        osc.stop(ctx.currentTime + 0.4);
        break;
      case 'wrong':
        osc.frequency.setValueAtTime(300, ctx.currentTime);
        osc.frequency.setValueAtTime(200, ctx.currentTime + 0.15);
        gain.gain.setValueAtTime(0.3, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.3);
        osc.start(ctx.currentTime);
        osc.stop(ctx.currentTime + 0.3);
        break;
      case 'click':
        osc.frequency.setValueAtTime(800, ctx.currentTime);
        gain.gain.setValueAtTime(0.1, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.05);
        osc.start(ctx.currentTime);
        osc.stop(ctx.currentTime + 0.05);
        break;
      case 'win':
        osc.frequency.setValueAtTime(523, ctx.currentTime);
        osc.frequency.setValueAtTime(659, ctx.currentTime + 0.15);
        osc.frequency.setValueAtTime(784, ctx.currentTime + 0.3);
        osc.frequency.setValueAtTime(1047, ctx.currentTime + 0.45);
        gain.gain.setValueAtTime(0.3, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.7);
        osc.start(ctx.currentTime);
        osc.stop(ctx.currentTime + 0.7);
        break;
      case 'tick':
        osc.frequency.setValueAtTime(1000, ctx.currentTime);
        gain.gain.setValueAtTime(0.05, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.03);
        osc.start(ctx.currentTime);
        osc.stop(ctx.currentTime + 0.03);
        break;
    }
  } catch { /* ignore audio errors */ }
}

// ==================== UTILITY FUNCTIONS ====================
function shuffleArray<T>(array: T[]): T[] {
  const shuffled = [...array];
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return shuffled;
}

function getPlayersByDifficulty(difficulty: Difficulty): Player[] {
  switch (difficulty) {
    case 'easy': return players.filter(p => p.difficulty === 'easy');
    case 'medium': return players.filter(p => p.difficulty === 'easy' || p.difficulty === 'medium');
    case 'hard': return [...players];
  }
}

function getRandomPlayersWithDifficulty(count: number, difficulty: Difficulty, exclude?: number[]): Player[] {
  let pool = getPlayersByDifficulty(difficulty);
  if (exclude) pool = pool.filter(p => !exclude.includes(p.id));
  return shuffleArray(pool).slice(0, count);
}

function getRandomPlayerWithDifficulty(difficulty: Difficulty, exclude?: number[]): Player {
  return getRandomPlayersWithDifficulty(1, difficulty, exclude)[0];
}

function loadStats() {
  try {
    const saved = localStorage.getItem('vs-football-stats');
    if (saved) return JSON.parse(saved);
  } catch { /* ignore */ }
  return { totalGames: 0, totalCorrect: 0, totalQuestions: 0, bestStreak: 0, gamesPlayed: 0 };
}

function saveStats(stats: ReturnType<typeof loadStats>) {
  localStorage.setItem('vs-football-stats', JSON.stringify(stats));
}

function loadDifficulty(): Difficulty {
  try {
    const saved = localStorage.getItem('vs-football-difficulty');
    if (saved && ['easy', 'medium', 'hard'].includes(saved)) return saved as Difficulty;
  } catch { /* ignore */ }
  return 'medium';
}

function saveDifficulty(d: Difficulty) {
  localStorage.setItem('vs-football-difficulty', d);
}

// ==================== DAILY CHALLENGE ====================
function getTodayKey(): string {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

interface DailyData {
  lastPlayedDate: string;
  streak: number;
  bestStreak: number;
  todayCompleted: boolean;
  todayScore: number;
  todayTotal: number;
}

function loadDailyData(): DailyData {
  try {
    const saved = localStorage.getItem('vs-football-daily');
    if (saved) {
      const data = JSON.parse(saved);
      const today = getTodayKey();
      // Check if streak is still active
      if (data.lastPlayedDate !== today) {
        const lastDate = new Date(data.lastPlayedDate);
        const todayDate = new Date(today);
        const diffDays = Math.floor((todayDate.getTime() - lastDate.getTime()) / (1000 * 60 * 60 * 24));
        if (diffDays > 1) {
          // Streak broken
          return { lastPlayedDate: '', streak: 0, bestStreak: data.bestStreak || 0, todayCompleted: false, todayScore: 0, todayTotal: 5 };
        }
        // New day, not played yet
        return { ...data, todayCompleted: false, todayScore: 0, todayTotal: 5 };
      }
      return data;
    }
  } catch { /* ignore */ }
  return { lastPlayedDate: '', streak: 0, bestStreak: 0, todayCompleted: false, todayScore: 0, todayTotal: 5 };
}

function saveDailyData(data: DailyData) {
  localStorage.setItem('vs-football-daily', JSON.stringify(data));
}

const playerColors = [
  'from-blue-500 to-blue-700', 'from-red-500 to-red-700', 'from-purple-500 to-purple-700',
  'from-orange-500 to-orange-700', 'from-cyan-500 to-cyan-700', 'from-pink-500 to-pink-700',
  'from-yellow-500 to-yellow-700', 'from-emerald-500 to-emerald-700',
];

const playerColorsFlat = ['#3b82f6', '#ef4444', '#a855f7', '#f97316', '#06b6d4', '#ec4899', '#eab308', '#10b981'];

const difficultyLabels: Record<Difficulty, { label: string; icon: string; desc: string }> = {
  easy: { label: 'سهل', icon: '🟢', desc: 'لاعبون مشهورون جداً - أسئلة بسيطة' },
  medium: { label: 'متوسط', icon: '🟡', desc: 'أسئلة تحتاج معرفة متوسطة' },
  hard: { label: 'صعب', icon: '🔴', desc: 'أسئلة صعبة ومعلومات دقيقة' },
};

const gameModes: { id: GameMode; icon: string; title: string; desc: string }[] = [
  { id: 'career3', icon: '🏟️', title: 'مسيرة 3 أندية', desc: 'خمن اللاعب من 3 أندية' },
  { id: 'careerNational', icon: '🌍', title: 'منتخب + ناديين', desc: 'خمن من المنتخب وناديين' },
  { id: 'birthPosition', icon: '📅', title: 'سنة + مركز', desc: 'خمن من سنة الميلاد والمركز' },
  { id: 'firstLast', icon: '🔄', title: 'أول وآخر نادي', desc: 'خمن من أول وآخر نادي' },
  { id: 'hints5', icon: '💡', title: '5 تلميحات', desc: 'خمن من تلميحات تدريجية' },
  { id: 'rankGoals', icon: '⚽', title: 'رتّب بالأهداف', desc: 'رتّب اللاعبين حسب الأهداف' },
  { id: 'rankAssists', icon: '🎯', title: 'رتّب بالأسيست', desc: 'رتّب حسب التمريرات الحاسمة' },
  { id: 'rankTitles', icon: '🏆', title: 'رتّب بالبطولات', desc: 'رتّب حسب عدد الألقاب' },
  { id: 'currentClub', icon: '🎽', title: 'النادي الحالي', desc: 'خمن من النادي الحالي فقط' },
  { id: 'nationalTeam', icon: '🏴', title: 'المنتخب فقط', desc: 'خمن من المنتخب فقط' },
  { id: 'twoNumbers', icon: '🔢', title: 'رقمين', desc: 'خمن من رقمين لعب بهما' },
  { id: 'blurryPhoto', icon: '🖼️', title: 'صورة ضبابية', desc: 'خمن من صورة مشوشة' },
  { id: 'transferStory', icon: '💰', title: 'قصة انتقال', desc: 'خمن من قصة الانتقال' },
  { id: 'teammate', icon: '🤝', title: 'من لعب معه؟', desc: 'خمن زميل اللاعب' },
  { id: 'coach', icon: '📋', title: 'من درّبه؟', desc: 'خمن المدرب' },
  { id: 'historicMatch', icon: '📜', title: 'مباراة تاريخية', desc: 'خمن المباراة من النتيجة' },
  { id: 'quickQuiz', icon: '⚡', title: 'أسئلة سريعة', desc: '3 أسئلة متتالية سريعة' },
  { id: 'trueFalse', icon: '✅', title: 'صح أو خطأ', desc: 'حدد صحة العبارة' },
  { id: 'comparison', icon: '⚔️', title: 'مقارنات', desc: 'من لديه إحصائيات أكثر؟' },
  { id: 'firstIntl', icon: '🌟', title: 'أول مباراة دولية', desc: 'خمن من سنة أول مباراة' },
];

// ==================== MAIN APP ====================
export function App() {
  const [gameMode, setGameMode] = useState<GameMode>('menu');
  const [difficulty, setDifficulty] = useState<Difficulty>(loadDifficulty());
  const [gameState, setGameState] = useState<GameState>({
    score: 0, totalQuestions: 0, correctAnswers: 0, currentQuestion: 0,
    showResult: false, selectedAnswer: null, isCorrect: null, timer: 30, streak: 0, bestStreak: 0,
  });
  const [stats, setStats] = useState(loadStats());
  const [showStats, setShowStats] = useState(false);

  const [multiplayerPlayers, setMultiplayerPlayers] = useState<MultiplayerPlayer[]>([]);
  const [currentPlayerIndex, setCurrentPlayerIndex] = useState(0);
  const [multiplayerRound, setMultiplayerRound] = useState(0);
  const [totalRounds, setTotalRounds] = useState(5);
  const [multiplayerGameMode, setMultiplayerGameMode] = useState<GameMode>('career3');
  const [multiplayerFinished, setMultiplayerFinished] = useState(false);
  const [showTurnTransition, setShowTurnTransition] = useState(false);
  const [multiplayerDifficulty, setMultiplayerDifficulty] = useState<Difficulty>('medium');

  const [dailyData, setDailyData] = useState<DailyData>(loadDailyData());

  const changeDifficulty = (d: Difficulty) => { setDifficulty(d); saveDifficulty(d); };

  const resetGame = useCallback(() => {
    setGameState({ score: 0, totalQuestions: 0, correctAnswers: 0, currentQuestion: 0, showResult: false, selectedAnswer: null, isCorrect: null, timer: 30, streak: 0, bestStreak: 0 });
  }, []);

  const goToMenu = useCallback(() => {
    setGameMode('menu'); resetGame(); setMultiplayerFinished(false); setShowTurnTransition(false);
  }, [resetGame]);

  const handleCorrect = useCallback(() => {
    playSound('correct');
    setGameState(prev => {
      const ns = prev.streak + 1;
      return { ...prev, score: prev.score + 10, correctAnswers: prev.correctAnswers + 1, isCorrect: true, showResult: true, streak: ns, bestStreak: Math.max(prev.bestStreak, ns) };
    });
    setStats((prev: ReturnType<typeof loadStats>) => { const n = { ...prev, totalCorrect: prev.totalCorrect + 1, totalQuestions: prev.totalQuestions + 1 }; saveStats(n); return n; });
  }, []);

  const handleWrong = useCallback(() => {
    playSound('wrong');
    setGameState(prev => ({ ...prev, isCorrect: false, showResult: true, streak: 0 }));
    setStats((prev: ReturnType<typeof loadStats>) => { const n = { ...prev, totalQuestions: prev.totalQuestions + 1 }; saveStats(n); return n; });
  }, []);

  const handleMultiplayerCorrect = useCallback(() => {
    playSound('correct');
    setMultiplayerPlayers(prev => { const u = [...prev]; u[currentPlayerIndex] = { ...u[currentPlayerIndex], score: u[currentPlayerIndex].score + 10, correctAnswers: u[currentPlayerIndex].correctAnswers + 1, totalAnswered: u[currentPlayerIndex].totalAnswered + 1 }; return u; });
  }, [currentPlayerIndex]);

  const handleMultiplayerWrong = useCallback(() => {
    playSound('wrong');
    setMultiplayerPlayers(prev => { const u = [...prev]; u[currentPlayerIndex] = { ...u[currentPlayerIndex], totalAnswered: u[currentPlayerIndex].totalAnswered + 1 }; return u; });
  }, [currentPlayerIndex]);

  const advanceMultiplayerTurn = useCallback(() => {
    const next = currentPlayerIndex + 1;
    if (next >= multiplayerPlayers.length) {
      const nr = multiplayerRound + 1;
      if (nr >= totalRounds) { setMultiplayerFinished(true); playSound('win'); }
      else { setMultiplayerRound(nr); setCurrentPlayerIndex(0); setShowTurnTransition(true); }
    } else { setCurrentPlayerIndex(next); setShowTurnTransition(true); }
  }, [currentPlayerIndex, multiplayerPlayers.length, multiplayerRound, totalRounds]);

  return (
    <div className="min-h-screen text-white" dir="rtl">
      <header className="sticky top-0 z-50 glass-card border-b border-white/10">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3 cursor-pointer" onClick={goToMenu}>
            <span className="text-3xl">⚽</span>
            <div><h1 className="text-xl font-black" style={{color: '#f0c040'}}>VS Football Quiz</h1><p className="text-xs text-white/50">تحدى معلوماتك الكروية</p></div>
          </div>
          <div className="flex items-center gap-2">
            {gameMode !== 'menu' && gameMode !== 'settings' && gameMode !== 'multiplayerSetup' && gameMode !== 'multiplayer' && (
              <div className="flex items-center gap-3 ml-2">
                <div className="text-center"><div className="text-lg font-bold" style={{color: '#f0c040'}}>{gameState.score}</div><div className="text-[10px] text-white/50">النقاط</div></div>
                <div className="text-center"><div className="text-lg font-bold text-green-400">🔥 {gameState.streak}</div><div className="text-[10px] text-white/50">متتالية</div></div>
              </div>
            )}
            <button onClick={() => setShowStats(!showStats)} className="p-2 rounded-lg bg-white/10 hover:bg-white/20 transition">📊</button>
            <button onClick={() => setGameMode('settings')} className="p-2 rounded-lg bg-white/10 hover:bg-white/20 transition">⚙️</button>
          </div>
        </div>
      </header>

      {showStats && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 p-4" onClick={() => setShowStats(false)}>
          <div className="glass-card rounded-2xl p-6 max-w-md w-full animate-bounceIn" onClick={e => e.stopPropagation()}>
            <h2 className="text-2xl font-bold mb-4" style={{color: '#f0c040'}}>📊 إحصائياتك</h2>
            <div className="grid grid-cols-2 gap-4">
              <StatCard label="إجمالي الأسئلة" value={stats.totalQuestions} />
              <StatCard label="الإجابات الصحيحة" value={stats.totalCorrect} />
              <StatCard label="نسبة النجاح" value={stats.totalQuestions > 0 ? `${Math.round((stats.totalCorrect / stats.totalQuestions) * 100)}%` : '0%'} />
              <StatCard label="أفضل سلسلة" value={stats.bestStreak || 0} />
            </div>
            <button onClick={() => setShowStats(false)} className="btn-primary w-full mt-4 text-center">إغلاق</button>
          </div>
        </div>
      )}

      <main className="max-w-6xl mx-auto px-4 py-6">
        {gameMode === 'menu' && <MainMenu onSelect={(mode) => { resetGame(); setGameMode(mode); }} difficulty={difficulty} onChangeDifficulty={changeDifficulty} dailyData={dailyData} />}
        {gameMode === 'settings' && <SettingsPage onBack={goToMenu} difficulty={difficulty} onChangeDifficulty={changeDifficulty} />}
        {gameMode === 'multiplayerSetup' && (
          <MultiplayerSetup onBack={goToMenu} onStart={(mP, r, m, d) => {
            setMultiplayerPlayers(mP); setTotalRounds(r); setMultiplayerGameMode(m); setMultiplayerDifficulty(d);
            setCurrentPlayerIndex(0); setMultiplayerRound(0); setMultiplayerFinished(false); setShowTurnTransition(true); setGameMode('multiplayer');
          }} />
        )}
        {gameMode === 'multiplayer' && (
          multiplayerFinished ? <MultiplayerResults players={multiplayerPlayers} onBack={goToMenu} />
          : showTurnTransition ? <TurnTransition player={multiplayerPlayers[currentPlayerIndex]} round={multiplayerRound + 1} totalRounds={totalRounds} playerIndex={currentPlayerIndex} onContinue={() => setShowTurnTransition(false)} />
          : <MultiplayerGamePlay gameMode={multiplayerGameMode} currentPlayer={multiplayerPlayers[currentPlayerIndex]} currentPlayerIndex={currentPlayerIndex} allPlayers={multiplayerPlayers} round={multiplayerRound} totalRounds={totalRounds} difficulty={multiplayerDifficulty} onCorrect={handleMultiplayerCorrect} onWrong={handleMultiplayerWrong} onNext={advanceMultiplayerTurn} onBack={goToMenu} />
        )}

        {gameMode === 'career3' && <Career3Game state={gameState} onCorrect={handleCorrect} onWrong={handleWrong} onBack={goToMenu} setState={setGameState} difficulty={difficulty} />}
        {gameMode === 'careerNational' && <CareerNationalGame state={gameState} onCorrect={handleCorrect} onWrong={handleWrong} onBack={goToMenu} setState={setGameState} difficulty={difficulty} />}
        {gameMode === 'birthPosition' && <BirthPositionGame state={gameState} onCorrect={handleCorrect} onWrong={handleWrong} onBack={goToMenu} setState={setGameState} difficulty={difficulty} />}
        {gameMode === 'firstLast' && <FirstLastGame state={gameState} onCorrect={handleCorrect} onWrong={handleWrong} onBack={goToMenu} setState={setGameState} difficulty={difficulty} />}
        {gameMode === 'hints5' && <Hints5Game state={gameState} onCorrect={handleCorrect} onWrong={handleWrong} onBack={goToMenu} setState={setGameState} difficulty={difficulty} />}
        {gameMode === 'rankGoals' && <RankGame state={gameState} onCorrect={handleCorrect} onWrong={handleWrong} onBack={goToMenu} setState={setGameState} sortKey="goals" title="رتّب حسب الأهداف" difficulty={difficulty} />}
        {gameMode === 'rankAssists' && <RankGame state={gameState} onCorrect={handleCorrect} onWrong={handleWrong} onBack={goToMenu} setState={setGameState} sortKey="assists" title="رتّب حسب الأسيست" difficulty={difficulty} />}
        {gameMode === 'rankTitles' && <RankGame state={gameState} onCorrect={handleCorrect} onWrong={handleWrong} onBack={goToMenu} setState={setGameState} sortKey="titles" title="رتّب حسب البطولات" difficulty={difficulty} />}
        {gameMode === 'currentClub' && <CurrentClubGame state={gameState} onCorrect={handleCorrect} onWrong={handleWrong} onBack={goToMenu} setState={setGameState} difficulty={difficulty} />}
        {gameMode === 'nationalTeam' && <NationalTeamGame state={gameState} onCorrect={handleCorrect} onWrong={handleWrong} onBack={goToMenu} setState={setGameState} difficulty={difficulty} />}
        {gameMode === 'twoNumbers' && <TwoNumbersGame state={gameState} onCorrect={handleCorrect} onWrong={handleWrong} onBack={goToMenu} setState={setGameState} difficulty={difficulty} />}
        {gameMode === 'blurryPhoto' && <BlurryPhotoGame state={gameState} onCorrect={handleCorrect} onWrong={handleWrong} onBack={goToMenu} setState={setGameState} difficulty={difficulty} />}
        {gameMode === 'transferStory' && <TransferStoryGame state={gameState} onCorrect={handleCorrect} onWrong={handleWrong} onBack={goToMenu} setState={setGameState} difficulty={difficulty} />}
        {gameMode === 'teammate' && <TeammateGame state={gameState} onCorrect={handleCorrect} onWrong={handleWrong} onBack={goToMenu} setState={setGameState} difficulty={difficulty} />}
        {gameMode === 'coach' && <CoachGame state={gameState} onCorrect={handleCorrect} onWrong={handleWrong} onBack={goToMenu} setState={setGameState} difficulty={difficulty} />}
        {gameMode === 'historicMatch' && <HistoricMatchGame state={gameState} onCorrect={handleCorrect} onWrong={handleWrong} onBack={goToMenu} setState={setGameState} difficulty={difficulty} />}
        {gameMode === 'quickQuiz' && <QuickQuizGame state={gameState} onCorrect={handleCorrect} onWrong={handleWrong} onBack={goToMenu} setState={setGameState} difficulty={difficulty} />}
        {gameMode === 'trueFalse' && <TrueFalseGame state={gameState} onCorrect={handleCorrect} onWrong={handleWrong} onBack={goToMenu} setState={setGameState} difficulty={difficulty} />}
        {gameMode === 'comparison' && <ComparisonGame state={gameState} onCorrect={handleCorrect} onWrong={handleWrong} onBack={goToMenu} setState={setGameState} difficulty={difficulty} />}
        {gameMode === 'firstIntl' && <FirstIntlGame state={gameState} onCorrect={handleCorrect} onWrong={handleWrong} onBack={goToMenu} setState={setGameState} difficulty={difficulty} />}
        {gameMode === 'dailyChallenge' && <DailyChallenge dailyData={dailyData} setDailyData={setDailyData} difficulty={difficulty} onBack={goToMenu} />}
      </main>
    </div>
  );
}

function StatCard({ label, value }: { label: string; value: string | number }) {
  return (<div className="glass-card rounded-xl p-4 text-center"><div className="text-2xl font-bold" style={{color: '#f0c040'}}>{value}</div><div className="text-xs text-white/60 mt-1">{label}</div></div>);
}

function DifficultySelector({ difficulty, onChange, compact = false }: { difficulty: Difficulty; onChange: (d: Difficulty) => void; compact?: boolean }) {
  return (
    <div className={`flex gap-2 ${compact ? '' : 'flex-wrap'}`}>
      {(['easy', 'medium', 'hard'] as Difficulty[]).map(d => (
        <button key={d} onClick={() => { onChange(d); playSound('click'); }}
          className={`${compact ? 'px-3 py-2 text-sm' : 'px-4 py-3'} rounded-xl font-bold transition-all flex items-center gap-2 ${
            difficulty === d
              ? d === 'easy' ? 'bg-green-500/30 border-2 border-green-500 scale-105' : d === 'medium' ? 'bg-yellow-500/30 border-2 border-yellow-500 scale-105' : 'bg-red-500/30 border-2 border-red-500 scale-105'
              : 'bg-white/10 border-2 border-white/10 hover:bg-white/20'}`}>
          <span>{difficultyLabels[d].icon}</span><span>{difficultyLabels[d].label}</span>
        </button>
      ))}
    </div>
  );
}

// ==================== SETTINGS ====================
function SettingsPage({ onBack, difficulty, onChangeDifficulty }: { onBack: () => void; difficulty: Difficulty; onChangeDifficulty: (d: Difficulty) => void }) {
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  return (
    <div className="animate-fadeIn max-w-2xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <button onClick={onBack} className="btn-secondary text-sm px-4 py-2">← القائمة</button>
        <h2 className="text-2xl font-bold">⚙️ الإعدادات</h2><div />
      </div>
      <div className="glass-card rounded-2xl p-6 mb-6 animate-slideUp">
        <h3 className="text-xl font-bold mb-2" style={{color: '#f0c040'}}>🎯 مستوى الصعوبة</h3>
        <p className="text-white/50 text-sm mb-4">{difficultyLabels[difficulty].desc}</p>
        <DifficultySelector difficulty={difficulty} onChange={onChangeDifficulty} />
      </div>
      <div className="glass-card rounded-2xl p-6 mb-6 animate-slideUp" style={{animationDelay: '100ms'}}>
        <h3 className="text-xl font-bold mb-4" style={{color: '#f0c040'}}>ℹ️ حول اللعبة</h3>
        <div className="text-center mb-6">
          <div className="text-6xl mb-4">⚽</div>
          <h4 className="text-2xl font-black mb-2" style={{color: '#f0c040'}}>VS Football Quiz</h4>
          <p className="text-white/60 mb-1">النسخة 3.0.0</p>
          <p className="text-white/50 text-sm">أسئلة لا نهائية يتم توليدها ديناميكياً!</p>
        </div>
        <div className="glass-card rounded-xl p-5 mb-4" style={{background: 'linear-gradient(135deg, rgba(212,160,23,0.1), rgba(212,160,23,0.05))'}}>
          <h5 className="font-bold mb-3 text-center" style={{color: '#f0c040'}}>👨‍💻 تم التطوير بواسطة</h5>
          <div className="flex items-center justify-center gap-8">
            <div className="text-center"><div className="w-16 h-16 rounded-full bg-gradient-to-br from-blue-500 to-blue-700 flex items-center justify-center text-2xl font-black mb-2 mx-auto shadow-lg">M</div><p className="font-bold text-lg">Malek</p><p className="text-xs text-white/50">مطوّر</p></div>
            <div className="text-3xl" style={{color: '#f0c040'}}>&</div>
            <div className="text-center"><div className="w-16 h-16 rounded-full bg-gradient-to-br from-emerald-500 to-emerald-700 flex items-center justify-center text-2xl font-black mb-2 mx-auto shadow-lg">A</div><p className="font-bold text-lg">Ahmed</p><p className="text-xs text-white/50">مطوّر</p></div>
          </div>
        </div>
      </div>
      <div className="glass-card rounded-2xl p-6 mb-6 animate-slideUp" style={{animationDelay: '200ms'}}>
        <h3 className="text-xl font-bold mb-4" style={{color: '#f0c040'}}>🎮 معلومات اللعبة</h3>
        <div className="grid grid-cols-2 gap-4">
          <div className="glass-card rounded-xl p-4 text-center"><div className="text-3xl mb-2">🎯</div><div className="text-2xl font-bold" style={{color: '#f0c040'}}>20</div><div className="text-xs text-white/60">نمط لعب</div></div>
          <div className="glass-card rounded-xl p-4 text-center"><div className="text-3xl mb-2">♾️</div><div className="text-2xl font-bold" style={{color: '#f0c040'}}>∞</div><div className="text-xs text-white/60">أسئلة لا نهائية</div></div>
          <div className="glass-card rounded-xl p-4 text-center"><div className="text-3xl mb-2">⚽</div><div className="text-2xl font-bold" style={{color: '#f0c040'}}>{players.length}</div><div className="text-xs text-white/60">لاعب</div></div>
          <div className="glass-card rounded-xl p-4 text-center"><div className="text-3xl mb-2">🔊</div><div className="text-2xl font-bold" style={{color: '#f0c040'}}>5</div><div className="text-xs text-white/60">مؤثرات صوتية</div></div>
        </div>
      </div>
      <div className="glass-card rounded-2xl p-6 mb-6 animate-slideUp" style={{animationDelay: '300ms'}}>
        <h3 className="text-xl font-bold mb-4" style={{color: '#f0c040'}}>🗂️ إدارة البيانات</h3>
        {!showResetConfirm ? (
          <button onClick={() => setShowResetConfirm(true)} className="w-full py-3 rounded-xl bg-red-500/20 border-2 border-red-500/30 text-red-400 font-bold hover:bg-red-500/30 transition">🗑️ مسح جميع البيانات</button>
        ) : (
          <div className="text-center"><p className="text-red-400 mb-3 font-bold">⚠️ هل أنت متأكد؟</p><div className="flex gap-3"><button onClick={() => { localStorage.clear(); window.location.reload(); }} className="flex-1 py-3 rounded-xl bg-red-500/30 border-2 border-red-500 text-red-400 font-bold">نعم</button><button onClick={() => setShowResetConfirm(false)} className="flex-1 py-3 rounded-xl bg-white/10 border-2 border-white/20 font-bold">إلغاء</button></div></div>
        )}
      </div>
      <div className="text-center mt-6 text-white/30 text-xs"><p>صنعت بواسطة Malek & Ahmed</p></div>
    </div>
  );
}

// ==================== MULTIPLAYER SETUP ====================
function MultiplayerSetup({ onBack, onStart }: { onBack: () => void; onStart: (players: MultiplayerPlayer[], rounds: number, gameMode: GameMode, difficulty: Difficulty) => void }) {
  const [numPlayers, setNumPlayers] = useState(2);
  const [playerNames, setPlayerNames] = useState<string[]>(['', '']);
  const [rounds, setRounds] = useState(5);
  const [selectedMode, setSelectedMode] = useState<GameMode>('career3');
  const [selectedDifficulty, setSelectedDifficulty] = useState<Difficulty>('medium');
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);

  useEffect(() => { setPlayerNames(Array.from({ length: numPlayers }, (_, i) => playerNames[i] || '')); }, [numPlayers]);

  const handleStart = () => {
    playSound('click');
    onStart(playerNames.map((name, i) => ({ name: name.trim() || `لاعب ${i + 1}`, score: 0, correctAnswers: 0, totalAnswered: 0, color: playerColors[i % playerColors.length] })), rounds, selectedMode, selectedDifficulty);
  };

  const validModes = gameModes.filter(m => !['rankGoals', 'rankAssists', 'rankTitles'].includes(m.id));

  return (
    <div className="animate-fadeIn max-w-2xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <button onClick={onBack} className="btn-secondary text-sm px-4 py-2">← القائمة</button>
        <h2 className="text-2xl font-bold">👥 تحدي الأصدقاء</h2><div />
      </div>
      <div className="glass-card rounded-2xl p-6 mb-4 animate-slideUp">
        <h3 className="font-bold mb-4" style={{color: '#f0c040'}}>👥 عدد اللاعبين</h3>
        <div className="flex gap-2 flex-wrap">{[2,3,4,5,6,7,8].map(n => (<button key={n} onClick={() => { setNumPlayers(n); playSound('click'); }} className={`w-12 h-12 rounded-xl font-bold text-lg transition-all ${numPlayers === n ? 'bg-gradient-to-br from-yellow-500 to-yellow-700 text-black scale-110' : 'bg-white/10 hover:bg-white/20'}`}>{n}</button>))}</div>
      </div>
      <div className="glass-card rounded-2xl p-6 mb-4 animate-slideUp" style={{animationDelay: '50ms'}}>
        <h3 className="font-bold mb-4" style={{color: '#f0c040'}}>✏️ أسماء اللاعبين</h3>
        <div className="space-y-3">{playerNames.map((name, i) => (
          <div key={i} className="flex items-center gap-3">
            <div className={`w-10 h-10 rounded-full bg-gradient-to-br ${playerColors[i % playerColors.length]} flex items-center justify-center font-bold text-sm flex-shrink-0`}>{i + 1}</div>
            <input ref={el => { inputRefs.current[i] = el; }} type="text" value={name} onChange={e => { const n = [...playerNames]; n[i] = e.target.value; setPlayerNames(n); }} placeholder={`لاعب ${i + 1}`}
              className="flex-1 bg-white/10 border-2 border-white/15 rounded-xl px-4 py-3 text-white placeholder-white/30 focus:border-yellow-500/50 focus:outline-none transition"
              onKeyDown={e => { if (e.key === 'Enter' && i < numPlayers - 1) inputRefs.current[i + 1]?.focus(); }} />
          </div>
        ))}</div>
      </div>
      <div className="glass-card rounded-2xl p-6 mb-4 animate-slideUp" style={{animationDelay: '100ms'}}>
        <h3 className="font-bold mb-4" style={{color: '#f0c040'}}>🎯 مستوى الصعوبة</h3>
        <DifficultySelector difficulty={selectedDifficulty} onChange={setSelectedDifficulty} />
      </div>
      <div className="glass-card rounded-2xl p-6 mb-4 animate-slideUp" style={{animationDelay: '150ms'}}>
        <h3 className="font-bold mb-4" style={{color: '#f0c040'}}>🔄 عدد الجولات</h3>
        <div className="flex gap-2 flex-wrap">{[3,5,7,10,15,20].map(n => (<button key={n} onClick={() => { setRounds(n); playSound('click'); }} className={`px-5 py-3 rounded-xl font-bold transition-all ${rounds === n ? 'bg-gradient-to-br from-yellow-500 to-yellow-700 text-black scale-110' : 'bg-white/10 hover:bg-white/20'}`}>{n}</button>))}</div>
      </div>
      <div className="glass-card rounded-2xl p-6 mb-6 animate-slideUp" style={{animationDelay: '200ms'}}>
        <h3 className="font-bold mb-4" style={{color: '#f0c040'}}>🎮 نمط اللعب</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-2">{validModes.map(mode => (
          <button key={mode.id} onClick={() => { setSelectedMode(mode.id); playSound('click'); }}
            className={`p-3 rounded-xl text-center transition-all text-sm ${selectedMode === mode.id ? 'bg-gradient-to-br from-yellow-500/30 to-yellow-700/30 border-2 border-yellow-500 scale-[1.02]' : 'bg-white/5 border-2 border-white/10 hover:bg-white/10'}`}>
            <span className="text-xl">{mode.icon}</span><p className="font-bold mt-1 text-xs">{mode.title}</p>
          </button>
        ))}</div>
      </div>
      <button onClick={handleStart} className="btn-primary w-full text-center text-xl py-4">🎮 ابدأ التحدي!</button>
    </div>
  );
}

function TurnTransition({ player, round, totalRounds, playerIndex, onContinue }: { player: MultiplayerPlayer; round: number; totalRounds: number; playerIndex: number; onContinue: () => void }) {
  return (
    <div className="flex items-center justify-center min-h-[60vh]"><div className="text-center animate-bounceIn max-w-md w-full"><div className="glass-card rounded-3xl p-8">
      <div className="text-sm text-white/50 mb-4">الجولة {round} من {totalRounds}</div>
      <div className={`w-24 h-24 rounded-full bg-gradient-to-br ${player.color} flex items-center justify-center text-4xl font-black mx-auto mb-4 shadow-xl`}>{player.name.charAt(0).toUpperCase()}</div>
      <h2 className="text-3xl font-black mb-2" style={{color: playerColorsFlat[playerIndex % playerColorsFlat.length]}}>{player.name}</h2>
      <p className="text-white/60 mb-2">دورك الآن!</p>
      <div className="flex items-center justify-center gap-4 mb-6">
        <div className="text-center"><div className="text-xl font-bold" style={{color: '#f0c040'}}>{player.score}</div><div className="text-xs text-white/50">النقاط</div></div>
        <div className="text-center"><div className="text-xl font-bold text-green-400">{player.correctAnswers}</div><div className="text-xs text-white/50">صحيحة</div></div>
      </div>
      <p className="text-white/40 text-sm mb-6">مرر الجهاز إلى {player.name} 📱</p>
      <button onClick={() => { playSound('click'); onContinue(); }} className="btn-primary w-full text-center text-lg py-4">أنا جاهز! 🎮</button>
    </div></div></div>
  );
}

// ==================== MULTIPLAYER GAMEPLAY ====================
function MultiplayerGamePlay({ gameMode, currentPlayer, currentPlayerIndex, allPlayers, round, totalRounds, difficulty, onCorrect, onWrong, onNext, onBack }: {
  gameMode: GameMode; currentPlayer: MultiplayerPlayer; currentPlayerIndex: number; allPlayers: MultiplayerPlayer[];
  round: number; totalRounds: number; difficulty: Difficulty;
  onCorrect: () => void; onWrong: () => void; onNext: () => void; onBack: () => void;
}) {
  const [qKey, setQKey] = useState(0);
  const [qData, setQData] = useState<{ options: string[]; correctAnswer: string; question: React.ReactNode } | null>(null);
  const [selected, setSelected] = useState<string | null>(null);
  const [answered, setAnswered] = useState(false);

  const generateQuestion = useCallback(() => {
    // Generate question based on game mode
    if (gameMode === 'trueFalse') {
      const tf = generateTrueFalse(difficulty);
      const ca = tf.answer ? 'صح ✅' : 'خطأ ❌';
      setQData({ options: ['صح ✅', 'خطأ ❌'], correctAnswer: ca,
        question: (<div><p className="text-white/60 mb-4 text-lg">هل هذه العبارة صحيحة؟</p><p className="text-2xl font-bold" style={{color: '#f0c040'}}>&quot;{tf.statement}&quot;</p></div>) });
      return;
    }
    if (gameMode === 'quickQuiz') {
      const qq = generateQuickQuestion(difficulty);
      setQData({ options: qq.options, correctAnswer: qq.answer,
        question: (<p className="text-xl font-bold" style={{color: '#f0c040'}}>{qq.question}</p>) });
      return;
    }
    if (gameMode === 'historicMatch') {
      const filtered = historicMatches.filter(m => difficulty === 'easy' ? m.difficulty === 'easy' : difficulty === 'medium' ? m.difficulty !== 'hard' : true);
      const m = filtered[Math.floor(Math.random() * filtered.length)];
      const wrong = shuffleArray(historicMatches.filter(x => x.id !== m.id)).slice(0, 3);
      setQData({ options: shuffleArray([m.descAr, ...wrong.map(x => x.descAr)]), correctAnswer: m.descAr,
        question: (<div><p className="text-white/60 mb-4 text-lg">ما هي المباراة؟</p><div className="text-5xl font-black" style={{color: '#f0c040'}}>{m.score}</div><div className="text-sm text-white/40 mt-2">{m.competition} - {m.year}</div></div>) });
      return;
    }

    // Player-based modes
    const p = getRandomPlayerWithDifficulty(difficulty);
    const wrongPlayers = getRandomPlayersWithDifficulty(3, difficulty, [p.id]);
    const options = shuffleArray([p.nameAr, ...wrongPlayers.map(wp => wp.nameAr)]);
    let question: React.ReactNode;

    switch (gameMode) {
      case 'careerNational': {
        const twoClubs = p.clubsAr.slice(0, 2);
        question = (<div><p className="text-white/60 mb-4">من هو اللاعب؟</p><div className="text-xl font-bold mb-2">🏴 {p.nationalityAr}</div><div className="flex items-center justify-center gap-3 text-lg font-bold">{twoClubs.map((c, i) => (<span key={i}><span style={{color: '#f0c040'}}>{c}</span>{i < twoClubs.length - 1 && <span className="text-white/30"> + </span>}</span>))}</div></div>);
        break;
      }
      case 'transferStory':
        question = (<div><p className="text-white/60 mb-4">من صاحب هذا الانتقال؟</p><div className="glass-card rounded-xl p-4 inline-block"><span className="text-xl" style={{color: '#f0c040'}}>💰 &quot;{p.transferStoryAr}&quot;</span></div></div>);
        break;
      case 'firstIntl':
        question = (<div><p className="text-white/60 mb-4">من لعب أول مباراة دولية في هذه السنة؟</p><div className="text-3xl font-black mb-2" style={{color: '#f0c040'}}>🌟 {p.firstIntlYear}</div><div className="text-lg text-white/50">مع منتخب {p.nationalityAr}</div></div>);
        break;
      case 'currentClub':
        question = (<div><p className="text-white/60 mb-4">من يلعب في هذا النادي؟</p><div className="text-3xl font-black" style={{color: '#f0c040'}}>🏟️ {p.currentClubAr}</div></div>);
        break;
      case 'birthPosition':
        question = (<div><p className="text-white/60 mb-4">من هو اللاعب؟</p><div className="flex items-center justify-center gap-6 text-2xl font-bold"><span>📅 <span style={{color: '#f0c040'}}>{p.birthYear}</span></span><span className="text-white/30">|</span><span>⚽ <span style={{color: '#f0c040'}}>{p.positionAr}</span></span></div><div className="mt-3 text-sm text-white/40">🏴 {p.nationalityAr}</div></div>);
        break;
      default: {
        const clubs = p.clubsAr.length >= 3 ? [p.clubsAr[0], p.clubsAr[Math.floor(p.clubsAr.length/2)], p.clubsAr[p.clubsAr.length - 1]] : p.clubsAr;
        question = (<div><p className="text-white/60 mb-4">من هو اللاعب؟</p><div className="flex items-center justify-center gap-3 flex-wrap text-xl font-bold">{clubs.map((c, i) => (<span key={i}><span style={{color: '#f0c040'}}>{c}</span>{i < clubs.length - 1 && <span className="text-white/30"> → </span>}</span>))}</div></div>);
      }
    }
    setQData({ options, correctAnswer: p.nameAr, question });
  }, [gameMode, difficulty, qKey]);

  useEffect(() => { generateQuestion(); }, [generateQuestion]);
  useEffect(() => { setSelected(null); setAnswered(false); }, [qKey]);
  if (!qData) return null;

  const handleSelect = (option: string) => {
    if (answered) return;
    playSound('click');
    setSelected(option); setAnswered(true);
    if (option === qData.correctAnswer) onCorrect(); else onWrong();
  };

  return (
    <div className="animate-fadeIn">
      <div className="glass-card rounded-2xl p-4 mb-4">
        <div className="flex items-center justify-between mb-3">
          <button onClick={onBack} className="text-sm text-white/50 hover:text-white">← خروج</button>
          <span className="text-sm text-white/50">الجولة {round + 1} من {totalRounds}</span>
        </div>
        <div className="flex items-center gap-2 overflow-x-auto pb-2">{allPlayers.map((pl, i) => (
          <div key={i} className={`flex items-center gap-2 px-3 py-2 rounded-xl flex-shrink-0 transition-all ${i === currentPlayerIndex ? 'bg-white/15 border-2 scale-105' : 'bg-white/5 border-2 border-transparent'}`} style={{borderColor: i === currentPlayerIndex ? playerColorsFlat[i] : 'transparent'}}>
            <div className={`w-8 h-8 rounded-full bg-gradient-to-br ${pl.color} flex items-center justify-center text-xs font-bold flex-shrink-0`}>{pl.name.charAt(0)}</div>
            <div><div className="text-xs font-bold">{pl.name}</div><div className="text-xs" style={{color: '#f0c040'}}>{pl.score}</div></div>
          </div>
        ))}</div>
      </div>
      <div className="glass-card rounded-xl p-3 mb-4 flex items-center justify-between" style={{borderColor: playerColorsFlat[currentPlayerIndex], borderWidth: '2px'}}>
        <div className="flex items-center gap-2">
          <div className={`w-8 h-8 rounded-full bg-gradient-to-br ${currentPlayer.color} flex items-center justify-center text-sm font-bold`}>{currentPlayer.name.charAt(0)}</div>
          <span className="font-bold">{currentPlayer.name}</span>
        </div>
        <span className="font-bold" style={{color: '#f0c040'}}>{currentPlayer.score} نقطة</span>
      </div>
      <div className="glass-card rounded-2xl p-6 mb-6 text-center animate-slideUp">{qData.question}</div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-6">{qData.options.map((option, i) => (
        <button key={i} onClick={() => handleSelect(option)}
          className={`option-btn ${answered && option === qData.correctAnswer ? 'correct' : ''} ${answered && option === selected && option !== qData.correctAnswer ? 'wrong' : ''}`}
          disabled={answered}>{option}</button>
      ))}</div>
      {answered && (
        <div className="text-center animate-bounceIn">
          <div className={`text-xl font-bold mb-3 ${selected === qData.correctAnswer ? 'text-green-400' : 'text-red-400'}`}>
            {selected === qData.correctAnswer ? '✅ إجابة صحيحة! +10' : `❌ خطأ! الجواب: ${qData.correctAnswer}`}
          </div>
          <button onClick={() => { setQKey(k => k + 1); onNext(); }} className="btn-primary">التالي ←</button>
        </div>
      )}
    </div>
  );
}

function MultiplayerResults({ players: mPlayers, onBack }: { players: MultiplayerPlayer[]; onBack: () => void }) {
  const sorted = [...mPlayers].sort((a, b) => b.score - a.score);
  const shareResults = () => {
    const text = `🏆 نتائج VS Football Quiz!\n\n${sorted.map((p, i) => `${i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `${i+1}.`} ${p.name}: ${p.score} (${p.correctAnswers} صحيحة)`).join('\n')}\n\n⚽ العب الآن!`;
    if (navigator.share) navigator.share({ title: 'VS Football Quiz', text }); else { navigator.clipboard.writeText(text); alert('تم نسخ النتائج!'); }
  };
  return (
    <div className="animate-fadeIn max-w-2xl mx-auto">
      <div className="text-center mb-8 animate-bounceIn"><div className="text-6xl mb-4">🏆</div><h2 className="text-3xl font-black mb-2" style={{color: '#f0c040'}}>الفائز: {sorted[0].name}!</h2><p className="text-white/60">{sorted[0].score} نقطة</p></div>
      <div className="glass-card rounded-2xl p-6 mb-6"><h3 className="text-xl font-bold mb-4 text-center" style={{color: '#f0c040'}}>📊 النتائج</h3>
        <div className="space-y-3">{sorted.map((player, i) => (
          <div key={i} className={`flex items-center justify-between p-4 rounded-xl ${i === 0 ? 'bg-yellow-500/20 border-2 border-yellow-500/50' : i === 1 ? 'bg-gray-400/10 border-2 border-gray-400/30' : i === 2 ? 'bg-orange-700/10 border-2 border-orange-700/30' : 'bg-white/5 border-2 border-white/10'}`} style={{animation: `slideUp 0.5s ease-out ${i * 100}ms both`}}>
            <div className="flex items-center gap-3">
              <span className="text-2xl">{i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `${i + 1}`}</span>
              <div className={`w-10 h-10 rounded-full bg-gradient-to-br ${player.color} flex items-center justify-center font-bold`}>{player.name.charAt(0)}</div>
              <div><div className="font-bold">{player.name}</div><div className="text-xs text-white/50">{player.correctAnswers} صحيحة من {player.totalAnswered} {player.totalAnswered > 0 && `(${Math.round((player.correctAnswers / player.totalAnswered) * 100)}%)`}</div></div>
            </div>
            <div className="text-xl font-black" style={{color: '#f0c040'}}>{player.score}</div>
          </div>
        ))}</div>
      </div>
      <div className="flex gap-3"><button onClick={onBack} className="flex-1 btn-primary text-center">🏠 القائمة</button><button onClick={shareResults} className="flex-1 btn-secondary text-center">📤 مشاركة</button></div>
    </div>
  );
}

// ==================== MAIN MENU ====================
function MainMenu({ onSelect, difficulty, onChangeDifficulty, dailyData }: { onSelect: (mode: GameMode) => void; difficulty: Difficulty; onChangeDifficulty: (d: Difficulty) => void; dailyData: DailyData }) {
  return (
    <div className="animate-fadeIn">
      <div className="text-center mb-6"><div className="text-6xl mb-4">⚽</div><h1 className="text-4xl md:text-5xl font-black mb-2" style={{color: '#f0c040'}}>VS Football Quiz</h1><p className="text-white/60 text-lg">أسئلة لا نهائية في 20 تحدي!</p></div>

      {/* Daily Challenge Banner */}
      <button onClick={() => { playSound('click'); onSelect('dailyChallenge'); }}
        className="w-full mb-6 animate-slideUp rounded-2xl p-5 text-center hover:scale-[1.01] transition-all relative overflow-hidden"
        style={{background: dailyData.todayCompleted ? 'linear-gradient(135deg, rgba(34,197,94,0.2), rgba(16,185,129,0.1))' : 'linear-gradient(135deg, rgba(212,160,23,0.2), rgba(239,68,68,0.1))', border: dailyData.todayCompleted ? '2px solid rgba(34,197,94,0.4)' : '2px solid rgba(212,160,23,0.4)'}}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="text-4xl">{dailyData.todayCompleted ? '✅' : '📅'}</div>
            <div className="text-right">
              <h3 className="text-xl font-black" style={{color: dailyData.todayCompleted ? '#22c55e' : '#f0c040'}}>
                {dailyData.todayCompleted ? 'تم إكمال تحدي اليوم!' : 'التحدي اليومي'}
              </h3>
              <p className="text-sm text-white/60">
                {dailyData.todayCompleted ? `حصلت على ${dailyData.todayScore}/5` : '5 أسئلة متنوعة يومياً'}
              </p>
            </div>
          </div>
          <div className="text-center">
            {dailyData.streak > 0 && (
              <div className="flex items-center gap-1">
                <span className="text-2xl font-black" style={{color: '#f0c040'}}>{dailyData.streak}</span>
                <span className="text-2xl">🔥</span>
              </div>
            )}
            <div className="text-xs text-white/50">أيام متتالية</div>
          </div>
        </div>
      </button>

      <div className="glass-card rounded-2xl p-4 mb-6 animate-slideUp" style={{animationDelay: '50ms'}}>
        <div className="flex items-center justify-between mb-3"><h3 className="font-bold" style={{color: '#f0c040'}}>🎯 مستوى الصعوبة</h3><span className="text-xs text-white/40">{difficultyLabels[difficulty].desc}</span></div>
        <DifficultySelector difficulty={difficulty} onChange={onChangeDifficulty} compact />
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <button onClick={() => { playSound('click'); onSelect('multiplayerSetup'); }} className="game-card rounded-2xl p-6 text-center border-2 hover:scale-[1.02] transition-all animate-slideUp" style={{borderColor: 'rgba(212,160,23,0.5)', background: 'linear-gradient(135deg, rgba(212,160,23,0.15), rgba(212,160,23,0.05))', animationDelay: '100ms'}}>
          <div className="text-4xl mb-2">👥</div><h3 className="text-xl font-black mb-1" style={{color: '#f0c040'}}>تحدي الأصدقاء</h3><p className="text-sm text-white/60">العب مع أصدقائك حتى 8 لاعبين!</p>
        </button>
        <button onClick={() => { playSound('click'); onSelect('settings'); }} className="game-card rounded-2xl p-6 text-center hover:scale-[1.02] transition-all animate-slideUp" style={{animationDelay: '150ms'}}>
          <div className="text-4xl mb-2">⚙️</div><h3 className="text-xl font-black mb-1">الإعدادات</h3><p className="text-sm text-white/60">بواسطة Malek & Ahmed</p>
        </button>
      </div>
      <div className="flex items-center gap-3 mb-4"><div className="h-px flex-1 bg-white/10"></div><span className="text-sm text-white/50 font-bold">🎮 أنماط اللعب</span><div className="h-px flex-1 bg-white/10"></div></div>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-4">{gameModes.map((mode, i) => (
        <button key={mode.id} onClick={() => { playSound('click'); onSelect(mode.id); }} className="game-card rounded-xl p-4 text-center hover:scale-[1.02] transition-all" style={{ animation: `slideUp 0.5s ease-out ${(i + 2) * 50}ms both` }}>
          <div className="text-3xl mb-2">{mode.icon}</div><h3 className="font-bold text-sm md:text-base mb-1">{mode.title}</h3><p className="text-[10px] md:text-xs text-white/50">{mode.desc}</p>
        </button>
      ))}</div>
      <div className="text-center mt-8 text-white/30 text-xs"><p>صنعت بواسطة Malek & Ahmed</p></div>
    </div>
  );
}

// ==================== GAME COMPONENTS ====================
interface GameProps {
  state: GameState; onCorrect: () => void; onWrong: () => void; onBack: () => void;
  setState: React.Dispatch<React.SetStateAction<GameState>>; difficulty: Difficulty;
}

function GameWrapper({ title, icon, children, onBack, state, difficulty }: { title: string; icon: string; children: React.ReactNode; onBack: () => void; state: GameState; difficulty: Difficulty }) {
  return (
    <div className="animate-fadeIn">
      <div className="flex items-center justify-between mb-4">
        <button onClick={onBack} className="btn-secondary text-sm px-4 py-2">← القائمة</button>
        <div className="flex items-center gap-2"><span className="text-2xl">{icon}</span><h2 className="text-lg font-bold">{title}</h2></div>
        <div className="flex items-center gap-2"><span className="text-xs">{difficultyLabels[difficulty].icon}</span><span className="font-bold text-sm" style={{color: '#f0c040'}}>{state.correctAnswers}/{state.totalQuestions}</span></div>
      </div>{children}
    </div>
  );
}

function MultipleChoice({ question, options, correctAnswer, onCorrect, onWrong, onNext, questionNumber }: {
  question: React.ReactNode; options: string[]; correctAnswer: string; onCorrect: () => void; onWrong: () => void; onNext: () => void; questionNumber: number;
}) {
  const [selected, setSelected] = useState<string | null>(null);
  const [answered, setAnswered] = useState(false);
  useEffect(() => { setSelected(null); setAnswered(false); }, [questionNumber]);
  const handleSelect = (option: string) => { if (answered) return; playSound('click'); setSelected(option); setAnswered(true); if (option === correctAnswer) onCorrect(); else onWrong(); };
  return (
    <div className="animate-slideUp">
      <div className="glass-card rounded-2xl p-6 mb-6 text-center">{question}</div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-6">{options.map((option, i) => (
        <button key={i} onClick={() => handleSelect(option)} className={`option-btn ${answered && option === correctAnswer ? 'correct' : ''} ${answered && option === selected && option !== correctAnswer ? 'wrong' : ''}`} disabled={answered}>{option}</button>
      ))}</div>
      {answered && (<div className="text-center animate-bounceIn"><div className={`text-xl font-bold mb-3 ${selected === correctAnswer ? 'text-green-400' : 'text-red-400'}`}>{selected === correctAnswer ? '✅ إجابة صحيحة!' : `❌ خطأ! الجواب: ${correctAnswer}`}</div><button onClick={onNext} className="btn-primary">السؤال التالي ←</button></div>)}
    </div>
  );
}

// Helper for standard player-based games
function usePlayerQuestion(difficulty: Difficulty) {
  const [qData, setQData] = useState<{ player: Player; options: string[] } | null>(null);
  const [qNum, setQNum] = useState(0);
  const gen = useCallback(() => {
    const p = getRandomPlayerWithDifficulty(difficulty);
    const w = getRandomPlayersWithDifficulty(3, difficulty, [p.id]);
    setQData({ player: p, options: shuffleArray([p.nameAr, ...w.map(x => x.nameAr)]) });
  }, [difficulty]);
  useEffect(() => { gen(); }, [gen, qNum]);
  return { qData, qNum, next: () => setQNum(n => n + 1) };
}

function Career3Game(props: GameProps) {
  const { qData, qNum, next } = usePlayerQuestion(props.difficulty);
  if (!qData) return null;
  const clubs = qData.player.clubsAr.length >= 3 ? [qData.player.clubsAr[0], qData.player.clubsAr[Math.floor(qData.player.clubsAr.length/2)], qData.player.clubsAr[qData.player.clubsAr.length - 1]] : qData.player.clubsAr;
  return (<GameWrapper title="مسيرة 3 أندية" icon="🏟️" onBack={props.onBack} state={props.state} difficulty={props.difficulty}>
    <MultipleChoice question={<div><p className="text-white/60 mb-4 text-lg">من لعب في هذه الأندية؟</p><div className="flex items-center justify-center gap-3 flex-wrap text-xl font-bold">{clubs.map((c, i) => (<span key={i}><span style={{color: '#f0c040'}}>{c}</span>{i < clubs.length - 1 && <span className="text-white/30"> → </span>}</span>))}</div></div>}
      options={qData.options} correctAnswer={qData.player.nameAr} onCorrect={props.onCorrect} onWrong={props.onWrong}
      onNext={() => { props.setState(p => ({...p, totalQuestions: p.totalQuestions + 1})); next(); }} questionNumber={qNum} />
  </GameWrapper>);
}

function CareerNationalGame(props: GameProps) {
  const { qData, qNum, next } = usePlayerQuestion(props.difficulty);
  if (!qData) return null;
  return (<GameWrapper title="منتخب + ناديين" icon="🌍" onBack={props.onBack} state={props.state} difficulty={props.difficulty}>
    <MultipleChoice question={<div><p className="text-white/60 mb-4">من هو اللاعب؟</p><div className="text-xl font-bold mb-2">🏴 {qData.player.nationalityAr}</div><div className="text-lg font-bold" style={{color: '#f0c040'}}>{qData.player.clubsAr.slice(0, 2).join(' + ')}</div></div>}
      options={qData.options} correctAnswer={qData.player.nameAr} onCorrect={props.onCorrect} onWrong={props.onWrong}
      onNext={() => { props.setState(p => ({...p, totalQuestions: p.totalQuestions + 1})); next(); }} questionNumber={qNum} />
  </GameWrapper>);
}

function BirthPositionGame(props: GameProps) {
  const { qData, qNum, next } = usePlayerQuestion(props.difficulty);
  if (!qData) return null;
  return (<GameWrapper title="سنة + مركز" icon="📅" onBack={props.onBack} state={props.state} difficulty={props.difficulty}>
    <MultipleChoice question={<div><p className="text-white/60 mb-4">من هو اللاعب؟</p><div className="flex items-center justify-center gap-6 text-2xl font-bold"><span>📅 <span style={{color: '#f0c040'}}>{qData.player.birthYear}</span></span><span className="text-white/30">|</span><span>⚽ <span style={{color: '#f0c040'}}>{qData.player.positionAr}</span></span></div><div className="mt-3 text-sm text-white/40">🏴 {qData.player.nationalityAr}</div></div>}
      options={qData.options} correctAnswer={qData.player.nameAr} onCorrect={props.onCorrect} onWrong={props.onWrong}
      onNext={() => { props.setState(p => ({...p, totalQuestions: p.totalQuestions + 1})); next(); }} questionNumber={qNum} />
  </GameWrapper>);
}

function FirstLastGame(props: GameProps) {
  const { qData, qNum, next } = usePlayerQuestion(props.difficulty);
  if (!qData) return null;
  return (<GameWrapper title="أول وآخر نادي" icon="🔄" onBack={props.onBack} state={props.state} difficulty={props.difficulty}>
    <MultipleChoice question={<div><p className="text-white/60 mb-4">من هو اللاعب؟</p><div className="flex items-center justify-center gap-4 text-xl font-bold"><span style={{color: '#22c55e'}}>{qData.player.clubsAr[0]}</span><span className="text-white/30 text-2xl">→</span><span style={{color: '#f0c040'}}>{qData.player.clubsAr[qData.player.clubsAr.length - 1]}</span></div></div>}
      options={qData.options} correctAnswer={qData.player.nameAr} onCorrect={props.onCorrect} onWrong={props.onWrong}
      onNext={() => { props.setState(p => ({...p, totalQuestions: p.totalQuestions + 1})); next(); }} questionNumber={qNum} />
  </GameWrapper>);
}

function Hints5Game(props: GameProps) {
  const { qData, qNum, next } = usePlayerQuestion(props.difficulty);
  const [revealedHints, setRevealedHints] = useState(1);
  useEffect(() => { setRevealedHints(1); }, [qNum]);
  if (!qData) return null;
  return (<GameWrapper title="5 تلميحات" icon="💡" onBack={props.onBack} state={props.state} difficulty={props.difficulty}>
    <div className="glass-card rounded-2xl p-6 mb-6"><p className="text-white/60 mb-4 text-lg text-center">من هو هذا اللاعب؟</p>
      <div className="space-y-3">{qData.player.hintsAr.slice(0, revealedHints).map((hint, i) => (<div key={i} className="flex items-center gap-3 animate-slideUp" style={{animationDelay: `${i * 100}ms`}}><span className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold" style={{background: 'rgba(212,160,23,0.3)', color: '#f0c040'}}>{i + 1}</span><span className="text-white/90">{hint}</span></div>))}</div>
      {revealedHints < 5 && <button onClick={() => { setRevealedHints(r => r + 1); playSound('click'); }} className="btn-secondary mt-4 w-full text-center text-sm">كشف تلميح ({revealedHints}/5) 💡</button>}
    </div>
    <MultipleChoice question={<></>} options={qData.options} correctAnswer={qData.player.nameAr} onCorrect={props.onCorrect} onWrong={props.onWrong}
      onNext={() => { props.setState(p => ({...p, totalQuestions: p.totalQuestions + 1})); next(); }} questionNumber={qNum} />
  </GameWrapper>);
}

function RankGame(props: GameProps & { sortKey: 'goals' | 'assists' | 'titles'; title: string }) {
  const [rankPlayers, setRankPlayers] = useState<Player[]>([]); const [userOrder, setUserOrder] = useState<Player[]>([]);
  const [submitted, setSubmitted] = useState(false); const [isCorrectOrder, setIsCorrectOrder] = useState(false); const [qNum, setQNum] = useState(0);
  useEffect(() => { const s = getRandomPlayersWithDifficulty(5, props.difficulty); setRankPlayers(s); setUserOrder(shuffleArray(s)); setSubmitted(false); }, [qNum, props.difficulty]);
  const moveUp = (i: number) => { if (i === 0 || submitted) return; const n = [...userOrder]; [n[i], n[i-1]] = [n[i-1], n[i]]; setUserOrder(n); playSound('click'); };
  const moveDown = (i: number) => { if (i === userOrder.length-1 || submitted) return; const n = [...userOrder]; [n[i], n[i+1]] = [n[i+1], n[i]]; setUserOrder(n); playSound('click'); };
  const check = () => { const correct = [...rankPlayers].sort((a, b) => b[props.sortKey] - a[props.sortKey]); const ok = userOrder.every((p, i) => p.id === correct[i].id); setIsCorrectOrder(ok); setSubmitted(true); props.setState(p => ({...p, totalQuestions: p.totalQuestions + 1})); if (ok) props.onCorrect(); else props.onWrong(); };
  const sorted = [...rankPlayers].sort((a, b) => b[props.sortKey] - a[props.sortKey]);
  return (<GameWrapper title={props.title} icon={props.sortKey === 'goals' ? '⚽' : props.sortKey === 'assists' ? '🎯' : '🏆'} onBack={props.onBack} state={props.state} difficulty={props.difficulty}>
    <div className="glass-card rounded-2xl p-6 mb-6 text-center"><p className="text-white/60 text-lg">رتّب من الأكثر إلى الأقل</p></div>
    <div className="space-y-3 mb-6">{userOrder.map((player, i) => (
      <div key={player.id} className={`drag-item flex items-center justify-between ${submitted ? (player.id === sorted[i]?.id ? 'border-green-500 bg-green-500/10' : 'border-red-500 bg-red-500/10') : ''}`}>
        <div className="flex items-center gap-3"><span className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold" style={{background: 'rgba(212,160,23,0.3)', color: '#f0c040'}}>{i + 1}</span><span className="font-bold">{player.nameAr}</span>{submitted && <span className="text-sm text-white/50">({player[props.sortKey]})</span>}</div>
        {!submitted && <div className="flex gap-2"><button onClick={() => moveUp(i)} className="p-1 rounded bg-white/10 hover:bg-white/20" disabled={i === 0}>⬆️</button><button onClick={() => moveDown(i)} className="p-1 rounded bg-white/10 hover:bg-white/20" disabled={i === userOrder.length - 1}>⬇️</button></div>}
      </div>))}</div>
    {!submitted ? <button onClick={check} className="btn-primary w-full text-center">تأكيد ✅</button> : (
      <div className="text-center animate-bounceIn"><div className={`text-xl font-bold mb-3 ${isCorrectOrder ? 'text-green-400' : 'text-red-400'}`}>{isCorrectOrder ? '✅ صحيح!' : '❌ خاطئ!'}</div>
        {!isCorrectOrder && <div className="glass-card rounded-xl p-4 mb-4"><p className="text-white/60 mb-2 text-sm">الترتيب الصحيح:</p>{sorted.map((p, i) => (<div key={p.id} className="text-sm py-1">{i+1}. {p.nameAr} ({p[props.sortKey]})</div>))}</div>}
        <button onClick={() => setQNum(n => n + 1)} className="btn-primary">التالي ←</button></div>)}
  </GameWrapper>);
}

function CurrentClubGame(props: GameProps) { const { qData, qNum, next } = usePlayerQuestion(props.difficulty); if (!qData) return null; return (<GameWrapper title="النادي الحالي" icon="🎽" onBack={props.onBack} state={props.state} difficulty={props.difficulty}><MultipleChoice question={<div><p className="text-white/60 mb-4">من يلعب في هذا النادي؟</p><div className="text-3xl font-black" style={{color: '#f0c040'}}>🏟️ {qData.player.currentClubAr}</div></div>} options={qData.options} correctAnswer={qData.player.nameAr} onCorrect={props.onCorrect} onWrong={props.onWrong} onNext={() => { props.setState(p => ({...p, totalQuestions: p.totalQuestions + 1})); next(); }} questionNumber={qNum} /></GameWrapper>); }

function NationalTeamGame(props: GameProps) { const { qData, qNum, next } = usePlayerQuestion(props.difficulty); if (!qData) return null; return (<GameWrapper title="المنتخب فقط" icon="🏴" onBack={props.onBack} state={props.state} difficulty={props.difficulty}><MultipleChoice question={<div><p className="text-white/60 mb-4">من يلعب لهذا المنتخب بهذا المركز؟</p><div className="text-2xl font-bold mb-2">🏴 {qData.player.nationalityAr}</div><div className="text-lg text-white/70">{qData.player.positionAr}</div></div>} options={qData.options} correctAnswer={qData.player.nameAr} onCorrect={props.onCorrect} onWrong={props.onWrong} onNext={() => { props.setState(p => ({...p, totalQuestions: p.totalQuestions + 1})); next(); }} questionNumber={qNum} /></GameWrapper>); }

function TwoNumbersGame(props: GameProps) {
  const [qData, setQData] = useState<{ player: Player; options: string[] } | null>(null); const [qNum, setQNum] = useState(0);
  useEffect(() => { const pool = getPlayersByDifficulty(props.difficulty).filter(p => p.numbers.length >= 2); const p = pool[Math.floor(Math.random() * pool.length)]; const w = getRandomPlayersWithDifficulty(3, props.difficulty, [p.id]); setQData({ player: p, options: shuffleArray([p.nameAr, ...w.map(x => x.nameAr)]) }); }, [qNum, props.difficulty]);
  if (!qData) return null; const nums = qData.player.numbers.slice(0, 2);
  return (<GameWrapper title="رقمين" icon="🔢" onBack={props.onBack} state={props.state} difficulty={props.difficulty}>
    <MultipleChoice question={<div><p className="text-white/60 mb-4">من لعب بهذين الرقمين؟</p><div className="flex items-center justify-center gap-6"><div className="w-20 h-24 rounded-xl flex items-center justify-center text-3xl font-black" style={{background: 'linear-gradient(135deg, rgba(212,160,23,0.3), rgba(212,160,23,0.1))', color: '#f0c040', border: '2px solid rgba(212,160,23,0.5)'}}>{nums[0]}</div><span className="text-2xl text-white/30">+</span><div className="w-20 h-24 rounded-xl flex items-center justify-center text-3xl font-black" style={{background: 'linear-gradient(135deg, rgba(34,197,94,0.3), rgba(34,197,94,0.1))', color: '#22c55e', border: '2px solid rgba(34,197,94,0.5)'}}>{nums[1]}</div></div></div>}
      options={qData.options} correctAnswer={qData.player.nameAr} onCorrect={props.onCorrect} onWrong={props.onWrong}
      onNext={() => { props.setState(p => ({...p, totalQuestions: p.totalQuestions + 1})); setQNum(n => n + 1); }} questionNumber={qNum} />
  </GameWrapper>);
}

function BlurryPhotoGame(props: GameProps) {
  const [qData, setQData] = useState<{ player: Player; options: string[] } | null>(null);
  const [qNum, setQNum] = useState(0);
  const [revealLevel, setRevealLevel] = useState(0);
  const [imgLoaded, setImgLoaded] = useState(false);
  const [imgError, setImgError] = useState(false);

  useEffect(() => {
    // Pick a player that has visual data for better experience
    const pool = getPlayersByDifficulty(props.difficulty);
    const withVisuals = pool.filter(p => playerVisuals[p.id]);
    const source = withVisuals.length >= 4 ? withVisuals : pool;
    const p = source[Math.floor(Math.random() * source.length)];
    const w = getRandomPlayersWithDifficulty(3, props.difficulty, [p.id]);
    setQData({ player: p, options: shuffleArray([p.nameAr, ...w.map(x => x.nameAr)]) });
    setRevealLevel(0);
    setImgLoaded(false);
    setImgError(false);
  }, [qNum, props.difficulty]);

  if (!qData) return null;

  const visual = playerVisuals[qData.player.id];
  const silhouette = getPlayerSilhouetteStyle(qData.player.id);
  const blurLevels = [20, 14, 9, 5, 2];
  const currentBlur = blurLevels[Math.min(revealLevel, blurLevels.length - 1)];

  const revealHint = () => {
    if (revealLevel < 4) {
      setRevealLevel(r => r + 1);
      playSound('click');
    }
  };

  return (
    <GameWrapper title="صورة ضبابية" icon="🖼️" onBack={props.onBack} state={props.state} difficulty={props.difficulty}>
      <div className="glass-card rounded-2xl p-6 mb-6 text-center animate-slideUp">
        <p className="text-white/60 mb-4 text-lg">من هو هذا اللاعب؟</p>

        {/* Image Container */}
        <div className="relative w-48 h-48 md:w-56 md:h-56 mx-auto rounded-2xl overflow-hidden mb-4 shadow-2xl" style={{border: '3px solid rgba(212,160,23,0.4)'}}>
          {/* Try real image first */}
          {visual && !imgError && (
            <img
              src={visual.imageUrl}
              alt="player"
              className="absolute inset-0 w-full h-full object-cover transition-all duration-700"
              style={{ filter: `blur(${currentBlur}px)`, transform: 'scale(1.1)' }}
              onLoad={() => setImgLoaded(true)}
              onError={() => setImgError(true)}
            />
          )}

          {/* Fallback: SVG-based visual card */}
          {(!visual || imgError || !imgLoaded) && (
            <div className="absolute inset-0 flex flex-col items-center justify-center transition-all duration-700"
              style={{
                background: silhouette.bgGradient,
                filter: `blur(${Math.max(currentBlur - 5, 0)}px)`,
              }}>
              <span className="text-7xl mb-2" style={{filter: `blur(${Math.max(currentBlur / 3, 0)}px)`}}>{silhouette.icon}</span>
              {revealLevel >= 2 && (
                <div className="text-xs text-white/60 bg-black/30 px-2 py-1 rounded-full">
                  {visual?.distinguishingFeature || qData.player.positionAr}
                </div>
              )}
            </div>
          )}

          {/* Loading indicator */}
          {visual && !imgError && !imgLoaded && (
            <div className="absolute inset-0 flex items-center justify-center bg-black/40 z-10">
              <div className="w-8 h-8 border-3 border-white/30 border-t-yellow-400 rounded-full animate-spin"></div>
            </div>
          )}

          {/* Blur level indicator */}
          <div className="absolute top-2 left-2 right-2 flex justify-between items-center z-20">
            <span className="text-xs bg-black/60 px-2 py-1 rounded-full text-white/80">
              وضوح: {Math.round(((4 - Math.min(revealLevel, 4)) / 4) * 100)}%
            </span>
          </div>
        </div>

        {/* Progressive Clues */}
        <div className="space-y-2 mb-4 max-w-md mx-auto">
          {silhouette.clues.slice(0, revealLevel + 1).map((clue, i) => (
            <div key={i} className="flex items-center gap-2 text-sm animate-slideUp" style={{animationDelay: `${i * 100}ms`}}>
              <span className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0"
                style={{background: 'rgba(212,160,23,0.3)', color: '#f0c040'}}>{i + 1}</span>
              <span className="text-white/80">{clue}</span>
            </div>
          ))}
        </div>

        {/* Reveal button */}
        {revealLevel < 4 && (
          <button onClick={revealHint} className="btn-secondary text-sm px-4 py-2">
            كشف تلميح ({revealLevel + 1}/5) 🔍
          </button>
        )}
      </div>

      <MultipleChoice
        question={<></>}
        options={qData.options}
        correctAnswer={qData.player.nameAr}
        onCorrect={props.onCorrect}
        onWrong={props.onWrong}
        onNext={() => { props.setState(p => ({...p, totalQuestions: p.totalQuestions + 1})); setQNum(n => n + 1); }}
        questionNumber={qNum}
      />
    </GameWrapper>
  );
}

function TransferStoryGame(props: GameProps) { const { qData, qNum, next } = usePlayerQuestion(props.difficulty); if (!qData) return null; return (<GameWrapper title="قصة انتقال" icon="💰" onBack={props.onBack} state={props.state} difficulty={props.difficulty}><MultipleChoice question={<div><p className="text-white/60 mb-4">من صاحب هذا الانتقال؟</p><div className="glass-card rounded-xl p-4 inline-block"><span className="text-xl" style={{color: '#f0c040'}}>💰 &quot;{qData.player.transferStoryAr}&quot;</span></div></div>} options={qData.options} correctAnswer={qData.player.nameAr} onCorrect={props.onCorrect} onWrong={props.onWrong} onNext={() => { props.setState(p => ({...p, totalQuestions: p.totalQuestions + 1})); next(); }} questionNumber={qNum} /></GameWrapper>); }

function TeammateGame(props: GameProps) {
  const [qData, setQData] = useState<{ player: Player; correctTeammate: string; options: string[] } | null>(null); const [qNum, setQNum] = useState(0);
  useEffect(() => { const p = getRandomPlayerWithDifficulty(props.difficulty); const ct = p.teammatesAr[Math.floor(Math.random() * p.teammatesAr.length)]; const allT = [...new Set(players.flatMap(pl => pl.teammatesAr))].filter(t => !p.teammatesAr.includes(t)); const wrong = shuffleArray(allT).slice(0, 3); setQData({ player: p, correctTeammate: ct, options: shuffleArray([ct, ...wrong]) }); }, [qNum, props.difficulty]);
  if (!qData) return null;
  return (<GameWrapper title="من لعب معه؟" icon="🤝" onBack={props.onBack} state={props.state} difficulty={props.difficulty}>
    <MultipleChoice question={<div><p className="text-white/60 mb-4">من لعب مع هذا اللاعب؟</p><div className="text-3xl font-black" style={{color: '#f0c040'}}>🤝 {qData.player.nameAr}</div></div>}
      options={qData.options} correctAnswer={qData.correctTeammate} onCorrect={props.onCorrect} onWrong={props.onWrong}
      onNext={() => { props.setState(p => ({...p, totalQuestions: p.totalQuestions + 1})); setQNum(n => n + 1); }} questionNumber={qNum} />
  </GameWrapper>);
}

function CoachGame(props: GameProps) {
  const [qData, setQData] = useState<{ player: Player; correctCoach: string; options: string[] } | null>(null); const [qNum, setQNum] = useState(0);
  useEffect(() => { const p = getRandomPlayerWithDifficulty(props.difficulty); const cc = p.coachesAr[Math.floor(Math.random() * p.coachesAr.length)]; const allC = [...new Set(players.flatMap(pl => pl.coachesAr))].filter(c => !p.coachesAr.includes(c)); const wrong = shuffleArray(allC).slice(0, 3); setQData({ player: p, correctCoach: cc, options: shuffleArray([cc, ...wrong]) }); }, [qNum, props.difficulty]);
  if (!qData) return null;
  return (<GameWrapper title="من درّبه؟" icon="📋" onBack={props.onBack} state={props.state} difficulty={props.difficulty}>
    <MultipleChoice question={<div><p className="text-white/60 mb-4">من درّب هذا اللاعب؟</p><div className="text-3xl font-black" style={{color: '#f0c040'}}>📋 {qData.player.nameAr}</div></div>}
      options={qData.options} correctAnswer={qData.correctCoach} onCorrect={props.onCorrect} onWrong={props.onWrong}
      onNext={() => { props.setState(p => ({...p, totalQuestions: p.totalQuestions + 1})); setQNum(n => n + 1); }} questionNumber={qNum} />
  </GameWrapper>);
}

function HistoricMatchGame(props: GameProps) {
  const [qData, setQData] = useState<{ match: typeof historicMatches[0]; options: string[] } | null>(null); const [qNum, setQNum] = useState(0);
  useEffect(() => { const filtered = historicMatches.filter(m => props.difficulty === 'easy' ? m.difficulty === 'easy' : props.difficulty === 'medium' ? m.difficulty !== 'hard' : true); const m = filtered[Math.floor(Math.random() * filtered.length)]; const wrong = shuffleArray(historicMatches.filter(x => x.id !== m.id)).slice(0, 3); setQData({ match: m, options: shuffleArray([m.descAr, ...wrong.map(x => x.descAr)]) }); }, [qNum, props.difficulty]);
  if (!qData) return null;
  return (<GameWrapper title="مباراة تاريخية" icon="📜" onBack={props.onBack} state={props.state} difficulty={props.difficulty}>
    <MultipleChoice question={<div><p className="text-white/60 mb-4">ما هي المباراة؟</p><div className="text-5xl font-black" style={{color: '#f0c040'}}>{qData.match.score}</div><div className="text-sm text-white/40 mt-2">{qData.match.competition} - {qData.match.year}</div></div>}
      options={qData.options} correctAnswer={qData.match.descAr} onCorrect={props.onCorrect} onWrong={props.onWrong}
      onNext={() => { props.setState(p => ({...p, totalQuestions: p.totalQuestions + 1})); setQNum(n => n + 1); }} questionNumber={qNum} />
  </GameWrapper>);
}

// ==================== DYNAMIC QUESTION MODES ====================
function QuickQuizGame(props: GameProps) {
  const [questions, setQuestions] = useState<GeneratedQuickQuestion[]>([]);
  const [ci, setCi] = useState(0); const [qNum, setQNum] = useState(0);
  const [timeLeft, setTimeLeft] = useState(15); const [answered, setAnswered] = useState(false);

  useEffect(() => {
    // Generate 3 fresh questions each round
    setQuestions([generateQuickQuestion(props.difficulty), generateQuickQuestion(props.difficulty), generateQuickQuestion(props.difficulty)]);
    setCi(0); setTimeLeft(15); setAnswered(false);
  }, [qNum, props.difficulty]);

  useEffect(() => {
    if (answered || !questions.length) return;
    if (timeLeft <= 0) { props.onWrong(); props.setState(p => ({...p, totalQuestions: p.totalQuestions + 1})); setAnswered(true); return; }
    const t = setTimeout(() => { setTimeLeft(tl => tl - 1); if (timeLeft <= 5) playSound('tick'); }, 1000);
    return () => clearTimeout(t);
  }, [timeLeft, answered, questions.length, props]);

  if (!questions.length || !questions[ci]) return null;
  const q = questions[ci];

  return (<GameWrapper title="أسئلة سريعة ⚡" icon="⚡" onBack={props.onBack} state={props.state} difficulty={props.difficulty}>
    <div className="glass-card rounded-2xl p-4 mb-4 flex items-center justify-between">
      <span className="text-sm text-white/60">السؤال {ci + 1} من 3</span>
      <span className={`text-xl font-bold ${timeLeft <= 5 ? 'text-red-400 animate-pulse' : 'text-green-400'}`}>⏱️ {timeLeft}s</span>
    </div>
    <div className="progress-bar h-2 mb-6"><div className="progress-bar-fill" style={{width: `${(timeLeft / 15) * 100}%`}}></div></div>
    <MultipleChoice question={<p className="text-xl font-bold" style={{color: '#f0c040'}}>{q.question}</p>}
      options={q.options} correctAnswer={q.answer}
      onCorrect={() => { props.onCorrect(); props.setState(p => ({...p, totalQuestions: p.totalQuestions + 1})); setAnswered(true); }}
      onWrong={() => { props.onWrong(); props.setState(p => ({...p, totalQuestions: p.totalQuestions + 1})); setAnswered(true); }}
      onNext={() => { if (ci < 2) { setCi(i => i + 1); setTimeLeft(15); setAnswered(false); } else setQNum(n => n + 1); }}
      questionNumber={ci + qNum * 10} />
  </GameWrapper>);
}

function TrueFalseGame(props: GameProps) {
  const [question, setQuestion] = useState<GeneratedTrueFalse | null>(null);
  const [selected, setSelected] = useState<boolean | null>(null);
  const [qNum, setQNum] = useState(0);

  useEffect(() => {
    // Generate fresh question every time - never repeats!
    setQuestion(generateTrueFalse(props.difficulty));
    setSelected(null);
  }, [qNum, props.difficulty]);

  if (!question) return null;
  const handleAnswer = (answer: boolean) => {
    if (selected !== null) return;
    playSound('click');
    setSelected(answer);
    props.setState(p => ({...p, totalQuestions: p.totalQuestions + 1}));
    if (answer === question.answer) props.onCorrect(); else props.onWrong();
  };

  return (<GameWrapper title="صح أو خطأ" icon="✅" onBack={props.onBack} state={props.state} difficulty={props.difficulty}>
    <div className="glass-card rounded-2xl p-8 mb-6 text-center animate-slideUp">
      <p className="text-white/60 mb-6 text-lg">هل هذه العبارة صحيحة؟</p>
      <p className="text-2xl font-bold mb-8" style={{color: '#f0c040'}}>&quot;{question.statement}&quot;</p>
      <div className="flex gap-4 justify-center">
        <button onClick={() => handleAnswer(true)} disabled={selected !== null}
          className={`flex-1 max-w-[200px] py-4 rounded-xl text-xl font-bold transition-all ${selected === null ? 'bg-green-500/20 border-2 border-green-500/30 hover:bg-green-500/30 hover:scale-105' : selected === true && question.answer === true ? 'bg-green-500/40 border-2 border-green-500' : selected === true ? 'bg-red-500/40 border-2 border-red-500 animate-shake' : question.answer === true ? 'bg-green-500/40 border-2 border-green-500' : 'bg-green-500/10 border-2 border-green-500/20'}`}>✅ صح</button>
        <button onClick={() => handleAnswer(false)} disabled={selected !== null}
          className={`flex-1 max-w-[200px] py-4 rounded-xl text-xl font-bold transition-all ${selected === null ? 'bg-red-500/20 border-2 border-red-500/30 hover:bg-red-500/30 hover:scale-105' : selected === false && question.answer === false ? 'bg-green-500/40 border-2 border-green-500' : selected === false ? 'bg-red-500/40 border-2 border-red-500 animate-shake' : question.answer === false ? 'bg-green-500/40 border-2 border-green-500' : 'bg-red-500/10 border-2 border-red-500/20'}`}>❌ خطأ</button>
      </div>
    </div>
    {selected !== null && (
      <div className="text-center animate-bounceIn">
        <div className={`text-xl font-bold mb-2 ${selected === question.answer ? 'text-green-400' : 'text-red-400'}`}>{selected === question.answer ? '✅ إجابة صحيحة!' : '❌ خاطئة!'}</div>
        <div className="glass-card rounded-xl p-4 mb-4 mx-auto max-w-lg text-sm"><p className="text-white/70">💡 <span className="font-bold" style={{color: '#f0c040'}}>التفسير:</span> {question.explanation}</p></div>
        <button onClick={() => setQNum(n => n + 1)} className="btn-primary">التالي ←</button>
      </div>
    )}
  </GameWrapper>);
}

function ComparisonGame(props: GameProps) {
  const [pA, setPA] = useState<Player | null>(null); const [pB, setPB] = useState<Player | null>(null);
  const [cType, setCType] = useState<'goals' | 'assists' | 'matches'>('goals'); const [selected, setSelected] = useState<number | null>(null); const [qNum, setQNum] = useState(0);
  useEffect(() => { const two = getRandomPlayersWithDifficulty(2, props.difficulty); setPA(two[0]); setPB(two[1]); setSelected(null); setCType((['goals', 'assists', 'matches'] as const)[Math.floor(Math.random() * 3)]); }, [qNum, props.difficulty]);
  if (!pA || !pB) return null;
  const labels = { goals: 'أهدافاً', assists: 'تمريرات حاسمة', matches: 'مباريات' };
  const correctId = pA[cType] >= pB[cType] ? pA.id : pB.id;
  const handleSelect = (id: number) => { if (selected !== null) return; playSound('click'); setSelected(id); props.setState(p => ({...p, totalQuestions: p.totalQuestions + 1})); if (id === correctId) props.onCorrect(); else props.onWrong(); };
  return (<GameWrapper title="مقارنات" icon="⚔️" onBack={props.onBack} state={props.state} difficulty={props.difficulty}>
    <div className="glass-card rounded-2xl p-6 mb-6 text-center"><p className="text-white/60 text-lg">من لديه {labels[cType]} أكثر؟</p></div>
    <div className="grid grid-cols-2 gap-4 mb-6">{[pA, pB].map(player => (
      <button key={player.id} onClick={() => handleSelect(player.id)} disabled={selected !== null}
        className={`game-card rounded-xl p-6 text-center transition-all ${selected !== null && player.id === correctId ? 'border-green-500 bg-green-500/10' : selected === player.id && player.id !== correctId ? 'border-red-500 bg-red-500/10 animate-shake' : ''} ${selected === null ? 'hover:scale-105 cursor-pointer' : ''}`}>
        <div className="text-4xl mb-3">⚽</div><div className="text-xl font-bold mb-2">{player.nameAr}</div><div className="text-sm text-white/50">{player.nationalityAr}</div>
        {selected !== null && <div className="mt-3 text-2xl font-black animate-bounceIn" style={{color: '#f0c040'}}>{player[cType]}</div>}
      </button>))}</div>
    {selected !== null && (<div className="text-center animate-bounceIn"><div className={`text-xl font-bold mb-3 ${selected === correctId ? 'text-green-400' : 'text-red-400'}`}>{selected === correctId ? '✅ صحيح!' : '❌ خاطئ!'}</div><button onClick={() => setQNum(n => n + 1)} className="btn-primary">التالي ←</button></div>)}
  </GameWrapper>);
}

function FirstIntlGame(props: GameProps) { const { qData, qNum, next } = usePlayerQuestion(props.difficulty); if (!qData) return null; return (<GameWrapper title="أول مباراة دولية" icon="🌟" onBack={props.onBack} state={props.state} difficulty={props.difficulty}><MultipleChoice question={<div><p className="text-white/60 mb-4">من لعب أول مباراة دولية في هذه السنة؟</p><div className="text-3xl font-black mb-2" style={{color: '#f0c040'}}>🌟 {qData.player.firstIntlYear}</div><div className="text-lg text-white/50">مع منتخب {qData.player.nationalityAr}</div></div>} options={qData.options} correctAnswer={qData.player.nameAr} onCorrect={props.onCorrect} onWrong={props.onWrong} onNext={() => { props.setState(p => ({...p, totalQuestions: p.totalQuestions + 1})); next(); }} questionNumber={qNum} /></GameWrapper>); }

// ==================== DAILY CHALLENGE ====================
type DailyQuestionType = 'career3' | 'trueFalse' | 'quickQuiz' | 'transferStory' | 'blurryHints';

interface DailyQuestion {
  type: DailyQuestionType;
  question: React.ReactNode;
  options: string[];
  correctAnswer: string;
  explanation?: string;
}

function DailyChallenge({ dailyData, setDailyData, difficulty, onBack }: {
  dailyData: DailyData;
  setDailyData: React.Dispatch<React.SetStateAction<DailyData>>;
  difficulty: Difficulty;
  onBack: () => void;
}) {
  const [questions, setQuestions] = useState<DailyQuestion[]>([]);
  const [currentQ, setCurrentQ] = useState(0);
  const [score, setScore] = useState(0);
  const [selected, setSelected] = useState<string | null>(null);
  const [answered, setAnswered] = useState(false);
  const [finished, setFinished] = useState(false);
  const [showExplanation, setShowExplanation] = useState('');

  // Generate 5 daily questions using today's date as seed
  useEffect(() => {
    if (dailyData.todayCompleted) {
      setFinished(true);
      setScore(dailyData.todayScore);
      return;
    }

    // Seed random based on today's date for consistency
    const today = getTodayKey();
    let seed = 0;
    for (let i = 0; i < today.length; i++) seed += today.charCodeAt(i) * (i + 1);

    const types: DailyQuestionType[] = ['career3', 'trueFalse', 'quickQuiz', 'transferStory', 'blurryHints'];
    const generated: DailyQuestion[] = [];

    for (let i = 0; i < 5; i++) {
      const type = types[i % types.length];
      const pool = getPlayersByDifficulty(difficulty);
      const pIndex = (seed * (i + 1) * 7 + i * 13) % pool.length;
      const p = pool[pIndex];
      const others = getRandomPlayersWithDifficulty(3, difficulty, [p.id]);
      const options = shuffleArray([p.nameAr, ...others.map(o => o.nameAr)]);

      switch (type) {
        case 'career3': {
          const clubs = p.clubsAr.length >= 3
            ? [p.clubsAr[0], p.clubsAr[Math.floor(p.clubsAr.length/2)], p.clubsAr[p.clubsAr.length - 1]]
            : p.clubsAr;
          generated.push({
            type, correctAnswer: p.nameAr, options,
            question: (
              <div>
                <p className="text-white/60 mb-2 text-sm">🏟️ خمن اللاعب من مسيرته</p>
                <div className="flex items-center justify-center gap-3 flex-wrap text-xl font-bold">
                  {clubs.map((c, ci) => (
                    <span key={ci}><span style={{color: '#f0c040'}}>{c}</span>{ci < clubs.length - 1 && <span className="text-white/30"> → </span>}</span>
                  ))}
                </div>
              </div>
            ),
          });
          break;
        }
        case 'trueFalse': {
          const tf = generateTrueFalse(difficulty);
          generated.push({
            type, correctAnswer: tf.answer ? 'صح ✅' : 'خطأ ❌',
            options: ['صح ✅', 'خطأ ❌'],
            explanation: tf.explanation,
            question: (
              <div>
                <p className="text-white/60 mb-2 text-sm">✅ صح أو خطأ</p>
                <p className="text-xl font-bold" style={{color: '#f0c040'}}>&quot;{tf.statement}&quot;</p>
              </div>
            ),
          });
          break;
        }
        case 'quickQuiz': {
          const qq = generateQuickQuestion(difficulty);
          generated.push({
            type, correctAnswer: qq.answer, options: qq.options,
            question: (
              <div>
                <p className="text-white/60 mb-2 text-sm">⚡ سؤال سريع</p>
                <p className="text-xl font-bold" style={{color: '#f0c040'}}>{qq.question}</p>
              </div>
            ),
          });
          break;
        }
        case 'transferStory': {
          generated.push({
            type, correctAnswer: p.nameAr, options,
            question: (
              <div>
                <p className="text-white/60 mb-2 text-sm">💰 خمن من قصة الانتقال</p>
                <div className="glass-card rounded-xl p-3 inline-block">
                  <span className="text-lg" style={{color: '#f0c040'}}>&quot;{p.transferStoryAr}&quot;</span>
                </div>
              </div>
            ),
          });
          break;
        }
        case 'blurryHints': {
          const hints = p.hintsAr.slice(0, 3);
          generated.push({
            type, correctAnswer: p.nameAr, options,
            question: (
              <div>
                <p className="text-white/60 mb-3 text-sm">💡 خمن من التلميحات</p>
                <div className="space-y-2">
                  {hints.map((h, hi) => (
                    <div key={hi} className="flex items-center gap-2 text-sm">
                      <span className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold"
                        style={{background: 'rgba(212,160,23,0.3)', color: '#f0c040'}}>{hi + 1}</span>
                      <span className="text-white/80">{h}</span>
                    </div>
                  ))}
                </div>
              </div>
            ),
          });
          break;
        }
      }
    }

    setQuestions(generated);
  }, [dailyData.todayCompleted, difficulty]);

  const handleAnswer = (option: string) => {
    if (answered || finished) return;
    playSound('click');
    setSelected(option);
    setAnswered(true);

    const q = questions[currentQ];
    const correct = option === q.correctAnswer;

    if (correct) {
      playSound('correct');
      setScore(s => s + 1);
    } else {
      playSound('wrong');
    }

    if (q.explanation) setShowExplanation(q.explanation);
  };

  const nextQuestion = () => {
    if (currentQ >= 4) {
      // Finished all 5 questions
      const finalScore = score;
      const today = getTodayKey();
      const newStreak = dailyData.lastPlayedDate ? dailyData.streak + 1 : 1;
      const newDaily: DailyData = {
        lastPlayedDate: today,
        streak: newStreak,
        bestStreak: Math.max(newStreak, dailyData.bestStreak),
        todayCompleted: true,
        todayScore: finalScore,
        todayTotal: 5,
      };
      setDailyData(newDaily);
      saveDailyData(newDaily);
      setFinished(true);
      playSound('win');
    } else {
      setCurrentQ(c => c + 1);
      setSelected(null);
      setAnswered(false);
      setShowExplanation('');
    }
  };

  // Finished state
  if (finished) {
    const displayScore = dailyData.todayCompleted ? dailyData.todayScore : score;
    const displayStreak = dailyData.streak;
    return (
      <div className="animate-fadeIn max-w-2xl mx-auto">
        <div className="text-center mb-8 animate-bounceIn">
          <div className="text-6xl mb-4">{displayScore >= 4 ? '🏆' : displayScore >= 3 ? '⭐' : '💪'}</div>
          <h2 className="text-3xl font-black mb-2" style={{color: '#f0c040'}}>
            {dailyData.todayCompleted ? 'تحدي اليوم مكتمل!' : 'أحسنت!'}
          </h2>
          <p className="text-xl text-white/70 mb-4">
            نتيجتك: <span className="font-black" style={{color: '#f0c040'}}>{displayScore}</span> / 5
          </p>

          {/* Score stars */}
          <div className="flex justify-center gap-2 mb-6">
            {[0, 1, 2, 3, 4].map(i => (
              <span key={i} className="text-3xl" style={{opacity: i < displayScore ? 1 : 0.2}}>⭐</span>
            ))}
          </div>

          {/* Streak */}
          {displayStreak > 0 && (
            <div className="glass-card rounded-2xl p-6 mb-6 inline-block">
              <div className="flex items-center gap-3">
                <span className="text-4xl">🔥</span>
                <div>
                  <div className="text-3xl font-black" style={{color: '#f0c040'}}>{displayStreak}</div>
                  <div className="text-sm text-white/60">أيام متتالية</div>
                </div>
              </div>
              {dailyData.bestStreak > displayStreak && (
                <div className="text-xs text-white/40 mt-2">أفضل سلسلة: {dailyData.bestStreak} يوم</div>
              )}
            </div>
          )}

          <div className="text-sm text-white/50 mb-6">عد غداً لتحدٍ جديد! 📅</div>
        </div>

        <div className="flex gap-3">
          <button onClick={onBack} className="flex-1 btn-primary text-center">🏠 القائمة الرئيسية</button>
          <button onClick={() => {
            const text = `⚽ VS Football Quiz - التحدي اليومي\n\n⭐ النتيجة: ${displayScore}/5\n🔥 سلسلة: ${displayStreak} يوم\n\nالعب الآن!`;
            if (navigator.share) navigator.share({ title: 'VS Football Quiz', text });
            else { navigator.clipboard.writeText(text); alert('تم نسخ النتيجة!'); }
          }} className="flex-1 btn-secondary text-center">📤 مشاركة</button>
        </div>
      </div>
    );
  }

  if (!questions.length) return null;
  const q = questions[currentQ];

  return (
    <div className="animate-fadeIn max-w-2xl mx-auto">
      <div className="flex items-center justify-between mb-4">
        <button onClick={onBack} className="btn-secondary text-sm px-4 py-2">← القائمة</button>
        <h2 className="text-xl font-bold">📅 التحدي اليومي</h2>
        <div className="flex items-center gap-1">
          {dailyData.streak > 0 && <span className="text-sm">🔥 {dailyData.streak}</span>}
        </div>
      </div>

      {/* Progress */}
      <div className="glass-card rounded-xl p-3 mb-4">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm text-white/60">السؤال {currentQ + 1} من 5</span>
          <span className="text-sm font-bold" style={{color: '#f0c040'}}>✅ {score}</span>
        </div>
        <div className="flex gap-1">
          {[0, 1, 2, 3, 4].map(i => (
            <div key={i} className="flex-1 h-2 rounded-full transition-all" style={{
              background: i < currentQ ? (i < score ? '#22c55e' : '#ef4444') : i === currentQ ? 'rgba(212,160,23,0.6)' : 'rgba(255,255,255,0.1)'
            }} />
          ))}
        </div>
      </div>

      {/* Question */}
      <div className="glass-card rounded-2xl p-6 mb-6 text-center animate-slideUp">
        {q.question}
      </div>

      {/* Options */}
      <div className={`grid gap-3 mb-6 ${q.options.length === 2 ? 'grid-cols-2' : 'grid-cols-1 md:grid-cols-2'}`}>
        {q.options.map((option, i) => (
          <button key={i} onClick={() => handleAnswer(option)}
            className={`option-btn ${answered && option === q.correctAnswer ? 'correct' : ''} ${answered && option === selected && option !== q.correctAnswer ? 'wrong' : ''}`}
            disabled={answered}>
            {option}
          </button>
        ))}
      </div>

      {/* Result */}
      {answered && (
        <div className="text-center animate-bounceIn">
          <div className={`text-xl font-bold mb-2 ${selected === q.correctAnswer ? 'text-green-400' : 'text-red-400'}`}>
            {selected === q.correctAnswer ? '✅ إجابة صحيحة!' : `❌ خطأ! الجواب: ${q.correctAnswer}`}
          </div>
          {showExplanation && (
            <div className="glass-card rounded-xl p-3 mb-3 mx-auto max-w-lg text-sm">
              <p className="text-white/70">💡 {showExplanation}</p>
            </div>
          )}
          <button onClick={nextQuestion} className="btn-primary">
            {currentQ >= 4 ? 'عرض النتيجة 🏆' : 'التالي ←'}
          </button>
        </div>
      )}
    </div>
  );
}
