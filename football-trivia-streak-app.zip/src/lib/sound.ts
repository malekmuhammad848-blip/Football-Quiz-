/* Tiny synthesized sound engine — no audio files needed.
   All sounds are generated with the Web Audio API so they work offline. */

export type SoundKind = 'correct' | 'wrong' | 'open' | 'select' | 'milestone' | 'toggle';

let ctx: AudioContext | null = null;

function ac(): AudioContext | null {
  try {
    if (!ctx) {
      const AC = window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AC) return null;
      ctx = new AC();
    }
    if (ctx.state === 'suspended') void ctx.resume();
    return ctx;
  } catch {
    return null;
  }
}

/** Call on any user gesture to unlock audio on mobile browsers. */
export function unlockAudio() {
  ac();
}

interface NoteOpts {
  freq: number;
  at: number; // seconds offset from now
  dur: number;
  type?: OscillatorType;
  vol?: number;
  slideTo?: number;
}

function note(c: AudioContext, { freq, at, dur, type = 'sine', vol = 0.2, slideTo }: NoteOpts) {
  const t0 = c.currentTime + at;
  const osc = c.createOscillator();
  const gain = c.createGain();
  osc.type = type;
  osc.frequency.setValueAtTime(freq, t0);
  if (slideTo) osc.frequency.exponentialRampToValueAtTime(slideTo, t0 + dur);
  gain.gain.setValueAtTime(0.0001, t0);
  gain.gain.exponentialRampToValueAtTime(vol, t0 + 0.015);
  gain.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
  osc.connect(gain).connect(c.destination);
  osc.start(t0);
  osc.stop(t0 + dur + 0.05);
}

function chord(c: AudioContext, freqs: number[], opts: Partial<NoteOpts> = {}) {
  freqs.forEach((f) => note(c, { freq: f, ...opts } as NoteOpts));
}

export function play(kind: SoundKind, enabled: boolean) {
  if (!enabled) return;
  const c = ac();
  if (!c) return;
  try {
    switch (kind) {
      case 'correct': {
        // bright ascending major arpeggio + soft top shimmer
        const seq = [523.25, 659.25, 783.99, 1046.5];
        seq.forEach((f, i) => note(c, { freq: f, at: i * 0.085, dur: 0.34, type: 'triangle', vol: 0.22 }));
        chord(c, [1046.5, 1318.5], { at: 0.36, dur: 0.5, type: 'sine', vol: 0.12 });
        break;
      }
      case 'wrong': {
        // descending dissonant thunk
        note(c, { freq: 185, at: 0, dur: 0.28, type: 'sawtooth', vol: 0.13, slideTo: 120 });
        note(c, { freq: 175, at: 0.02, dur: 0.3, type: 'square', vol: 0.06, slideTo: 110 });
        note(c, { freq: 98, at: 0.16, dur: 0.4, type: 'triangle', vol: 0.16, slideTo: 70 });
        break;
      }
      case 'open': {
        // soft airy "whoosh pop"
        note(c, { freq: 420, at: 0, dur: 0.16, type: 'sine', vol: 0.1, slideTo: 760 });
        note(c, { freq: 880, at: 0.07, dur: 0.2, type: 'sine', vol: 0.08 });
        break;
      }
      case 'select': {
        note(c, { freq: 620, at: 0, dur: 0.09, type: 'sine', vol: 0.1, slideTo: 500 });
        break;
      }
      case 'milestone': {
        // triumphant stadium fanfare
        const seq = [523.25, 659.25, 783.99, 1046.5, 1318.5];
        seq.forEach((f, i) => note(c, { freq: f, at: i * 0.1, dur: 0.32, type: 'triangle', vol: 0.2 }));
        chord(c, [1046.5, 1318.5, 1568], { at: 0.5, dur: 0.7, type: 'triangle', vol: 0.14 });
        chord(c, [2093, 2637], { at: 0.62, dur: 0.6, type: 'sine', vol: 0.06 });
        break;
      }
      case 'toggle': {
        note(c, { freq: 540, at: 0, dur: 0.08, type: 'sine', vol: 0.08 });
        note(c, { freq: 680, at: 0.06, dur: 0.1, type: 'sine', vol: 0.08 });
        break;
      }
    }
  } catch {
    /* ignore audio errors */
  }
}
