import { QUESTIONS } from '../data/questions';
import { PHRASES } from '../data/phrases';

export const MILESTONES = [7, 14, 30, 50, 100, 200, 365];

export interface DayResult {
  date: string;
  status: 'correct' | 'wrong';
  picked: number;
  prevStreak: number;
  phraseIdx: number;
  milestone: boolean;
}

export interface Settings {
  theme: 'dark' | 'light';
  sound: boolean;
  notify: boolean;
}

export interface PersistedState {
  streak: number;
  best: number;
  lastSolved: string | null;
  today: DayResult | null;
  lastPhrase: number;
  totalCorrect: number;
  totalWrong: number;
  settings: Settings;
}

const KEY = 'with-daood:v1';

const DEFAULTS: PersistedState = {
  streak: 0,
  best: 0,
  lastSolved: null,
  today: null,
  lastPhrase: -1,
  totalCorrect: 0,
  totalWrong: 0,
  settings: { theme: 'dark', sound: true, notify: false },
};

/* ── date helpers (local timezone, YYYY-MM-DD keys) ── */

export function toKey(d: Date): string {
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

export function todayKey(): string {
  return toKey(new Date());
}

export function addDays(key: string, n: number): string {
  const [y, m, d] = key.split('-').map(Number);
  const dt = new Date(y, m - 1, d + n);
  return toKey(dt);
}

export function msUntilMidnight(): number {
  const now = new Date();
  const mid = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1, 0, 0, 0, 250);
  return mid.getTime() - now.getTime();
}

export function formatCountdown(ms: number): string {
  const s = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  const p = (n: number) => String(n).padStart(2, '0');
  return `${p(h)}:${p(m)}:${p(sec)}`;
}

/* ── persistence ── */

export function loadState(): PersistedState {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return { ...DEFAULTS };
    const parsed = JSON.parse(raw) as Partial<PersistedState>;
    const state: PersistedState = {
      ...DEFAULTS,
      ...parsed,
      settings: { ...DEFAULTS.settings, ...(parsed.settings ?? {}) },
    };
    // break the chain if user missed a day (last solve is older than yesterday)
    if (state.lastSolved) {
      const gap = daysBetween(state.lastSolved, todayKey());
      if (gap >= 2) state.streak = 0;
    }
    // stale day-result from a previous date → unanswered today
    if (state.today && state.today.date !== todayKey()) state.today = null;
    return state;
  } catch {
    return { ...DEFAULTS };
  }
}

export function saveState(s: PersistedState) {
  try {
    localStorage.setItem(KEY, JSON.stringify(s));
  } catch {
    /* storage unavailable — ignore */
  }
}

function daysBetween(a: string, b: string): number {
  const da = new Date(a + 'T00:00:00');
  const db = new Date(b + 'T00:00:00');
  return Math.round((db.getTime() - da.getTime()) / 86400000);
}

/* ── daily question & phrase selection ── */

export function questionIndexFor(dateKey: string): number {
  let h = 0;
  for (let i = 0; i < dateKey.length; i++) {
    h = (Math.imul(h, 31) + dateKey.charCodeAt(i)) >>> 0;
  }
  h = Math.imul(h ^ (h >>> 13), 2654435761) >>> 0;
  return h % QUESTIONS.length;
}

export function pickPhrase(last: number): number {
  if (PHRASES.length < 2) return 0;
  let idx = Math.floor(Math.random() * PHRASES.length);
  let guard = 0;
  while (idx === last && guard++ < 20) {
    idx = Math.floor(Math.random() * PHRASES.length);
  }
  return idx;
}

export function nextMilestone(streak: number): { prev: number; next: number } {
  for (const m of MILESTONES) {
    if (streak < m) {
      const prev = MILESTONES[MILESTONES.indexOf(m) - 1] ?? 0;
      return { prev, next: m };
    }
  }
  return { prev: MILESTONES[MILESTONES.length - 2], next: MILESTONES[MILESTONES.length - 1] };
}

export function milestoneLabel(n: number): string {
  switch (n) {
    case 7:
      return 'أسبوع كامل من التألق!';
    case 14:
      return 'أسبوعان متتاليان بلا توقف!';
    case 30:
      return 'شهر كامل... أنت أسطورة حقيقية!';
    case 50:
      return 'خمسون يوماً ذهبية!';
    case 100:
      return 'مئة يوم! إنجاز تاريخي نادر!';
    case 200:
      return 'مئتا يوم... ما هذا الإصرار؟';
    case 365:
      return 'عام كامل! لا يُصدَّق!';
    default:
      return 'إنجاز رائع!';
  }
}

/* Arabic plural-aware day label (noun only) */
export function daysLabel(n: number): string {
  if (n === 1) return 'يوم واحد';
  if (n === 2) return 'يومان';
  if (n >= 3 && n <= 10) return 'أيام';
  return 'يوماً';
}

/* full counting phrase: 1 → "يوم واحد", 2 → "يومين", 5 → "5 أيام", 12 → "12 يوماً" */
export function daysCount(n: number): string {
  if (n === 1) return 'يوم واحد';
  if (n === 2) return 'يومين';
  if (n >= 3 && n <= 10) return `${n} أيام`;
  return `${n} يوماً`;
}

/* streak continuation phrase shown under the orb number */
export function streakPhrase(n: number): string {
  if (n === 1) return 'يوم متتالٍ';
  if (n === 2) return 'يومان متتاليان';
  if (n >= 3 && n <= 10) return 'أيام متتالية';
  return 'يوماً متتالياً';
}
