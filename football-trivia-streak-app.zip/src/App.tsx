import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import confetti from 'canvas-confetti';
import { Settings as SettingsIcon, Sparkles, Check } from 'lucide-react';

import { QUESTIONS } from './data/questions';
import { PHRASES } from './data/phrases';
import {
  addDays,
  loadState,
  saveState,
  todayKey,
  questionIndexFor,
  pickPhrase,
  MILESTONES,
  daysCount,
  type PersistedState,
  type Settings,
} from './lib/store';
import { play, unlockAudio } from './lib/sound';
import StreakOrb from './components/StreakOrb';
import QuestionCard from './components/QuestionCard';
import { SuccessPanel, WrongPanel } from './components/ResultPanels';
import SettingsSheet from './components/SettingsSheet';

export default function App() {
  const [state, setState] = useState<PersistedState>(loadState);
  const [dateKey, setDateKey] = useState(todayKey);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [notifyDenied, setNotifyDenied] = useState(false);
  const [flash, setFlash] = useState<'ok' | 'bad' | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  const soundOn = state.settings.sound;

  /* ── persist + theme ── */
  useEffect(() => saveState(state), [state]);

  useEffect(() => {
    document.documentElement.dataset.theme = state.settings.theme;
    const meta = document.querySelector('meta[name="theme-color"]');
    meta?.setAttribute('content', state.settings.theme === 'dark' ? '#05080a' : '#f3f5ec');
  }, [state.settings.theme]);

  /* ── unlock audio on first gesture ── */
  useEffect(() => {
    const unlock = () => {
      unlockAudio();
      play('open', soundOn);
    };
    window.addEventListener('pointerdown', unlock, { once: true });
    return () => window.removeEventListener('pointerdown', unlock);
  }, [soundOn]);

  /* ── midnight watcher: rotate question, re-evaluate the chain ── */
  useEffect(() => {
    const t = window.setInterval(() => {
      const k = todayKey();
      if (k !== dateKey) {
        setDateKey(k);
        setState(loadState());
        play('open', soundOn);
      }
    }, 5000);
    return () => window.clearInterval(t);
  }, [dateKey, soundOn]);

  /* ── derived daily values ── */
  const qIdx = useMemo(() => questionIndexFor(dateKey), [dateKey]);
  const question = QUESTIONS[qIdx];
  const result = state.today && state.today.date === dateKey ? state.today : null;
  const phrase = result ? PHRASES[result.phraseIdx] ?? PHRASES[0] : '';

  const todayFmt = useMemo(
    () => new Intl.DateTimeFormat('ar', { weekday: 'long', day: 'numeric', month: 'long' }).format(new Date()),
    [dateKey],
  );

  /* ── rotating fact ticker ── */
  const [factIdx, setFactIdx] = useState(3);
  useEffect(() => {
    const t = window.setInterval(() => setFactIdx((i) => (i + 7) % QUESTIONS.length), 6000);
    return () => window.clearInterval(t);
  }, []);
  const tickerFact = QUESTIONS[factIdx]?.fact ?? '';

  /* ── answer handling ── */
  const fireConfetti = useCallback((milestone: boolean, theme: 'dark' | 'light') => {
    const base =
      theme === 'dark' ? ['#b3f23c', '#7ed321', '#eaffd0', '#ffffff'] : ['#3f8a10', '#67b02a', '#bee38a', '#123308'];
    const gold = ['#ffd24d', '#ffde8a', '#fff3cf', '#ffffff'];
    const colors = milestone ? gold : base;
    confetti({ particleCount: milestone ? 160 : 100, spread: milestone ? 100 : 75, origin: { y: 0.55 }, colors, disableForReducedMotion: true });
    if (milestone) {
      window.setTimeout(() => confetti({ particleCount: 80, angle: 60, spread: 70, origin: { x: 0, y: 0.7 }, colors: gold, shapes: ['star'], scalar: 1.1, disableForReducedMotion: true }), 220);
      window.setTimeout(() => confetti({ particleCount: 80, angle: 120, spread: 70, origin: { x: 1, y: 0.7 }, colors: gold, shapes: ['star'], scalar: 1.1, disableForReducedMotion: true }), 380);
    } else {
      window.setTimeout(() => confetti({ particleCount: 50, angle: 60, spread: 60, origin: { x: 0.08, y: 0.75 }, colors, disableForReducedMotion: true }), 160);
      window.setTimeout(() => confetti({ particleCount: 50, angle: 120, spread: 60, origin: { x: 0.92, y: 0.75 }, colors, disableForReducedMotion: true }), 260);
    }
  }, []);

  const handleReveal = useCallback(
    (correct: boolean) => {
      const prospective = correct ? (state.lastSolved === addDays(dateKey, -1) ? state.streak + 1 : 1) : 0;
      const milestone = MILESTONES.includes(prospective);
      play(correct ? (milestone ? 'milestone' : 'correct') : 'wrong', soundOn);
      setFlash(correct ? 'ok' : 'bad');
      window.setTimeout(() => setFlash(null), 950);
      if (correct) fireConfetti(milestone, state.settings.theme);
    },
    [soundOn, state.lastSolved, state.streak, state.settings.theme, dateKey, fireConfetti],
  );

  const handleComplete = useCallback(
    (picked: number, correct: boolean) => {
      setState((prev) => {
        if (prev.today?.date === dateKey) return prev; // already answered
        const prevStreak = prev.streak;
        if (correct) {
          const newStreak = prev.lastSolved === addDays(dateKey, -1) ? prev.streak + 1 : 1;
          const milestone = MILESTONES.includes(newStreak);
          const pIdx = pickPhrase(prev.lastPhrase);
          return {
            ...prev,
            streak: newStreak,
            best: Math.max(prev.best, newStreak),
            lastSolved: dateKey,
            lastPhrase: pIdx,
            totalCorrect: prev.totalCorrect + 1,
            today: { date: dateKey, status: 'correct', picked, prevStreak, phraseIdx: pIdx, milestone },
          };
        }
        return {
          ...prev,
          streak: 0,
          totalWrong: prev.totalWrong + 1,
          today: { date: dateKey, status: 'wrong', picked, prevStreak, phraseIdx: 0, milestone: false },
        };
      });
    },
    [dateKey],
  );

  /* ── settings handlers ── */
  const changeSettings = (s: Settings) => {
    play('toggle', soundOn);
    if (s.notify && !state.settings.notify) {
      if (!('Notification' in window)) {
        setToast('متصفحك لا يدعم الإشعارات');
        return;
      }
      Notification.requestPermission().then((p) => {
        if (p === 'granted') {
          setState((prev) => ({ ...prev, settings: { ...prev.settings, notify: true } }));
          setToast('تم تفعيل التذكير اليومي');
        } else {
          setNotifyDenied(true);
        }
      });
      return;
    }
    setState((prev) => ({ ...prev, settings: s }));
  };

  /* ── daily reminder (fires at 20:00 while the app is open) ── */
  const reminderRef = useRef<number | null>(null);
  useEffect(() => {
    if (reminderRef.current) window.clearTimeout(reminderRef.current);
    if (!state.settings.notify || result) return;
    if (!('Notification' in window) || Notification.permission !== 'granted') return;

    const now = new Date();
    const eightPm = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 20, 0, 0);
    const delay = eightPm.getTime() > now.getTime() ? eightPm.getTime() - now.getTime() : 45 * 60 * 1000;

    reminderRef.current = window.setTimeout(() => {
      const body =
        state.streak > 0
          ? `سلسلتك (${daysCount(state.streak)}) تنتظرك — حل سؤال الليلة قبل منتصف الليل!`
          : 'سؤال كرة القدم اليومي بانتظارك — ابدأ سلسلتك الليلة!';
      const n = new Notification('with daood — سؤال اليوم', { body, dir: 'rtl', lang: 'ar' });
      n.onclick = () => window.focus();
    }, delay);

    return () => {
      if (reminderRef.current) window.clearTimeout(reminderRef.current);
    };
  }, [state.settings.notify, state.streak, result, dateKey]);

  /* ── toast auto-dismiss ── */
  useEffect(() => {
    if (!toast) return;
    const t = window.setTimeout(() => setToast(null), 2600);
    return () => window.clearTimeout(t);
  }, [toast]);

  /* ── share ── */
  const share = async () => {
    const text = `وصلت سلسلة ${daysCount(state.streak)} في with daood — سؤال كرة القدم اليومي. هل تلحق بي؟`;
    try {
      if (navigator.share) await navigator.share({ title: 'with daood', text });
      else {
        await navigator.clipboard.writeText(text);
        setToast('نُسخ! شاركه أين تحب');
      }
    } catch {
      /* user cancelled */
    }
  };

  const answered = !!result;
  const goldOrb = result?.status === 'correct' && result.milestone;

  return (
    <div className="relative min-h-dvh overflow-hidden">
      {/* ── ambient background ── */}
      <div className="pointer-events-none absolute inset-0" aria-hidden>
        <div className="blob drift-a h-[420px] w-[420px] -top-32 -right-24" style={{ background: 'var(--blob-1)' }} />
        <div className="blob drift-b h-[520px] w-[520px] top-[45%] -left-40" style={{ background: 'var(--blob-2)' }} />
        <div className="pitch-lines" />
        {/* pitch center circle */}
        <div
          className="absolute left-1/2 top-24 h-[560px] w-[560px] -translate-x-1/2 rounded-full"
          style={{ border: '1.5px solid var(--pitch-line)' }}
        />
      </div>
      <div className="grain" aria-hidden />

      {/* ── answer flash overlay ── */}
      <AnimatePresence>
        {flash && (
          <motion.div
            key={flash}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.35 }}
            className="pointer-events-none fixed inset-0 z-30"
            style={{
              background:
                flash === 'ok'
                  ? 'radial-gradient(ellipse 120% 90% at 50% 50%, transparent 55%, var(--ok-soft) 100%), radial-gradient(ellipse 120% 90% at 50% 50%, transparent 40%, color-mix(in srgb, var(--accent) 22%, transparent) 100%)'
                  : 'radial-gradient(ellipse 120% 90% at 50% 50%, transparent 55%, var(--danger-soft) 100%)',
            }}
          />
        )}
      </AnimatePresence>

      {/* ── page ── */}
      <div className="relative z-10 mx-auto flex min-h-dvh w-full max-w-lg flex-col px-5 pb-10 pt-6 md:max-w-xl">
        {/* header */}
        <motion.header
          initial={{ opacity: 0, y: -16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
          className="mb-6 flex items-center justify-between"
        >
          <div>
            <div className="font-latin text-[22px] font-bold leading-none tracking-tight" style={{ color: 'var(--ink)' }} dir="ltr">
              with daood<span style={{ color: 'var(--accent)' }}>.</span>
            </div>
            <div className="mt-1.5 text-[11px] font-bold" style={{ color: 'var(--muted)' }}>
              سؤال كرة القدم اليومي
            </div>
          </div>
          <div className="flex items-center gap-2.5">
            <span
              className="glass flex items-center gap-2 rounded-full px-3.5 py-2 text-[11px] font-bold"
              style={{ color: 'var(--muted)' }}
            >
              <span className="ping-dot relative h-1.5 w-1.5 rounded-full" style={{ background: 'var(--accent)' }} />
              {todayFmt}
            </span>
            <button
              onClick={() => {
                play('open', soundOn);
                setSettingsOpen(true);
              }}
              aria-label="الإعدادات"
              className="glass flex h-10 w-10 items-center justify-center rounded-full transition-transform hover:rotate-12 active:scale-90"
              style={{ color: 'var(--ink)' }}
            >
              <SettingsIcon size={18} strokeWidth={2.2} />
            </button>
          </div>
        </motion.header>

        {/* streak orb */}
        <motion.section
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.65, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
          className="mb-6"
        >
          <StreakOrb
            streak={state.streak}
            best={state.best}
            totalCorrect={state.totalCorrect}
            celebrateKey={state.streak}
            gold={goldOrb}
          />
        </motion.section>

        {/* fact ticker */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.6 }}
          className="mb-6 flex items-start gap-2 rounded-2xl px-4 py-2.5"
          style={{ background: 'var(--card-2)', border: '1px solid var(--line)' }}
        >
          <Sparkles size={14} strokeWidth={2.4} className="mt-0.5 shrink-0" style={{ color: 'var(--accent)' }} />
          <AnimatePresence mode="wait">
            <motion.p
              key={factIdx}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.4 }}
              className="text-[11.5px] font-semibold leading-relaxed"
              style={{ color: 'var(--muted)' }}
            >
              {tickerFact}
            </motion.p>
          </AnimatePresence>
        </motion.div>

        {/* main card */}
        <main className="flex-1">
          <AnimatePresence mode="wait">
            {!answered ? (
              <QuestionCard
                key="question"
                question={question}
                dayNumber={qIdx + 1}
                onReveal={handleReveal}
                onComplete={handleComplete}
                playSelect={() => play('select', soundOn)}
              />
            ) : result.status === 'correct' ? (
              <SuccessPanel
                key="success"
                result={result}
                question={question}
                phrase={phrase}
                streak={state.streak}
                onShare={share}
              />
            ) : (
              <WrongPanel key="wrong" result={result} question={question} />
            )}
          </AnimatePresence>
        </main>

        {/* footer */}
        <motion.footer
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.55, duration: 0.7 }}
          className="mt-8 text-center"
        >
          <p className="text-[10px] font-bold tracking-wide" style={{ color: 'var(--faint)' }}>
            صُنع من قبل <span className="font-latin" dir="ltr">malek</span> — عُد غداً لسؤال جديد
          </p>
        </motion.footer>
      </div>

      {/* settings sheet */}
      <SettingsSheet
        open={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        settings={state.settings}
        onChange={changeSettings}
        notifyDenied={notifyDenied}
      />

      {/* toast */}
      <AnimatePresence>
        {toast && (
          <motion.div
            key="toast"
            initial={{ opacity: 0, y: 24, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 12, scale: 0.95 }}
            transition={{ type: 'spring', stiffness: 400, damping: 28 }}
            className="fixed bottom-6 left-1/2 z-[60] flex -translate-x-1/2 items-center gap-2 rounded-full px-5 py-3 text-xs font-bold"
            style={{ background: 'var(--ink)', color: 'var(--bg)', boxShadow: 'var(--shadow)' }}
          >
            <Check size={14} strokeWidth={3} style={{ color: 'var(--accent)' }} />
            {toast}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
