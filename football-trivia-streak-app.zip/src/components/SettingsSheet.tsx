import { motion, AnimatePresence } from 'framer-motion';
import { X, Sun, Moon, Volume2, VolumeX, Bell, BellOff, Info, HeartHandshake } from 'lucide-react';
import type { Settings } from '../lib/store';

interface Props {
  open: boolean;
  onClose: () => void;
  settings: Settings;
  onChange: (s: Settings) => void;
  notifyDenied: boolean;
}

export default function SettingsSheet({ open, onClose, settings, onChange, notifyDenied }: Props) {
  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
            onClick={onClose}
            className="fixed inset-0 z-50"
            style={{ background: 'rgba(0,0,0,0.55)', backdropFilter: 'blur(6px)' }}
          />
          <div className="pointer-events-none fixed inset-0 z-50 flex items-end justify-center md:items-center md:p-6">
            <motion.div
              initial={{ y: '110%', opacity: 0.5 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: '110%', opacity: 0.5 }}
              transition={{ type: 'spring', stiffness: 300, damping: 32 }}
              className="pointer-events-auto w-full max-w-lg rounded-t-[32px] p-6 pb-10 md:rounded-[32px] md:pb-6"
              style={{ background: 'var(--card)', border: '1px solid var(--line)', boxShadow: 'var(--shadow)' }}
              role="dialog"
              aria-label="الإعدادات"
            >
            {/* header */}
            <div className="mb-6 flex items-center justify-between">
              <h2 className="text-xl font-black" style={{ color: 'var(--ink)' }}>الإعدادات</h2>
              <button
                onClick={onClose}
                aria-label="إغلاق"
                className="flex h-9 w-9 items-center justify-center rounded-full transition-transform active:scale-90"
                style={{ background: 'var(--accent-soft)', color: 'var(--muted)' }}
              >
                <X size={17} strokeWidth={2.5} />
              </button>
            </div>

            <div className="grid gap-3">
              {/* theme */}
              <Row
                icon={settings.theme === 'dark' ? <Moon size={18} /> : <Sun size={18} />}
                title="المظهر"
                desc={settings.theme === 'dark' ? 'داكن — ملعب الليل' : 'فاتح — ملعب النهار'}
                control={
                  <Toggle
                    on={settings.theme === 'light'}
                    onToggle={() => onChange({ ...settings, theme: settings.theme === 'dark' ? 'light' : 'dark' })}
                    ariaLabel="تبديل المظهر"
                  />
                }
              />

              {/* sound */}
              <Row
                icon={settings.sound ? <Volume2 size={18} /> : <VolumeX size={18} />}
                title="المؤثرات الصوتية"
                desc={settings.sound ? 'مفعّلة — أصوات عند الإجابة والتنقل' : 'صامت — بلا مؤثرات'}
                control={
                  <Toggle
                    on={settings.sound}
                    onToggle={() => onChange({ ...settings, sound: !settings.sound })}
                    ariaLabel="تبديل الصوت"
                  />
                }
              />

              {/* notifications */}
              <Row
                icon={settings.notify ? <Bell size={18} /> : <BellOff size={18} />}
                title="تذكير يومي"
                desc={
                  notifyDenied
                    ? 'المتصفح رفض الإذن — فعّله من إعدادات المتصفح'
                    : settings.notify
                      ? 'سيصلك تذكير مسائي إن لم تُجب بعد'
                      : 'ذكّرني قبل نهاية اليوم حتى لا تنكسر السلسلة'
                }
                control={
                  <Toggle
                    on={settings.notify}
                    onToggle={() => onChange({ ...settings, notify: !settings.notify })}
                    ariaLabel="تبديل التذكير"
                  />
                }
              />
            </div>

            {/* about */}
            <div
              className="mt-6 rounded-3xl p-5 text-center"
              style={{ background: 'var(--accent-soft)', border: '1px solid var(--line)' }}
            >
              <div className="mb-1.5 flex items-center justify-center gap-1.5 text-[11px] font-extrabold" style={{ color: 'var(--accent)' }}>
                <Info size={13} strokeWidth={2.5} />
                حول التطبيق
              </div>
              <p className="text-sm font-extrabold leading-relaxed" style={{ color: 'var(--ink)' }}>
                سؤال كرة قدم جديد كل يوم، سلسلة تحميها، ومعرفة تكبر معك.
              </p>
              <p className="mt-2 flex items-center justify-center gap-1.5 text-[13px] font-bold" style={{ color: 'var(--muted)' }}>
                <HeartHandshake size={15} strokeWidth={2.2} style={{ color: 'var(--accent)' }} />
                صُنع من قبل <span className="font-latin font-bold" style={{ color: 'var(--accent)' }} dir="ltr">malek</span>
              </p>
              <p className="mt-1.5 font-latin text-[10px] font-semibold tracking-widest" style={{ color: 'var(--faint)' }} dir="ltr">
                WITH DAOOD · v1.0
              </p>
            </div>
            </motion.div>
          </div>
        </>
      )}
    </AnimatePresence>
  );
}

/* ── little pieces ── */
function Row({ icon, title, desc, control }: { icon: React.ReactNode; title: string; desc: string; control: React.ReactNode }) {
  return (
    <div className="flex items-center gap-3.5 rounded-3xl p-4" style={{ border: '1px solid var(--line)', background: 'var(--card-2)' }}>
      <div
        className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl"
        style={{ background: 'var(--accent-soft)', color: 'var(--accent)' }}
      >
        {icon}
      </div>
      <div className="min-w-0 flex-1">
        <div className="text-sm font-extrabold" style={{ color: 'var(--ink)' }}>{title}</div>
        <div className="text-[11px] font-semibold leading-snug" style={{ color: 'var(--muted)' }}>{desc}</div>
      </div>
      {control}
    </div>
  );
}

function Toggle({ on, onToggle, ariaLabel }: { on: boolean; onToggle: () => void; ariaLabel: string }) {
  return (
    <button
      onClick={onToggle}
      aria-label={ariaLabel}
      aria-pressed={on}
      className="relative h-8 w-[52px] shrink-0 rounded-full transition-colors duration-300"
      style={{ background: on ? 'var(--accent)' : 'var(--line-strong)' }}
    >
      <motion.span
        layout
        transition={{ type: 'spring', stiffness: 550, damping: 32 }}
        className="absolute top-1 h-6 w-6 rounded-full"
        style={{
          background: on ? 'var(--accent-contrast)' : 'var(--card)',
          right: on ? 4 : 'calc(100% - 28px)',
          boxShadow: '0 2px 6px rgba(0,0,0,0.25)',
        }}
      />
    </button>
  );
}
