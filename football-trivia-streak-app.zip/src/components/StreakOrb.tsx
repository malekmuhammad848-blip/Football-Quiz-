import { useEffect, useRef } from 'react';
import { motion, useAnimate } from 'framer-motion';
import { Flame, Trophy, CircleCheckBig } from 'lucide-react';
import { daysCount, streakPhrase, nextMilestone } from '../lib/store';

interface Props {
  streak: number;
  best: number;
  totalCorrect: number;
  celebrateKey: number; // bump this to replay the pop animation
  gold?: boolean;
}

const R = 84;
const CIRC = 2 * Math.PI * R;

export default function StreakOrb({ streak, best, totalCorrect, celebrateKey, gold }: Props) {
  const { prev, next } = nextMilestone(streak);
  const span = Math.max(1, next - prev);
  const frac = Math.min(1, Math.max(0.06, (streak - prev) / span));
  const remaining = next - streak;

  const accent = gold ? 'var(--gold)' : 'var(--accent)';

  // pop the orb only when the streak value actually changes
  const [scope, animate] = useAnimate();
  const prevKey = useRef(celebrateKey);
  useEffect(() => {
    if (prevKey.current === celebrateKey) return;
    prevKey.current = celebrateKey;
    animate(scope.current, { scale: [1, 1.16, 1] }, { duration: 0.75, ease: [0.2, 1.4, 0.4, 1] });
  }, [celebrateKey, animate, scope]);

  return (
    <div className="flex flex-col items-center gap-5">
      {/* ── the orb ── */}
      <motion.div ref={scope} className="relative">
        {/* glow */}
        <div
          className="absolute -inset-10 rounded-full blur-3xl transition-opacity duration-700"
          style={{ background: `radial-gradient(circle, ${accent}40, transparent 65%)`, opacity: streak > 0 ? 1 : 0.35 }}
        />
        <svg width="200" height="200" viewBox="0 0 200 200" className="relative -rotate-90">
          <circle cx="100" cy="100" r={R} fill="none" stroke="var(--line)" strokeWidth="9" />
          <motion.circle
            cx="100"
            cy="100"
            r={R}
            fill="none"
            stroke={accent}
            strokeWidth="9"
            strokeLinecap="round"
            strokeDasharray={CIRC}
            initial={{ strokeDashoffset: CIRC }}
            animate={{ strokeDashoffset: CIRC * (1 - frac) }}
            transition={{ duration: 1.3, ease: [0.22, 1, 0.36, 1] }}
            style={{ filter: `drop-shadow(0 0 10px ${accent})` }}
          />
        </svg>

        {/* center content */}
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-0.5">
          <motion.div className={streak > 0 ? 'flame-anim' : ''} style={{ color: streak > 0 ? accent : 'var(--faint)' }}>
            <Flame size={26} strokeWidth={2.4} fill={streak > 0 ? accent : 'none'} fillOpacity={0.25} />
          </motion.div>
          <div
            className="font-latin tnum leading-none font-bold"
            style={{ fontSize: 58, letterSpacing: '-0.04em', color: streak > 0 ? 'var(--ink)' : 'var(--faint)' }}
          >
            {streak}
          </div>
          <div className="text-[11px] font-semibold" style={{ color: 'var(--muted)' }}>
            {streak === 0 ? 'ابدأ سلسلتك اليوم' : streakPhrase(streak)}
          </div>
        </div>
      </motion.div>

      {/* ── chips row ── */}
      <div className="flex flex-wrap items-stretch justify-center gap-2.5">
        <Chip
          icon={<Trophy size={15} strokeWidth={2.2} style={{ color: 'var(--gold)' }} />}
          label="أفضل سلسلة"
          value={String(best)}
          sub={best === 0 ? 'لم تبدأ بعد' : daysCount(best)}
        />
        <Chip
          icon={<CircleCheckBig size={15} strokeWidth={2.2} style={{ color: 'var(--ok)' }} />}
          label="إجابات صحيحة"
          value={String(totalCorrect)}
          sub="إجمالي"
        />
        <div
          className="flex flex-col items-center justify-center rounded-2xl px-4 py-2"
          style={{ background: 'var(--accent-soft)', border: '1px solid var(--line)' }}
        >
          <span className="text-[10px] font-bold" style={{ color: 'var(--muted)' }}>
            {streak === 0 ? 'الهدف الأول' : 'الإنجاز القادم'}
          </span>
          <span className="font-latin tnum text-lg font-bold leading-tight" style={{ color: accent }}>
            {next}
          </span>
          <span className="text-[10px] font-semibold" style={{ color: 'var(--muted)' }}>
            {remaining === 0 ? 'حققته اليوم' : `بقي ${daysCount(remaining)}`}
          </span>
        </div>
      </div>
    </div>
  );
}

function Chip({ icon, label, value, sub }: { icon: React.ReactNode; label: string; value: string; sub: string }) {
  return (
    <div
      className="flex flex-col items-center justify-center rounded-2xl px-4 py-2"
      style={{ background: 'var(--card)', border: '1px solid var(--line)' }}
    >
      <span className="flex items-center gap-1.5 text-[10px] font-bold" style={{ color: 'var(--muted)' }}>
        {icon}
        {label}
      </span>
      <span className="font-latin tnum text-lg font-bold leading-tight" style={{ color: 'var(--ink)' }}>
        {value}
      </span>
      <span className="text-[10px] font-semibold" style={{ color: 'var(--faint)' }}>{sub}</span>
    </div>
  );
}
