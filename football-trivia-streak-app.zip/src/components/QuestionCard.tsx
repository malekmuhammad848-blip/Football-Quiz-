import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Sparkles, Loader2, Check, X } from 'lucide-react';
import type { Question } from '../data/questions';

interface Props {
  question: Question;
  dayNumber: number;
  onReveal: (correct: boolean) => void;
  onComplete: (picked: number, correct: boolean) => void;
  playSelect: () => void;
}

type Phase = 'idle' | 'checking' | 'revealed';

const LETTERS = ['أ', 'ب', 'ج', 'د'];

export default function QuestionCard({ question, dayNumber, onReveal, onComplete, playSelect }: Props) {
  const [picked, setPicked] = useState<number | null>(null);
  const [phase, setPhase] = useState<Phase>('idle');

  const choose = (i: number) => {
    if (phase !== 'idle') return;
    playSelect();
    setPicked(i);
    setPhase('checking');
    // short suspense, then reveal
    window.setTimeout(() => setPhase('revealed'), 700);
  };

  useEffect(() => {
    if (phase !== 'idle') return;
    const onKey = (e: KeyboardEvent) => {
      const n = Number(e.key);
      if (n >= 1 && n <= 4) choose(n - 1);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  });

  // fire the reveal moment (sound/confetti), then hand the result to the parent
  useEffect(() => {
    if (phase !== 'revealed' || picked === null) return;
    onReveal(picked === question.answer);
    const t = window.setTimeout(() => onComplete(picked, picked === question.answer), 1500);
    return () => window.clearTimeout(t);
  }, [phase, picked, question.answer, onReveal, onComplete]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 26, scale: 0.98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: -22, scale: 0.98 }}
      transition={{ duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
      className="conic-frame card relative rounded-[28px] p-6 md:p-8"
      style={{ borderRadius: 28 }}
    >
      {/* header row */}
      <div className="mb-5 flex items-center justify-between gap-3">
        <span
          className="inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-[11px] font-bold"
          style={{ background: 'var(--accent-soft)', color: 'var(--accent)' }}
        >
          <Sparkles size={13} strokeWidth={2.4} />
          {question.category}
        </span>
        <span className="font-latin tnum text-[11px] font-semibold tracking-wider" style={{ color: 'var(--faint)' }}>
          #{String(dayNumber).padStart(3, '0')}
        </span>
      </div>

      {/* question */}
      <h2 className="mb-7 text-xl font-extrabold leading-[1.75] md:text-2xl md:leading-[1.7]" style={{ color: 'var(--ink)' }}>
        {question.q}
      </h2>

      {/* options */}
      <div className="grid gap-3">
        {question.options.map((opt, i) => {
          const isPicked = picked === i;
          const isAnswer = question.answer === i;
          const revealed = phase === 'revealed';

          let border = 'var(--line)';
          let bg = 'transparent';
          let color = 'var(--ink)';
          let extra: React.CSSProperties = {};

          if (phase === 'checking' && isPicked) {
            border = 'var(--accent)';
            bg = 'var(--accent-soft)';
          } else if (revealed && isAnswer) {
            border = 'var(--ok)';
            bg = 'var(--ok-soft)';
            color = 'var(--ok)';
            extra = { boxShadow: '0 0 0 1px var(--ok), 0 10px 30px -12px var(--ok)' };
          } else if (revealed && isPicked && !isAnswer) {
            border = 'var(--danger)';
            bg = 'var(--danger-soft)';
            color = 'var(--danger)';
          } else if (revealed) {
            color = 'var(--faint)';
          }

          return (
            <motion.button
              key={i}
              type="button"
              onClick={() => choose(i)}
              disabled={phase !== 'idle'}
              whileHover={phase === 'idle' ? { x: -5 } : undefined}
              whileTap={phase === 'idle' ? { scale: 0.985 } : undefined}
              animate={
                revealed && isPicked && !isAnswer
                  ? { x: [0, -7, 7, -5, 5, 0] }
                  : revealed && isAnswer
                    ? { scale: [1, 1.03, 1] }
                    : {}
              }
              transition={{ duration: 0.45 }}
              className="group relative flex w-full items-center gap-3.5 rounded-2xl border px-4 py-3.5 text-start transition-colors"
              style={{ borderColor: border, background: bg, color, ...extra }}
            >
              <span
                className="opt-key flex h-8 w-8 shrink-0 items-center justify-center rounded-xl text-sm font-bold transition-colors"
                style={{
                  background: revealed && isAnswer ? 'var(--ok)' : isPicked && phase !== 'idle' ? (revealed ? 'var(--danger)' : 'var(--accent)') : 'var(--accent-soft)',
                  color:
                    revealed && isAnswer
                      ? '#fff'
                      : isPicked && phase !== 'idle'
                        ? revealed
                          ? '#fff'
                          : 'var(--accent-contrast)'
                        : 'var(--accent)',
                }}
              >
                <AnimatePresence mode="wait" initial={false}>
                  {revealed && isAnswer ? (
                    <motion.span key="ok" initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: 'spring', stiffness: 500, damping: 20 }}>
                      <Check size={16} strokeWidth={3} />
                    </motion.span>
                  ) : revealed && isPicked ? (
                    <motion.span key="no" initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: 'spring', stiffness: 500, damping: 20 }}>
                      <X size={16} strokeWidth={3} />
                    </motion.span>
                  ) : (
                    <span key={i}>{LETTERS[i]}</span>
                  )}
                </AnimatePresence>
              </span>

              <span className="flex-1 text-[15px] font-bold leading-snug">{opt}</span>

              {phase === 'checking' && isPicked && (
                <Loader2 size={16} className="animate-spin" style={{ color: 'var(--accent)' }} />
              )}
            </motion.button>
          );
        })}
      </div>

      <p className="mt-5 text-center text-[11px] font-semibold" style={{ color: 'var(--faint)' }}>
        فرصة واحدة فقط — الإجابة الخاطئة تكسر السلسلة
      </p>
    </motion.div>
  );
}
