import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Check, X, Quote, Lightbulb, CalendarClock, Trophy, Share2, Flame } from 'lucide-react';
import type { Question } from '../data/questions';
import { formatCountdown, milestoneLabel, msUntilMidnight, daysCount, type DayResult } from '../lib/store';

/* ── shared countdown ── */
export function useMidnightCountdown() {
  const [ms, setMs] = useState(msUntilMidnight);
  useEffect(() => {
    const t = window.setInterval(() => setMs(msUntilMidnight()), 1000);
    return () => window.clearInterval(t);
  }, []);
  return ms;
}

function CountdownBar({ gold }: { gold?: boolean }) {
  const ms = useMidnightCountdown();
  return (
    <div
      className="flex items-center justify-center gap-2.5 rounded-2xl px-4 py-3"
      style={{ background: gold ? 'var(--gold-soft)' : 'var(--accent-soft)', border: '1px solid var(--line)' }}
    >
      <CalendarClock size={16} strokeWidth={2.2} style={{ color: gold ? 'var(--gold)' : 'var(--accent)' }} />
      <span className="text-xs font-bold" style={{ color: 'var(--muted)' }}>
        سؤال الغد يصل بعد
      </span>
      <span className="font-latin tnum text-sm font-bold tracking-wider" style={{ color: gold ? 'var(--gold)' : 'var(--accent)' }} dir="ltr">
        {formatCountdown(ms)}
      </span>
    </div>
  );
}

function FactCard({ fact }: { fact: string }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.5, duration: 0.5 }}
      className="rounded-2xl p-4"
      style={{ background: 'var(--card-2)', border: '1px dashed var(--line-strong)' }}
    >
      <div className="mb-1.5 flex items-center gap-1.5 text-[11px] font-extrabold" style={{ color: 'var(--gold)' }}>
        <Lightbulb size={14} strokeWidth={2.4} />
        هل تعلم؟
      </div>
      <p className="text-[13px] font-semibold leading-relaxed" style={{ color: 'var(--muted)' }}>
        {fact}
      </p>
    </motion.div>
  );
}

const panelAnim = {
  initial: { opacity: 0, y: 26, scale: 0.98 },
  animate: { opacity: 1, y: 0, scale: 1 },
  exit: { opacity: 0, y: -20, scale: 0.98 },
  transition: { duration: 0.5, ease: [0.22, 1, 0.36, 1] as const },
};

/* ══ SUCCESS ═══════════════════════════════════════════════ */
export function SuccessPanel({
  result,
  question,
  phrase,
  streak,
  onShare,
}: {
  result: DayResult;
  question: Question;
  phrase: string;
  streak: number;
  onShare: () => void;
}) {
  const gold = result.milestone;
  return (
    <motion.div {...panelAnim} className="card relative overflow-hidden rounded-[28px] p-6 md:p-8">
      {/* gold flash for milestones */}
      {gold && (
        <motion.div
          initial={{ opacity: 0.9 }}
          animate={{ opacity: 0 }}
          transition={{ duration: 1.6 }}
          className="pointer-events-none absolute inset-0"
          style={{ background: 'radial-gradient(circle at 50% 0%, var(--gold-soft), transparent 70%)' }}
        />
      )}

      <div className="flex flex-col items-center text-center">
        <motion.div
          initial={{ scale: 0, rotate: -30 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ type: 'spring', stiffness: 300, damping: 15 }}
          className="mb-4 flex h-16 w-16 items-center justify-center rounded-full"
          style={{
            background: gold ? 'var(--gold)' : 'var(--ok)',
            boxShadow: gold ? '0 0 50px -6px var(--gold)' : '0 0 50px -6px var(--ok)',
            color: '#fff',
          }}
        >
          {gold ? <Trophy size={28} strokeWidth={2.4} /> : <Check size={30} strokeWidth={3} />}
        </motion.div>

        <motion.h2
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="text-2xl font-black md:text-3xl"
          style={{ color: gold ? 'var(--gold)' : 'var(--ink)' }}
        >
          {gold ? milestoneLabel(streak) : 'إجابة صحيحة!'}
        </motion.h2>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.25 }}
          className="mt-1.5 text-sm font-bold"
          style={{ color: 'var(--muted)' }}
        >
          {result.prevStreak === 0
            ? 'سلسلتك بدأت للتو — بداية الأبطال'
            : streak > result.prevStreak
              ? `سلسلتك وصلت إلى ${daysCount(streak)}`
              : `ما زلت عند ${daysCount(streak)}`}
        </motion.p>

        {/* motivational phrase */}
        <motion.div
          initial={{ opacity: 0, y: 14, scale: 0.97 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ delay: 0.35, type: 'spring', stiffness: 120, damping: 16 }}
          className="mt-5 w-full rounded-3xl p-5"
          style={{ background: gold ? 'var(--gold-soft)' : 'var(--accent-soft)', border: '1px solid var(--line)' }}
        >
          <Quote size={18} className="mx-auto mb-2 -scale-x-100" style={{ color: gold ? 'var(--gold)' : 'var(--accent)' }} />
          <p className="text-lg font-extrabold leading-relaxed" style={{ color: 'var(--ink)' }}>
            {phrase}
          </p>
        </motion.div>

        <div className="mt-4 w-full">
          <FactCard fact={question.fact} />
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.65 }}
          className="mt-4 grid w-full gap-2.5"
        >
          <CountdownBar gold={gold} />
          <button
            onClick={onShare}
            className="flex items-center justify-center gap-2 rounded-2xl px-4 py-3 text-xs font-bold transition-transform active:scale-[0.98]"
            style={{ border: '1px solid var(--line-strong)', color: 'var(--muted)' }}
          >
            <Share2 size={14} strokeWidth={2.4} />
            شارك إنجازك مع أصدقائك
          </button>
        </motion.div>
      </div>
    </motion.div>
  );
}

/* ══ WRONG ═════════════════════════════════════════════════ */
export function WrongPanel({ result, question }: { result: DayResult; question: Question }) {
  const broke = result.prevStreak > 0;
  return (
    <motion.div {...panelAnim} className="card relative overflow-hidden rounded-[28px] p-6 md:p-8">
      <div className="flex flex-col items-center text-center">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: 'spring', stiffness: 300, damping: 14 }}
          className="mb-4 flex h-16 w-16 items-center justify-center rounded-full"
          style={{ background: 'var(--danger)', boxShadow: '0 0 50px -8px var(--danger)', color: '#fff' }}
        >
          <X size={30} strokeWidth={3} />
        </motion.div>

        <h2 className="text-2xl font-black md:text-3xl" style={{ color: 'var(--ink)' }}>
          إجابة خاطئة
        </h2>
        <p className="mt-1.5 text-sm font-bold leading-relaxed" style={{ color: 'var(--muted)' }}>
          الصحيح: <span style={{ color: 'var(--ok)' }}>{question.options[question.answer]}</span>
        </p>

        {broke ? (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.25 }}
            className="mt-5 flex w-full items-center justify-center gap-2.5 rounded-2xl px-4 py-3.5"
            style={{ background: 'var(--danger-soft)', border: '1px solid var(--line)' }}
          >
            <Flame size={17} strokeWidth={2.3} style={{ color: 'var(--faint)' }} />
            <span className="text-sm font-extrabold" style={{ color: 'var(--danger)' }}>
              انكسرت سلسلة الـ{daysCount(result.prevStreak)}... غداً نبدأ من جديد
            </span>
          </motion.div>
        ) : (
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.25 }}
            className="mt-5 text-sm font-bold"
            style={{ color: 'var(--muted)' }}
          >
            لم تبدأ سلسلتك بعد — غداً فرصة جديدة بإذن الله
          </motion.p>
        )}

        <div className="mt-4 w-full">
          <FactCard fact={question.fact} />
        </div>

        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.5 }} className="mt-4 w-full">
          <CountdownBar />
        </motion.div>
      </div>
    </motion.div>
  );
}
